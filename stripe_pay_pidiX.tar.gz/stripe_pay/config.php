<?php
// 文件位置：/public/plugins/gateway/stripe_pay/config/config.php
return [
    'live_secret_key' => [
        'title' => 'Secret Key',
        'type'  => 'password',
        'value' => '',
        'tip'   => 'Stripe 生产环境私钥，以 sk_live_ 开头',
        'size'  => 300,
    ],
    'live_publishable_key' => [
        'title' => 'Publishable Key',
        'type'  => 'text',
        'value' => '',
        'tip'   => 'Stripe 生产环境公钥，以 pk_live_ 开头',
        'size'  => 300,
    ],
    'webhook_secret' => [
        'title' => 'Webhook 签名密钥',
        'type'  => 'text',
        'value' => '',
        'tip'   => '用于验证 Stripe 异步通知的签名，以 whsec_ 开头',
        'size'  => 300,
    ],
'currency' => [
    'title' => '结算货币',
    'type'  => 'text',
    'value' => 'usd',
    'tip'   => '请输入 ISO 货币代码（小写），如 usd、eur、hkd、cny 等',
    'size'  => 100,
],
];