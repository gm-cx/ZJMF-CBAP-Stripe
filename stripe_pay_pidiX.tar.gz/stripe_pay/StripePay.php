<?php
namespace gateway\stripe_pay;

use app\common\lib\Plugin;
use think\facade\Db;

class StripePay extends Plugin
{
    public $info = [
        'name'        => 'StripePay',
        'title'       => 'Stripe支付',
        'description' => '跳转Stripe官方页面支付',
        'author'      => '智简魔方',
        'version'     => '1.0.0',
        'help_url'    => 'https://stripe.com/',
        'author_url'  => '',
        'url'         => '',
    ];

    public $orderRule = 1;

    public function install()
    {
        return true;
    }

    public function uninstall()
    {
        return true;
    }

    public function StripePayHandle($param)
    {
        $config = $this->Config();

        // 检查 SDK
        $sdkPath = dirname(__FILE__) . '/lib/init.php';
        if (!file_exists($sdkPath)) {
            return '<div style="color:red;">Stripe SDK 未安装，请联系管理员。</div>';
        }
        require_once $sdkPath;

        $secretKey = $config['live_secret_key'] ?? '';

        if (empty($secretKey)) {
            return '<div style="color:red;">Stripe 密钥未配置，请检查插件设置。</div>';
        }

        \Stripe\Stripe::setApiKey($secretKey);
        \Stripe\Stripe::setApiVersion('2022-11-15');

        $amount = (int)($param['finance']['total'] * 100);
        $currency = $config['currency'] ?? 'usd';
        $tmpOrderId = $param['finance']['tmp_order_id'];
        $orderId = $param['finance']['id'];
        $customerEmail = $param['client']['email'] ?? '';
        $customerName = $param['client']['username'] ?? '';

        // 构建同步返回地址（支付完成后跳回）
        $returnUrl = rtrim($param['global']['website_url'], '/') . '/gateway/stripe_pay/index/returnHandle';
        // 异步 Webhook 地址（由 Stripe 服务器回调）
        $webhookUrl = rtrim($param['global']['website_url'], '/') . '/gateway/stripe_pay/index/notifyHandle';

        try {
            // 创建 Checkout Session
            $session = \Stripe\Checkout\Session::create([
// 修改这里：添加 'alipay' 到支持的支付方式列表
            'payment_method_types' => ['card', 'alipay'],
            'line_items' => [[
                'price_data' => [
                    'currency' => $currency,
                    'product_data' => [
                        'name' => '订单 #' . $orderId,
                    ],
                    'unit_amount' => $amount,
                ],
                'quantity' => 1,
            ]],
            'mode' => 'payment',
            'success_url' => $returnUrl . '?session_id={CHECKOUT_SESSION_ID}',
            'cancel_url' => $returnUrl . '?canceled=true',
            'client_reference_id' => $tmpOrderId,
            'customer_email' => $customerEmail,
            'metadata' => [
                'tmp_order_id' => $tmpOrderId,
                'order_id'     => $orderId,
            ],
        ]);
    } catch (\Exception $e) {
            return '<div style="color:red;">支付会话创建失败：' . htmlspecialchars($e->getMessage()) . '</div>';
        }

        // 返回包含跳转按钮的页面（或自动跳转）
        return $this->buildRedirectPage($session->url, $param);
    }

    public function StripePayHandleRefund($param)
    {
        // 退款逻辑不变（可保留 PaymentIntent 退款，或改用 Checkout Session 关联的 PaymentIntent）
        $config = $this->Config();
        $sdkPath = dirname(__FILE__) . '/lib/init.php';
        if (!file_exists($sdkPath)) {
            return ['status' => 400, 'msg' => 'SDK未安装'];
        }
        require_once $sdkPath;

        $secretKey = $config['live_secret_key'] ?? '';
        \Stripe\Stripe::setApiKey($secretKey);

        try {
            // 根据交易流水号（可能是 PaymentIntent ID 或 Session ID）退款
            // 如果是 Session ID，需先获取 PaymentIntent
            $refund = \Stripe\Refund::create([
                'payment_intent' => $param['transaction_number'],
                'amount'         => (int)($param['amount'] * 100),
            ]);
            if ($refund->status === 'succeeded') {
                return ['status' => 200, 'msg' => '退款成功', 'data' => ['trade_no' => $refund->id]];
            } else {
                return ['status' => 400, 'msg' => '退款处理中'];
            }
        } catch (\Exception $e) {
            return ['status' => 400, 'msg' => $e->getMessage()];
        }
    }

    public function Config()
    {
        $dbConfig = Db::name('plugin')
            ->where('name', $this->info['name'])
            ->value('config');
        if (!empty($dbConfig) && $dbConfig != "null") {
            $config = json_decode($dbConfig, true);
        } else {
            $config = [];
        }

        $defaultConfigFile = dirname(__FILE__) . '/config/config.php';
        $default = [];
        if (file_exists($defaultConfigFile)) {
            $default = require $defaultConfigFile;
        }

        return array_merge($default, $config);
    }

    /**
     * 构建跳转页面（显示一个按钮，点击后跳转）
     */
    private function buildRedirectPage($checkoutUrl, $param)
    {
        $orderId = $param['finance']['id'];
        $amount = $param['finance']['total'];
        $currency = strtoupper($this->Config()['currency'] ?? 'usd');

        // 也可直接自动跳转，取消注释下面一行即可
        // header('Location: ' . $checkoutUrl); exit;

        return <<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>跳转支付</title>
    <style>
        body { font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; background: #f5f5f5; }
        .container { width: 100%; max-width: 400px; padding: 30px; background: #fff; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }
        .title { margin-bottom: 20px; color: #333; }
        .order-info { background: #f9f9f9; padding: 15px; border-radius: 4px; margin-bottom: 25px; text-align: left; }
        .order-info p { margin: 5px 0; color: #666; }
        .btn-pay { display: inline-block; padding: 14px 30px; background: #635bff; color: #fff; border: none; border-radius: 4px; font-size: 18px; cursor: pointer; text-decoration: none; }
        .btn-pay:hover { background: #524ee0; }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="title">确认支付</h2>
        <div class="order-info">
            <p><strong>订单号：</strong> {$orderId}</p>
            <p><strong>支付金额：</strong> {$amount} {$currency}</p>
        </div>
        <a href="{$checkoutUrl}" class="btn-pay" target="_blank">去支付</a>
    </div>
</body>
</html>
HTML;
    }
}