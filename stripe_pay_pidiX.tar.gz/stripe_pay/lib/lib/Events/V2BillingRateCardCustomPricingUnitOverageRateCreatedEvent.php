<?php

// File generated from our OpenAPI spec

namespace Stripe\Events;

/**
 * @property \Stripe\RelatedObject $related_object Object containing the reference to API resource relevant to the event
 * @property \Stripe\EventData\V2BillingRateCardCustomPricingUnitOverageRateCreatedEventData $data data associated with the event
 */
class V2BillingRateCardCustomPricingUnitOverageRateCreatedEvent extends \Stripe\V2\Core\Event
{
    const LOOKUP_TYPE = 'v2.billing.rate_card_custom_pricing_unit_overage_rate.created';

    /**
     * Retrieves the related object from the API. Make an API request on every call.
     *
     * @return \Stripe\V2\Billing\RateCardCustomPricingUnitOverageRate
     *
     * @throws \Stripe\Exception\ApiErrorException if the request fails
     */
    public function fetchRelatedObject()
    {
        $apiMode = \Stripe\Util\Util::getApiMode($this->related_object->url);
        list($object, $options) = $this->_request('get', $this->related_object->url, [], [
            'stripe_context' => $this->context,
            'headers' => ['Stripe-Request-Trigger' => 'event=' . $this->id],
        ], [], $apiMode);

        return \Stripe\Util\Util::convertToStripeObject($object, $options, $apiMode);
    }

    public static function constructFrom($values, $opts = null, $apiMode = 'v2')
    {
        $evt = parent::constructFrom($values, $opts, $apiMode);
        if (null !== $evt->data) {
            $evt->data = \Stripe\EventData\V2BillingRateCardCustomPricingUnitOverageRateCreatedEventData::constructFrom($evt->data, $opts, $apiMode);
        }

        return $evt;
    }
}
