<?php

// File generated from our OpenAPI spec

namespace Stripe\Billing;

/**
 * @property string $object String representing the object's type. Objects of the same type share the same value.
 * @property null|(object{ends_at: int, starts_at: int}&\Stripe\StripeObject) $aggregation_period The aggregation period for which this alert triggered
 * @property Alert $alert A billing alert is a resource that notifies you when a certain usage threshold on a meter is crossed. For example, you might create a billing alert to notify you when a certain user made 100 API requests.
 * @property int $created Time at which the object was created. Measured in seconds since the Unix epoch.
 * @property null|string $currency Currency for the threshold value
 * @property null|string $custom_pricing_unit Custom pricing unit for the threshold value
 * @property string $customer ID of customer for which the alert triggered
 * @property null|string $external_customer_id External customer ID for the customer for which the alert triggered
 * @property null|(object{billing_cadence: null|string, pricing_plan_subscription: null|string, type: string}&\Stripe\StripeObject) $group_by Populated specifically for spend alerts to notify merchants which group_by entity has the exceeded spend
 * @property bool $livemode If the object exists in live mode, the value is <code>true</code>. If the object exists in test mode, the value is <code>false</code>.
 * @property null|int $triggered_at Timestamp at which the threshold was crossed
 * @property string $value The value triggering the alert
 */
class AlertTriggered extends \Stripe\ApiResource
{
    const OBJECT_NAME = 'billing.alert_triggered';
}
