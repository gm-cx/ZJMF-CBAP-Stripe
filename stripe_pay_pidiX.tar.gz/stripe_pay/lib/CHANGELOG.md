# Changelog

## 20.1.0-alpha.4 - 2026-04-15
* [#2057](https://github.com/stripe/stripe-php/pull/2057) Update generated code for private-preview
  * Add support for `latest_version` on `V2.Billing.LicenseFee`, `V2.Billing.PricingPlan`, and `V2.Billing.RateCard`
  * Add support for `service_interval_count` and `service_interval` on `V2.Billing.LicenseFee` and `V2.Billing.RateCard`
* [#2055](https://github.com/stripe/stripe-php/pull/2055) Update generated code for private-preview
  * Add support for new resources `V2.Core.WorkflowRun` and `V2.Core.Workflow`
  * Add support for `report_authorized` method on resource `PaymentAttemptRecord`
  * Add support for `all` and `retrieve` methods on resource `V2.Core.WorkflowRun`
  * Add support for `all`, `invoke`, and `retrieve` methods on resource `V2.Core.Workflow`
  * Add support for `next_action` and `status` on `SharedPayment.IssuedToken`
  * ⚠️ Remove support for `network_id` on `SharedPayment.IssuedToken.seller_details`
  * Add support for `bills` on `AccountSession.components`
  * Add support for `settlement_currencies` on `BalanceSettings.payments` and `BalanceSettings.update().$params.payment`
  * Add support for `default_settlement_currency` on `BalanceSettings.payments`
  * Add support for `account_funding` on `Charge.payment_method_details.card`
  * Add support for `automatic_surcharge` on `Checkout.Session`, `Checkout\Session.create().$params`, `PaymentLink.create().$params`, and `PaymentLink`
  * Add support for `bizum` on `Checkout.Session.payment_method_options` and `Checkout\Session.create().$params.payment_method_option`
  * Add support for `surcharge_cost` on `Checkout.Session`
  * Add support for `amount_surcharge` on `Checkout.Session.total_details`
  * Add support for `shared_payment_granted_token` on `ConfirmationToken.create().$params.payment_method_datum`, `PaymentIntent.confirm().$params.payment_method_datum`, `PaymentIntent.create().$params.payment_method_datum`, `PaymentIntent.update().$params.payment_method_datum`, `SetupIntent.confirm().$params.payment_method_datum`, `SetupIntent.create().$params.payment_method_datum`, and `SetupIntent.update().$params.payment_method_datum`
  * Add support for `details` on `Identity.VerificationReport.email`
  * Add support for new value `email` on enums `Identity.VerificationReport.type` and `Identity.VerificationSession.type`
  * Add support for `confirm` on `Identity\VerificationSession.create().$params` and `Identity\VerificationSession.update().$params`
  * Add support for `subscription` on `InvoiceItem.parent.schedule_details`
  * ⚠️ Remove support for `shared_payment_granted_token` on `PaymentIntent.confirm().$params` and `PaymentIntent.create().$params`
  * Add support for `money_services` on `PaymentIntent.payment_details`
  * ⚠️ Remove support for `external_reference` on `Plan`
  * Change `SharedPayment.GrantedToken.payment_method_details.billing_details` to be required

## 20.1.0-alpha.3 - 2026-04-08
* [#2053](https://github.com/stripe/stripe-php/pull/2053) Update generated code for private-preview
  * Add support for `payment_record` on `ApplicationFee.fee_source`
  * Add support for `fleet_data` on `Charge.capture().$params.payment_detail`, `Charge.update().$params.payment_detail`, `PaymentIntent.capture().$params.amount_detail.line_item.payment_method_option.card`, `PaymentIntent.capture().$params.payment_detail`, `PaymentIntent.confirm().$params.amount_detail.line_item.payment_method_option.card`, `PaymentIntent.confirm().$params.payment_detail`, `PaymentIntent.create().$params.amount_detail.line_item.payment_method_option.card`, `PaymentIntent.create().$params.payment_detail`, `PaymentIntent.decrement_authorization().$params.amount_detail.line_item.payment_method_option.card`, `PaymentIntent.increment_authorization().$params.amount_detail.line_item.payment_method_option.card`, `PaymentIntent.payment_details`, `PaymentIntent.update().$params.amount_detail.line_item.payment_method_option.card`, `PaymentIntent.update().$params.payment_detail`, and `PaymentIntentAmountDetailsLineItem.payment_method_options.card`
  * Add support for `beneficiary_account`, `beneficiary_details`, `sender_account`, and `sender_details` on `Charge.capture().$params.payment_detail.money_service.account_funding`, `Charge.update().$params.payment_detail.money_service.account_funding`, `PaymentIntent.capture().$params.payment_detail.money_service.account_funding`, `PaymentIntent.confirm().$params.payment_detail.money_service.account_funding`, `PaymentIntent.create().$params.payment_detail.money_service.account_funding`, and `PaymentIntent.update().$params.payment_detail.money_service.account_funding`
  * Change type of `Charge.capture().$params.payment_detail.money_service.transaction_type`, `Charge.update().$params.payment_detail.money_service.transaction_type`, `PaymentIntent.capture().$params.payment_detail.money_service.transaction_type`, `PaymentIntent.confirm().$params.payment_detail.money_service.transaction_type`, `PaymentIntent.create().$params.payment_detail.money_service.transaction_type`, and `PaymentIntent.update().$params.payment_detail.money_service.transaction_type` from `literal('account_funding')` to `emptyable(literal('account_funding'))`
  * Add support for new value `requires_action` on enum `DelegatedCheckout.RequestedSession.status`
  * Add support for `bizum` on `Invoice.create().$params.payment_setting.payment_method_option`, `Invoice.payment_settings.payment_method_options`, `Invoice.update().$params.payment_setting.payment_method_option`, `QuotePreviewInvoice.payment_settings.payment_method_options`, `Subscription.create().$params.payment_setting.payment_method_option`, `Subscription.payment_settings.payment_method_options`, and `Subscription.update().$params.payment_setting.payment_method_option`
  * Add support for new value `bizum` on enums `Invoice.payment_settings.payment_method_types`, `QuotePreviewInvoice.payment_settings.payment_method_types`, and `Subscription.payment_settings.payment_method_types`
  * Add support for `quantity_precision` on `PaymentIntent.capture().$params.amount_detail.line_item`, `PaymentIntent.confirm().$params.amount_detail.line_item`, `PaymentIntent.create().$params.amount_detail.line_item`, `PaymentIntent.decrement_authorization().$params.amount_detail.line_item`, `PaymentIntent.increment_authorization().$params.amount_detail.line_item`, `PaymentIntent.update().$params.amount_detail.line_item`, and `PaymentIntentAmountDetailsLineItem`
  * Add support for `liquid_asset` and `wallet` on `PaymentIntent.confirm().$params.payment_method_option.card.payment_detail.money_service.account_funding`, `PaymentIntent.confirm().$params.payment_method_option.card_present.payment_detail.money_service.account_funding`, `PaymentIntent.create().$params.payment_method_option.card.payment_detail.money_service.account_funding`, `PaymentIntent.create().$params.payment_method_option.card_present.payment_detail.money_service.account_funding`, `PaymentIntent.update().$params.payment_method_option.card.payment_detail.money_service.account_funding`, and `PaymentIntent.update().$params.payment_method_option.card_present.payment_detail.money_service.account_funding`
  * Add support for `shared_payment_granted_token` on `PaymentMethod`
  * ⚠️ Change type of `Radar.CustomerEvaluation.event_type` from `string` to `enum('login'|'registration')`
  * ⚠️ Change type of `Radar.CustomerEvaluation.signals.account_sharing.risk_level` and `Radar.CustomerEvaluation.signals.multi_accounting.risk_level` from `string` to `enum`
  * Add support for `data` on `Radar.PaymentEvaluation.client_device_metadata_details` and `Radar\PaymentEvaluation.create().$params.client_device_metadata_detail`
  * Add support for `sunbit` on `SharedPayment.GrantedToken.payment_method_details`
  * Add support for new value `sunbit` on enum `SharedPayment.GrantedToken.payment_method_details.type`
  * ⚠️ Remove support for values `bm_crn`, `bo_tin`, `bt_tpn`, `co_nit`, `ec_ruc`, `eg_tin`, `gh_tin`, `gy_tin`, `hn_rtn`, `jm_trn`, `jo_crn`, `ke_pin`, `ky_crn`, `lk_tin`, `mo_tin`, `mv_tin`, `ng_tin`, `pa_ruc`, `ph_tin`, `py_ruc`, `sl_tin`, `sv_nit`, `uy_ruc`, `vg_cn`, and `za_tin` from enum `V2.Core.Account.identity.business_details.id_numbers[].type`
  * ⚠️ Remove support for values `bm_pp`, `bo_ci`, `bt_cid`, `eg_tin`, `gh_pin`, `gy_tin`, `hn_rtn`, `jm_trn`, `jo_pin`, `ky_pp`, `lk_nic`, `mo_bir`, `mt_nic`, `mv_tin`, `pa_ruc`, `ph_tin`, `py_ruc`, `si_pin`, `sv_nit`, and `vg_pp` from enums `V2.Core.Account.identity.individual.id_numbers[].type` and `V2.Core.AccountPerson.id_numbers[].type`
  * Add support for error type `CannotProceedException`

## 20.1.0-alpha.2 - 2026-04-01
* [#2051](https://github.com/stripe/stripe-php/pull/2051) Update generated code for private-preview
  * Add support for new resources `SharedPayment.IssuedToken` and `V2.Data.Reporting.QueryRun`
  * Add support for `create` and `retrieve` methods on resource `V2.Data.Reporting.QueryRun`
  * Add support for `pause` and `resume` methods on resource `V2.Payments.OffSessionPayment`
  * Add support for `tenant_keys`, `tenant_operator`, and `tenant_values` on `Billing\MeterEventSummary.all().$params`
  * Add support for `money_services` on `Charge.capture().$params.payment_detail`, `Charge.update().$params.payment_detail`, `PaymentIntent.capture().$params.payment_detail`, `PaymentIntent.confirm().$params.payment_detail`, `PaymentIntent.create().$params.payment_detail`, and `PaymentIntent.update().$params.payment_detail`
  * Add support for `payment_method_options` on `DelegatedCheckout.RequestedSession`, `DelegatedCheckout\RequestedSession.create().$params`, and `DelegatedCheckout\RequestedSession.update().$params`
  * ⚠️ Remove support for `payment_method_data` on `DelegatedCheckout\RequestedSession.confirm().$params`, `DelegatedCheckout\RequestedSession.create().$params`, and `DelegatedCheckout\RequestedSession.update().$params`
  * Add support for `card_brands` and `payment_method_types` on `DelegatedCheckout.RequestedSession.seller_details`
  * Change type of `DelegatedCheckout.RequestedSession.shared_payment_issued_token` from `string` to `expandable($SharedPayment.IssuedToken)`
  * Add support for `check_scan` on `Invoice.create().$params.payment_setting.payment_method_option`, `Invoice.payment_settings.payment_method_options`, `Invoice.update().$params.payment_setting.payment_method_option`, `QuotePreviewInvoice.payment_settings.payment_method_options`, `Subscription.create().$params.payment_setting.payment_method_option`, `Subscription.payment_settings.payment_method_options`, and `Subscription.update().$params.payment_setting.payment_method_option`
  * Add support for new value `check_scan` on enums `Invoice.payment_settings.payment_method_types`, `QuotePreviewInvoice.payment_settings.payment_method_types`, and `Subscription.payment_settings.payment_method_types`
  * Add support for `processor_details` on `PaymentAttemptRecord.report_failed().$params`, `PaymentAttemptRecord.report_guaranteed().$params`, `PaymentRecord.report_payment().$params.failed`, `PaymentRecord.report_payment().$params.guaranteed`, `PaymentRecord.report_payment_attempt().$params.failed`, `PaymentRecord.report_payment_attempt().$params.guaranteed`, `PaymentRecord.report_payment_attempt_failed().$params`, and `PaymentRecord.report_payment_attempt_guaranteed().$params`
  * Add support for `payment_details` on `PaymentIntent.confirm().$params.payment_method_option.card_present`, `PaymentIntent.confirm().$params.payment_method_option.card`, `PaymentIntent.create().$params.payment_method_option.card_present`, `PaymentIntent.create().$params.payment_method_option.card`, `PaymentIntent.update().$params.payment_method_option.card_present`, and `PaymentIntent.update().$params.payment_method_option.card`
  * ⚠️ Remove support for `bill_from` on `QuotePreviewSubscriptionSchedule.billing_schedules[]`, `Subscription.billing_schedules[]`, and `SubscriptionSchedule.billing_schedules[]`
  * Add support for `agent_details`, `payment_method_details`, and `risk_details` on `SharedPayment.GrantedToken`
  * Add support for `paper_checks` on `V2.Account.configuration.recipient_data.features`, `V2.Core.Account.configuration.recipient.capabilities`, `V2.Core.Account.configuration.storer.capabilities.outbound_payments`, `V2\Account.create().$params.configuration.recipient_datum.feature`, `V2\Account.update().$params.configuration.recipient_datum.feature`, `V2\Core\Account.create().$params.configuration.recipient.capability`, `V2\Core\Account.create().$params.configuration.storer.capability.outbound_payment`, `V2\Core\Account.update().$params.configuration.recipient.capability`, and `V2\Core\Account.update().$params.configuration.storer.capability.outbound_payment`
  * Add support for new value `paper_checks` on enum `V2.Account.configuration.supportable_features.recipient_data`
  * Add support for new value `paper_checks` on enum `V2.Account.requirements[].impact.required_for_features`
  * ⚠️ Change type of `V2.Billing.Cadence.settings_data.collection.payment_method_options.konbini`, `V2.Billing.CollectionSetting.payment_method_options.konbini`, `V2.Billing.CollectionSettingVersion.payment_method_options.konbini`, `V2\Billing\CollectionSetting.create().$params.payment_method_option.konbini`, and `V2\Billing\CollectionSetting.update().$params.payment_method_option.konbini` from `map(string: dynamic)` to `an object`
  * ⚠️ Change type of `V2.Billing.Cadence.settings_data.collection.payment_method_options.sepa_debit`, `V2.Billing.CollectionSetting.payment_method_options.sepa_debit`, `V2.Billing.CollectionSettingVersion.payment_method_options.sepa_debit`, `V2\Billing\CollectionSetting.create().$params.payment_method_option.sepa_debit`, and `V2\Billing\CollectionSetting.update().$params.payment_method_option.sepa_debit` from `map(string: dynamic)` to `an object`
  * Add support for `id` on `V2.Billing.CadenceSpendModifier.max_billing_period_spend.amount.custom_pricing_unit`, `V2.Billing.IntentAction.apply.spend_modifier_rule.max_billing_period_spend.amount.custom_pricing_unit`, and `V2\Billing\Intent.create().$params.action.apply.spend_modifier_rule.max_billing_period_spend.amount.custom_pricing_unit`
  * Add support for new values `outbound_payments.paper_checks` and `paper_checks` on enums `V2.Core.Account.future_requirements.entries[].impact.restricts_capabilities[].capability` and `V2.Core.Account.requirements.entries[].impact.restricts_capabilities[].capability`
  * Add support for new values `bm_crn`, `bo_tin`, `bt_tpn`, `co_nit`, `ec_ruc`, `eg_tin`, `gh_tin`, `gy_tin`, `hn_rtn`, `jm_trn`, `jo_crn`, `ke_pin`, `ky_crn`, `lk_tin`, `mo_tin`, `mv_tin`, `ng_tin`, `pa_ruc`, `ph_tin`, `py_ruc`, `sl_tin`, `sv_nit`, `uy_ruc`, `vg_cn`, and `za_tin` on enum `V2.Core.Account.identity.business_details.id_numbers[].type`
  * Add support for new values `bm_pp`, `bo_ci`, `bt_cid`, `eg_tin`, `gh_pin`, `gy_tin`, `hn_rtn`, `jm_trn`, `jo_pin`, `ky_pp`, `lk_nic`, `mo_bir`, `mt_nic`, `mv_tin`, `pa_ruc`, `ph_tin`, `py_ruc`, `si_pin`, `sv_nit`, and `vg_pp` on enums `V2.Core.Account.identity.individual.id_numbers[].type` and `V2.Core.AccountPerson.id_numbers[].type`
  * ⚠️ Change type of `V2.Core.Event.reason.request.client.stripe_action` from `map(string: dynamic)` to `an object`
  * ⚠️ Change type of `V2.MoneyManagement.InboundTransfer.transfer_history[].bank_debit_processing` from `map(string: dynamic)` to `an object`
  * ⚠️ Change type of `V2.MoneyManagement.InboundTransfer.transfer_history[].bank_debit_queued` from `map(string: dynamic)` to `an object`
  * ⚠️ Change type of `V2.MoneyManagement.InboundTransfer.transfer_history[].bank_debit_succeeded` from `map(string: dynamic)` to `an object`
  * Add support for new values `paper_check_attachment_too_large`, `paper_check_expired`, and `paper_check_undeliverable` on enum `V2.MoneyManagement.OutboundPayment.status_details.failed.reason`
  * ⚠️ Remove support for `town` on `V2.MoneyManagement.OutboundPayment.tracking_details.paper_check.mailing_address`
  * Change `V2.MoneyManagement.OutboundPayment.delivery_options.paper_check.memo` to be required
  * Add support for new value `payout_method_amount_limit_exceeded` on enum `V2.MoneyManagement.OutboundTransfer.status_details.failed.reason`
  * Add support for `application_fee_amount_requested` on `V2.Payments.OffSessionPayment`
  * ⚠️ Remove support for `compartment_id` on `V2.Payments.OffSessionPayment`
  * Add support for new value `exceeded_retry_window` on enum `V2.Payments.OffSessionPayment.failure_reason`
  * Add support for `retry_until` on `V2.Payments.OffSessionPayment.retry_details`
  * Add support for new value `paused` on enum `V2.Payments.OffSessionPayment.status`
  * ⚠️ Change `V2.Reporting.ReportRun.result.file` to be optional
  * Add support for `application_fee_amount` on `V2\Payments\OffSessionPayment.capture().$params` and `V2\Payments\OffSessionPayment.create().$params`
  * Add support for new value `paper_checks` on enum `EventsV2CoreAccountIncludingConfigurationRecipientCapabilityStatusUpdatedEvent.updated_capability`
  * Add support for new value `outbound_payments.paper_checks` on enum `EventsV2CoreAccountIncludingConfigurationStorerCapabilityStatusUpdatedEvent.updated_capability`
  * Add support for `alert_id` on `EventsV2CoreHealthApiErrorResolvedEvent`, `EventsV2CoreHealthApiLatencyResolvedEvent`, `EventsV2CoreHealthAuthorizationRateDropResolvedEvent`, `EventsV2CoreHealthIssuingAuthorizationRequestErrorsFiringEvent`, `EventsV2CoreHealthIssuingAuthorizationRequestErrorsResolvedEvent`, `EventsV2CoreHealthIssuingAuthorizationRequestTimeoutResolvedEvent`, `EventsV2CoreHealthPaymentMethodErrorResolvedEvent`, `EventsV2CoreHealthSepaDebitDelayedFiringEvent`, `EventsV2CoreHealthSepaDebitDelayedResolvedEvent`, `EventsV2CoreHealthTrafficVolumeDropResolvedEvent`, and `EventsV2CoreHealthWebhookLatencyResolvedEvent`
  * Add support for `api_key` on `EventsV2IamApiKeyCreatedEvent`, `EventsV2IamApiKeyDefaultSecretRevealedEvent`, `EventsV2IamApiKeyExpiredEvent`, `EventsV2IamApiKeyPermissionsUpdatedEvent`, `EventsV2IamApiKeyRotatedEvent`, and `EventsV2IamApiKeyUpdatedEvent`
  * Add support for `stripe_access_grant` on `EventsV2IamStripeAccessGrantApprovedEvent`, `EventsV2IamStripeAccessGrantCanceledEvent`, `EventsV2IamStripeAccessGrantDeniedEvent`, `EventsV2IamStripeAccessGrantRemovedEvent`, `EventsV2IamStripeAccessGrantRequestedEvent`, and `EventsV2IamStripeAccessGrantUpdatedEvent`
  * Add support for event notifications `V2DataReportingQueryRunCreatedEvent`, `V2DataReportingQueryRunFailedEvent`, `V2DataReportingQueryRunSucceededEvent`, and `V2DataReportingQueryRunUpdatedEvent` with related object `V2.Data.Reporting.QueryRun`
  * Add support for event notifications `V2PaymentsOffSessionPaymentPausedEvent` and `V2PaymentsOffSessionPaymentResumedEvent` with related object `V2.Payments.OffSessionPayment`
* [#2052](https://github.com/stripe/stripe-php/pull/2052) Fixes an issue encoding two-dimensional array request params where the SDK incorrectly flattens the array.

## 20.1.0-alpha.1 - 2026-03-25

This release changes the pinned API version to 2026-03-25.preview and contains additional breaking changes. See the [GA changelog](https://github.com/stripe/stripe-php/blob/master/CHANGELOG.md#2000---2026-03-25) for more information.

* [#2049](https://github.com/stripe/stripe-php/pull/2049) Update generated code for private-preview
  * Add support for new resource `RiskSignals`
  * Add support for `financial_account_rewards` and `nesting_demo` on `AccountSession.components`
  * Add support for `upi_payments` on `Account.capabilities`, `Account.create().$params.capability`, and `Account.update().$params.capability`
  * Add support for `risk_signals` on `Account`
  * Add support for `fraud_intent` on `AccountSignals`
  * Add support for new value `related_accounts` on enum `AccountSignals.delinquency.indicators[].indicator`
  * Add support for `risk_reserved` on `Balance`
  * ⚠️ Remove support for `billable_items` on `Billing.Alert.spend_threshold.filters`
  * Add support for `upi` on `Charge.payment_method_details`, `Checkout.Session.payment_method_options`, `Checkout\Session.create().$params.payment_method_option`, `ConfirmationToken.create().$params.payment_method_datum`, `ConfirmationToken.payment_method_preview`, `Mandate.payment_method_details`, `PaymentAttemptRecord.payment_method_details`, `PaymentIntent.confirm().$params.payment_method_datum`, `PaymentIntent.confirm().$params.payment_method_option`, `PaymentIntent.create().$params.payment_method_datum`, `PaymentIntent.create().$params.payment_method_option`, `PaymentIntent.payment_method_options`, `PaymentIntent.update().$params.payment_method_datum`, `PaymentIntent.update().$params.payment_method_option`, `PaymentMethod.create().$params`, `PaymentMethodConfiguration.create().$params`, `PaymentMethodConfiguration.update().$params`, `PaymentMethodConfiguration`, `PaymentMethod`, `PaymentRecord.payment_method_details`, `SetupAttempt.payment_method_details`, `SetupIntent.confirm().$params.payment_method_datum`, `SetupIntent.confirm().$params.payment_method_option`, `SetupIntent.create().$params.payment_method_datum`, `SetupIntent.create().$params.payment_method_option`, `SetupIntent.payment_method_options`, `SetupIntent.update().$params.payment_method_datum`, and `SetupIntent.update().$params.payment_method_option`
  * Add support for new value `tempo` on enums `Charge.payment_method_details.crypto.network`, `PaymentAttemptRecord.payment_method_details.crypto.network`, and `PaymentRecord.payment_method_details.crypto.network`
  * ⚠️ Remove support for `source_type` on `Charge.payment_method_details.stripe_balance`, `ConfirmationToken.create().$params.payment_method_datum.stripe_balance`, `ConfirmationToken.payment_method_preview.stripe_balance`, `PaymentAttemptRecord.payment_method_details.stripe_balance`, `PaymentIntent.confirm().$params.payment_method_datum.stripe_balance`, `PaymentIntent.create().$params.payment_method_datum.stripe_balance`, `PaymentIntent.update().$params.payment_method_datum.stripe_balance`, `PaymentMethod.create().$params.stripe_balance`, `PaymentMethod.stripe_balance`, `PaymentRecord.payment_method_details.stripe_balance`, `SetupIntent.confirm().$params.payment_method_datum.stripe_balance`, `SetupIntent.create().$params.payment_method_datum.stripe_balance`, and `SetupIntent.update().$params.payment_method_datum.stripe_balance`
  * Add support for `integration_identifier` on `Checkout.Session` and `Checkout\Session.create().$params`
  * Change type of `Checkout\Session.create().$params.line_item.price_datum.product_datum.tax_detail.tax_code`, `Checkout\Session.update().$params.line_item.price_datum.product_datum.tax_detail.tax_code`, `Invoice.add_lines().$params.line.price_datum.product_datum.tax_detail.tax_code`, `Invoice.update_lines().$params.line.price_datum.product_datum.tax_detail.tax_code`, `InvoiceLineItem.update().$params.price_datum.product_datum.tax_detail.tax_code`, `PaymentLink.create().$params.line_item.price_datum.product_datum.tax_detail.tax_code`, `Plan.create().$params.product.tax_detail.tax_code`, `Price.create().$params.product_datum.tax_detail.tax_code`, `Product.create().$params.tax_detail.tax_code`, and `Product.update().$params.tax_detail.tax_code` from `string` to `emptyable(string)`
  * Add support for `crypto` on `Checkout\Session.create().$params.payment_method_option`
  * Add support for `pending_invoice_item_interval` on `Checkout\Session.create().$params.subscription_datum` and `Checkout\Session.update().$params.subscription_datum`
  * Change `Checkout\Session.create().$params.line_item.price_datum.product_datum.tax_detail.tax_code`, `Checkout\Session.update().$params.line_item.price_datum.product_datum.tax_detail.tax_code`, `Invoice.add_lines().$params.line.price_datum.product_datum.tax_detail.tax_code`, `Invoice.update_lines().$params.line.price_datum.product_datum.tax_detail.tax_code`, `InvoiceLineItem.update().$params.price_datum.product_datum.tax_detail.tax_code`, `PaymentLink.create().$params.line_item.price_datum.product_datum.tax_detail.tax_code`, `Plan.create().$params.product.tax_detail.tax_code`, `Price.create().$params.product_datum.tax_detail.tax_code`, `Product.create().$params.tax_detail.tax_code`, and `Product.update().$params.tax_detail.tax_code` to be optional
  * Add support for new value `application` on enums `Checkout.Session.automatic_tax.liability.type`, `Checkout.Session.invoice_creation.invoice_data.issuer.type`, `Invoice.automatic_tax.liability.type`, `Invoice.issuer.type`, `PaymentLink.automatic_tax.liability.type`, `PaymentLink.invoice_creation.invoice_data.issuer.type`, `PaymentLink.subscription_data.invoice_settings.issuer.type`, `Quote.automatic_tax.liability.type`, `Quote.invoice_settings.issuer.type`, `QuotePreviewInvoice.automatic_tax.liability.type`, `QuotePreviewInvoice.issuer.type`, `QuotePreviewSubscriptionSchedule.default_settings.automatic_tax.liability.type`, `QuotePreviewSubscriptionSchedule.default_settings.invoice_settings.issuer.type`, `QuotePreviewSubscriptionSchedule.phases[].automatic_tax.liability.type`, `QuotePreviewSubscriptionSchedule.phases[].invoice_settings.issuer.type`, `Subscription.automatic_tax.liability.type`, `Subscription.invoice_settings.issuer.type`, `SubscriptionSchedule.default_settings.automatic_tax.liability.type`, `SubscriptionSchedule.default_settings.invoice_settings.issuer.type`, `SubscriptionSchedule.phases[].automatic_tax.liability.type`, and `SubscriptionSchedule.phases[].invoice_settings.issuer.type`
  * Add support for `au_becs_debit`, `bacs_debit`, `boleto`, `link`, `sepa_debit`, and `us_bank_account` on `Checkout.Session.current_attempt.payment_method_details`
  * Add support for new values `elements`, `embedded_page`, `form`, and `hosted_page` on enum `Checkout.Session.ui_mode`
  * ⚠️ Remove support for values `custom`, `embedded`, and `hosted` from enum `Checkout.Session.ui_mode`
  * Add support for new value `marine_carbon_removal` on enum `Climate.Supplier.removal_pathway`
  * Add support for new value `upi` on enums `ConfirmationToken.payment_method_preview.type` and `PaymentMethod.type`
  * Add support for `metadata` on `CreditNote.create().$params.line`, `CreditNote.preview().$params.line`, `CreditNote.preview_lines().$params.line`, and `CreditNoteLineItem`
  * Add support for `selected_fulfillment_option_overrides` on `DelegatedCheckout.RequestedSession.fulfillment_details`
  * Add support for `line_item_keys` on `DelegatedCheckout.RequestedSession.fulfillment_details.fulfillment_options[].digital.digital_options[]` and `DelegatedCheckout.RequestedSession.fulfillment_details.fulfillment_options[].shipping.shipping_options[]`
  * Add support for `quantity_decimal` on `Invoice.add_lines().$params.line`, `Invoice.create_preview().$params.invoice_item`, `Invoice.update_lines().$params.line`, `InvoiceItem.create().$params`, `InvoiceItem.update().$params`, `InvoiceItem`, `InvoiceLineItem.update().$params`, and `InvoiceLineItem`
  * Add support for `expires_after_seconds` on `Invoice.create().$params.payment_setting.payment_method_option.pix`, `Invoice.payment_settings.payment_method_options.pix`, `Invoice.update().$params.payment_setting.payment_method_option.pix`, `QuotePreviewInvoice.payment_settings.payment_method_options.pix`, `Subscription.create().$params.payment_setting.payment_method_option.pix`, `Subscription.payment_settings.payment_method_options.pix`, and `Subscription.update().$params.payment_setting.payment_method_option.pix`
  * ⚠️ Add support for `level` on `Issuing\Authorization.create().$params.risk_assessment.card_testing_risk` and `Issuing\Authorization.create().$params.risk_assessment.merchant_dispute_risk`
  * ⚠️ Remove support for `risk_level` on `Issuing\Authorization.create().$params.risk_assessment.card_testing_risk` and `Issuing\Authorization.create().$params.risk_assessment.merchant_dispute_risk`
  * Add support for new values `da`, `pl`, and `sv` on enum `Issuing.Cardholder.preferred_locales`
  * Add support for `lifecycle_controls` on `Issuing.Card` and `Issuing\Card.create().$params`
  * ⚠️ Change type of `Issuing.Token.network_data.visa.card_reference_id` from `string` to `nullable(string)`
  * ⚠️ Change type of `PaymentAttemptRecord.payment_method_details.card.brand` and `PaymentRecord.payment_method_details.card.brand` from `enum` to `nullable(enum)`
  * ⚠️ Change type of `PaymentAttemptRecord.payment_method_details.card.exp_month` and `PaymentRecord.payment_method_details.card.exp_month` from `longInteger` to `nullable(longInteger)`
  * ⚠️ Change type of `PaymentAttemptRecord.payment_method_details.card.exp_year` and `PaymentRecord.payment_method_details.card.exp_year` from `longInteger` to `nullable(longInteger)`
  * ⚠️ Change type of `PaymentAttemptRecord.payment_method_details.card.funding` and `PaymentRecord.payment_method_details.card.funding` from `enum('credit'|'debit'|'prepaid'|'unknown')` to `nullable(enum('credit'|'debit'|'prepaid'|'unknown'))`
  * ⚠️ Change type of `PaymentAttemptRecord.payment_method_details.card.last4` and `PaymentRecord.payment_method_details.card.last4` from `string` to `nullable(string)`
  * ⚠️ Change type of `PaymentAttemptRecord.payment_method_details.card.moto` and `PaymentRecord.payment_method_details.card.moto` from `boolean` to `nullable(boolean)`
  * Add support for `cryptogram`, `electronic_commerce_indicator`, `exemption_indicator_applied`, and `exemption_indicator` on `PaymentAttemptRecord.payment_method_details.card.three_d_secure` and `PaymentRecord.payment_method_details.card.three_d_secure`
  * Add support for `surcharge` on `PaymentIntent.amount_details`, `PaymentIntent.capture().$params.amount_detail`, `PaymentIntent.confirm().$params.amount_detail`, `PaymentIntent.create().$params.amount_detail`, `PaymentIntent.increment_authorization().$params.amount_detail`, and `PaymentIntent.update().$params.amount_detail`
  * Add support for `mandate_options` on `PaymentIntent.confirm().$params.payment_method_option.stripe_balance`, `PaymentIntent.create().$params.payment_method_option.stripe_balance`, `PaymentIntent.payment_method_options.stripe_balance`, and `PaymentIntent.update().$params.payment_method_option.stripe_balance`
  * Add support for `amount_details` and `payment_details` on `PaymentIntent.decrement_authorization().$params`
  * Add support for new value `upi` on enums `PaymentIntent.excluded_payment_method_types` and `SetupIntent.excluded_payment_method_types`
  * Add support for `upi_handle_redirect_or_display_qr_code` on `PaymentIntent.next_action` and `SetupIntent.next_action`
  * Add support for `managed_payments` on `PaymentLink.create().$params` and `PaymentLink`
  * Add support for new value `upi` on enum `PaymentLink.payment_method_types`
  * Add support for `recommended_action` and `signals` on `Radar.PaymentEvaluation`
  * ⚠️ Remove support for `insights` on `Radar.PaymentEvaluation`
  * Add support for new value `crypto_fingerprint` on enum `Radar.ValueList.item_type`
  * Add support for `stripe_balance` on `SetupIntent.confirm().$params.payment_method_option`, `SetupIntent.create().$params.payment_method_option`, `SetupIntent.payment_method_options`, and `SetupIntent.update().$params.payment_method_option`
  * Add support for new value `resolved` on enum `SharedPayment.GrantedToken.deactivated_reason`
  * Add support for `recurring_interval` on `SharedPayment.GrantedToken.usage_limits`
  * ⚠️ Change type of `SharedPayment.GrantedToken.usage_limits.expires_at` from `DateTime` to `nullable(DateTime)`
  * Add support for `presentment_details` on `Subscription`
  * Add support for new value `canceled_by_retention_policy` on enum `Subscription.cancellation_details.reason`
  * ⚠️ Remove support for `invoice_resources` on `V2.Billing.Intent`
  * ⚠️ Remove support for `amount_due` and `customer_balance_applied` on `V2.Billing.Intent.amount_details`
  * Add support for `recurring_credit_grant` on `V2.Billing.IntentAction.modify.pricing_plan_subscription_details.overrides.partial_period_behaviors[]`, `V2.Billing.IntentAction.subscribe.pricing_plan_subscription_details.overrides.partial_period_behaviors[]`, `V2\Billing\Intent.create().$params.action.modify.pricing_plan_subscription_detail.override.partial_period_behavior`, and `V2\Billing\Intent.create().$params.action.subscribe.pricing_plan_subscription_detail.override.partial_period_behavior`
  * Add support for `consumer_privacy_disclosures` and `consumer_storer` on `V2.Core.Account.identity.attestations.terms_of_service`, `V2\Core\Account.create().$params.identity.attestation.terms_of_service`, and `V2\Core\Account.update().$params.identity.attestation.terms_of_service`
  * ⚠️ Remove support for `include` on `V2\Billing\Intent.create().$params` and `V2\Billing\Intent.reserve().$params`
  * Add support for error code `service_period_coupon_with_metered_tiered_item_unsupported` on `Invoice.last_finalization_error`, `PaymentIntent.last_payment_error`, `QuotePreviewInvoice.last_finalization_error`, `SetupAttempt.setup_error`, `SetupIntent.last_setup_error`, and `StripeError`
* [#2048](https://github.com/stripe/stripe-php/pull/2048) Update generated code for private-preview
  * Release specs are identical.
* [#2037](https://github.com/stripe/stripe-php/pull/2037) Update generated code for private-preview
  * Add support for new resource `V2.Core.AccountEvaluation`
  * ⚠️ Remove support for resources `V2.Billing.LicenseFeeSubscription` and `V2.Billing.PricingPlanSubscriptionComponents`
  * Add support for `create` method on resource `V2.Core.AccountEvaluation`
  * ⚠️ Remove support for `retrieve` method on resources `V2.Billing.LicenseFeeSubscription` and `V2.Billing.PricingPlanSubscriptionComponents`
  * Add support for `modify_rates` method on resource `V2.Billing.RateCard`
  * Add support for `remove_discounts` method on resource `V2.Billing.PricingPlanSubscription`
  * Add support for new value `eg_bank_account` on enum `V2.Account.configuration.recipient_data.default_outbound_destination.type`
  * Add support for `invoice_resources` on `V2.Billing.Intent`
  * Add support for `amount_due` and `customer_balance_applied` on `V2.Billing.Intent.amount_details`
  * Add support for `expires_at` on `V2.Billing.Intent.status_transitions`
  * Add support for `discount` on `V2.Billing.IntentAction.apply` and `V2\Billing\Intent.create().$params.action.apply`
  * Add support for `timestamp` on `V2.Billing.IntentAction.apply.effective_at` and `V2\Billing\Intent.create().$params.action.apply.effective_at`
  * Add support for new values `current_billing_period_start` and `timestamp` on enum `V2.Billing.IntentAction.apply.effective_at.type`
  * Add support for new value `discount` on enum `V2.Billing.IntentAction.apply.type`
  * ⚠️ Change type of `V2.Billing.IntentAction.deactivate.pricing_plan_subscription_details.overrides.partial_period_behaviors[].type`, `V2.Billing.IntentAction.modify.pricing_plan_subscription_details.overrides.partial_period_behaviors[].type`, `V2.Billing.IntentAction.subscribe.pricing_plan_subscription_details.overrides.partial_period_behaviors[].type`, `V2\Billing\Intent.create().$params.action.deactivate.pricing_plan_subscription_detail.override.partial_period_behavior.type`, `V2\Billing\Intent.create().$params.action.modify.pricing_plan_subscription_detail.override.partial_period_behavior.type`, and `V2\Billing\Intent.create().$params.action.subscribe.pricing_plan_subscription_detail.override.partial_period_behavior.type` from `literal('license_fee')` to `enum('license_fee'|'recurring_credit_grant')`
  * Add support for `service_cycle` on `V2.Billing.LicenseFee` and `V2.Billing.RateCard`
  * ⚠️ Remove support for `latest_version` on `V2.Billing.LicenseFee`, `V2.Billing.PricingPlan`, and `V2.Billing.RateCard`
  * ⚠️ Remove support for `service_interval_count` and `service_interval` on `V2.Billing.LicenseFee` and `V2.Billing.RateCard`
  * ⚠️ Change type of `V2.Billing.LicenseFee.transform_quantity.divide_by`, `V2.Billing.LicenseFeeVersion.transform_quantity.divide_by`, `V2.Billing.RateCardRate.transform_quantity.divide_by`, `V2\Billing\LicenseFee.create().$params.transform_quantity.divide_by`, `V2\Billing\LicenseFee.update().$params.transform_quantity.divide_by`, and `V2\Billing\RateCardRate.create().$params.transform_quantity.divide_by` from `longInteger` to `int64_string`
  * Add support for `discount_details` and `pricing_plan_component_details` on `V2.Billing.PricingPlanSubscription`
  * Add support for new value `crypto_wallets` on enums `V2.Core.Account.future_requirements.entries[].impact.restricts_capabilities[].capability` and `V2.Core.Account.requirements.entries[].impact.restricts_capabilities[].capability`
  * ⚠️ Remove support for value `crypto` from enums `V2.Core.Account.future_requirements.entries[].impact.restricts_capabilities[].capability` and `V2.Core.Account.requirements.entries[].impact.restricts_capabilities[].capability`
  * Add support for `balance_by_funds_type` on `V2.MoneyManagement.FinancialAccount.payments`
  * Add support for new value `next_day_payout_fee` on enum `V2.MoneyManagement.OutboundPaymentQuote.estimated_fees[].type`
  * Add support for `treasury_transaction_entry` on `V2.MoneyManagement.TransactionEntry`
  * Add support for `treasury_credit_reversal`, `treasury_debit_reversal`, `treasury_inbound_transfer`, `treasury_issuing_authorization`, `treasury_outbound_payment`, `treasury_outbound_transfer`, `treasury_received_credit`, and `treasury_received_debit` on `V2.MoneyManagement.Transaction.flow` and `V2.MoneyManagement.TransactionEntry.transaction_details.flow`
  * Add support for new values `treasury_credit_reversal`, `treasury_debit_reversal`, `treasury_inbound_transfer`, `treasury_issuing_authorization`, `treasury_other`, `treasury_outbound_payment`, `treasury_outbound_transfer`, `treasury_received_credit`, and `treasury_received_debit` on enums `V2.MoneyManagement.Transaction.flow.type` and `V2.MoneyManagement.TransactionEntry.transaction_details.flow.type`
  * Add support for `treasury_transaction` on `V2.MoneyManagement.Transaction`
  * Add support for new value `no_valid_payment_method` on enum `V2.Payments.OffSessionPayment.failure_reason`
  * Add support for `metadata` on `V2.Payments.SettlementAllocationIntentSplit`
  * ⚠️ Change type of `V2.Reporting.ReportRun.result.file.size` from `longInteger` to `int64_string`
  * Add support for `statement_descriptor` on `V2\MoneyManagement\OutboundPayment.create().$params` and `V2\MoneyManagement\OutboundTransfer.create().$params`
  * Add support for `include` on `V2\Billing\Intent.create().$params`, `V2\Billing\Intent.reserve().$params`, `V2\Billing\PricingPlanSubscription.all().$params`, `V2\Billing\PricingPlanSubscription.retrieve().$params`, `V2\MoneyManagement\FinancialAccount.all().$params`, and `V2\MoneyManagement\FinancialAccount.retrieve().$params`
  * Add support for event notifications `V1AccountSignalsIncludingDelinquencyCreatedEvent`, `V2CoreAccountSignalsFraudulentWebsiteReadyEvent`, and `V2SignalsAccountSignalFraudulentMerchantReadyEvent`
* [#2040](https://github.com/stripe/stripe-php/pull/2040) Merge to private-preview

## 20.0.0 - 2026-03-25

This release changes the pinned API version to `2026-03-25.dahlia` and contains breaking changes (prefixed with ⚠️ below). There's also a [detailed migration guide](https://github.com/stripe/stripe-php/wiki/Migration-guide-for-v20) to simplify your upgrade process.

Please review details for the breaking changes and alternatives in the [Stripe API changelog](https://docs.stripe.com/changelog/dahlia) before upgrading.

* ⚠️ **Breaking change:** [#2038](https://github.com/stripe/stripe-php/pull/2038) Drop support for PHP < 7.2. This is also the **last major version to support PHP 7.2 and 7.3**. Please upgrade to 7.4+ before September 2026. See the [versioning policy](https://docs.stripe.com/sdks/versioning?lang=php#stripe-sdk-language-version-support-policy) for more information.
* ⚠️ **Breaking change:** [#2042](https://github.com/stripe/stripe-php/pull/2042) Preserve null values in v2 JSON request bodies
  - The SDK now preserves and sends `null` when set in V2 API metadata and params, enabling you to clear metadata entries and some unsettable properties for V2 APIs.
  - ⚠️ The `Util::objectsToIds()` method now has a required `$serializeNull` parameter to indicate if null values set in the object should be output in the resulting hash. This is relevant for V2 POST APIs to let callers clear emptyable values.  
* [#1917](https://github.com/stripe/stripe-php/pull/1917) Avoid using func_get_args
* [#2011](https://github.com/stripe/stripe-php/pull/2011) Ensure that `previous_attributes` is always an instance of `StripeObject`
* [#2033](https://github.com/stripe/stripe-php/pull/2033) Add runtime support for V2 int64 string-encoded fields
  
### ⚠️ Breaking changes due to changes in the Stripe API

* [#2041](https://github.com/stripe/stripe-php/pull/2041) ⚠️ Throw an error when using the wrong webhook parsing method
* Generated changes from [#2046](https://github.com/stripe/stripe-php/pull/2046), [#2044](https://github.com/stripe/stripe-php/pull/2044), [#2025](https://github.com/stripe/stripe-php/pull/2025)
  * Add support for `upi_payments` on `Account.capabilities`, `Account.create().$params.capability`, and `Account.update().$params.capability`
  * Add support for `upi` on `Charge.payment_method_details`, `Checkout.Session.payment_method_options`, `Checkout\Session.create().$params.payment_method_option`, `ConfirmationToken.create().$params.payment_method_datum`, `ConfirmationToken.payment_method_preview`, `Mandate.payment_method_details`, `PaymentAttemptRecord.payment_method_details`, `PaymentIntent.confirm().$params.payment_method_datum`, `PaymentIntent.confirm().$params.payment_method_option`, `PaymentIntent.create().$params.payment_method_datum`, `PaymentIntent.create().$params.payment_method_option`, `PaymentIntent.payment_method_options`, `PaymentIntent.update().$params.payment_method_datum`, `PaymentIntent.update().$params.payment_method_option`, `PaymentMethod.create().$params`, `PaymentMethodConfiguration.create().$params`, `PaymentMethodConfiguration.update().$params`, `PaymentMethodConfiguration`, `PaymentMethod`, `PaymentRecord.payment_method_details`, `SetupAttempt.payment_method_details`, `SetupIntent.confirm().$params.payment_method_datum`, `SetupIntent.confirm().$params.payment_method_option`, `SetupIntent.create().$params.payment_method_datum`, `SetupIntent.create().$params.payment_method_option`, `SetupIntent.payment_method_options`, `SetupIntent.update().$params.payment_method_datum`, and `SetupIntent.update().$params.payment_method_option`
  * Add support for new value `tempo` on enums `Charge.payment_method_details.crypto.network`, `PaymentAttemptRecord.payment_method_details.crypto.network`, and `PaymentRecord.payment_method_details.crypto.network`
  * Add support for `integration_identifier` on `Checkout.Session` and `Checkout\Session.create().$params`
  * Add support for `crypto` on `Checkout\Session.create().$params.payment_method_option`
  * Add support for `pending_invoice_item_interval` on `Checkout\Session.create().$params.subscription_datum`
  * Add support for new values `elements`, `embedded_page`, `form`, and `hosted_page` on enum `Checkout.Session.ui_mode`
  * Add support for new value `marine_carbon_removal` on enum `Climate.Supplier.removal_pathway`
  * Add support for new value `upi` on enums `ConfirmationToken.payment_method_preview.type` and `PaymentMethod.type`
  * Add support for `metadata` on `CreditNote.create().$params.line`, `CreditNote.preview().$params.line`, `CreditNote.preview_lines().$params.line`, and `CreditNoteLineItem`
  * Add support for `quantity_decimal` on `Invoice.add_lines().$params.line`, `Invoice.create_preview().$params.invoice_item`, `Invoice.update_lines().$params.line`, `InvoiceItem.create().$params`, `InvoiceItem.update().$params`, `InvoiceItem`, `InvoiceLineItem.update().$params`, and `InvoiceLineItem`
  * ⚠️ Add support for `level` on `Issuing\Authorization.create().$params.risk_assessment.card_testing_risk` and `Issuing\Authorization.create().$params.risk_assessment.merchant_dispute_risk`
  * ⚠️ Remove support for `risk_level` on `Issuing\Authorization.create().$params.risk_assessment.card_testing_risk` and `Issuing\Authorization.create().$params.risk_assessment.merchant_dispute_risk`
  * Add support for `lifecycle_controls` on `Issuing.Card` and `Issuing\Card.create().$params`
  * ⚠️ Change type of `Issuing.Token.network_data.visa.card_reference_id` from `string` to `nullable(string)`
  * ⚠️ Change type of `PaymentAttemptRecord.payment_method_details.card.brand` and `PaymentRecord.payment_method_details.card.brand` from `enum` to `nullable(enum)`
  * ⚠️ Change type of `PaymentAttemptRecord.payment_method_details.card.exp_month` and `PaymentRecord.payment_method_details.card.exp_month` from `longInteger` to `nullable(longInteger)`
  * ⚠️ Change type of `PaymentAttemptRecord.payment_method_details.card.exp_year` and `PaymentRecord.payment_method_details.card.exp_year` from `longInteger` to `nullable(longInteger)`
  * ⚠️ Change type of `PaymentAttemptRecord.payment_method_details.card.funding` and `PaymentRecord.payment_method_details.card.funding` from `enum('credit'|'debit'|'prepaid'|'unknown')` to `nullable(enum('credit'|'debit'|'prepaid'|'unknown'))`
  * ⚠️ Change type of `PaymentAttemptRecord.payment_method_details.card.last4` and `PaymentRecord.payment_method_details.card.last4` from `string` to `nullable(string)`
  * ⚠️ Change type of `PaymentAttemptRecord.payment_method_details.card.moto` and `PaymentRecord.payment_method_details.card.moto` from `boolean` to `nullable(boolean)`
  * Add support for `cryptogram`, `electronic_commerce_indicator`, `exemption_indicator_applied`, and `exemption_indicator` on `PaymentAttemptRecord.payment_method_details.card.three_d_secure` and `PaymentRecord.payment_method_details.card.three_d_secure`
  * Add support for new value `upi` on enums `PaymentIntent.excluded_payment_method_types` and `SetupIntent.excluded_payment_method_types`
  * Add support for `upi_handle_redirect_or_display_qr_code` on `PaymentIntent.next_action` and `SetupIntent.next_action`
  * Add support for new value `upi` on enum `PaymentLink.payment_method_types`
  * Add support for `recommended_action` and `signals` on `Radar.PaymentEvaluation`
  * ⚠️ Remove support for `insights` on `Radar.PaymentEvaluation`
  * Add support for new value `crypto_fingerprint` on enum `Radar.ValueList.item_type`
  * Add support for new value `canceled_by_retention_policy` on enum `Subscription.cancellation_details.reason`
  * ⚠️ Change type of `V2.Core.EventDestination.events_from` from `enum('other_accounts'|'self')` to `string`
  * Add support for error code `service_period_coupon_with_metered_tiered_item_unsupported` on `Invoice.last_finalization_error`, `PaymentIntent.last_payment_error`, `SetupAttempt.setup_error`, `SetupIntent.last_setup_error`, and `StripeError`

## 19.5.0-alpha.4 - 2026-03-18
* [#2035](https://github.com/stripe/stripe-php/pull/2035) Update generated code for private-preview
  * Add support for `simulate_crypto_deposit` test helper method on resource `PaymentIntent`
  * Add support for `deposit_options` and `mode` on `PaymentIntent.confirm().$params.payment_method_option.crypto`, `PaymentIntent.create().$params.payment_method_option.crypto`, `PaymentIntent.payment_method_options.crypto`, and `PaymentIntent.update().$params.payment_method_option.crypto`
  * Add support for `crypto_display_details` on `PaymentIntent.next_action`
* [#2031](https://github.com/stripe/stripe-php/pull/2031) Update generated code for private-preview
  * Add support for new resources `Orchestration.PaymentAttempt` and `Radar.CustomerEvaluation`
  * Add support for `retrieve` method on resource `Orchestration.PaymentAttempt`
  * Add support for `create` and `update` methods on resource `Radar.CustomerEvaluation`
  * Add support for `approve` method on resource `Checkout.Session`
  * Add support for `report_authenticated`, `report_canceled`, `report_failed`, `report_guaranteed`, `report_informational`, and `report_refund` methods on resource `PaymentAttemptRecord`
  * Add support for `create_us_paper_check_on_application` on `AccountSession.create().$params.component.check_scanning.feature`
  * ⚠️ Change `AccountSignals.delinquency` to be optional
  * Add support for `approval_method` on `Checkout.Session` and `Checkout\Session.create().$params`
  * Add support for `current_attempt` on `Checkout.Session`
  * Add support for `selected_fulfillment_option_overrides` on `DelegatedCheckout\RequestedSession.update().$params.fulfillment_detail`
  * Add support for `pricing_plan_subscription_details` on `InvoiceItem.parent` and `InvoiceLineItem.parent`
  * ⚠️ Remove support for `license_fee_subscription_details` on `InvoiceItem.parent` and `InvoiceLineItem.parent`
  * ⚠️ Remove support for `pricing_plan_subscription` and `pricing_plan_version` on `InvoiceItem.parent.rate_card_subscription_details` and `InvoiceLineItem.parent.rate_card_subscription_details`
  * Add support for new value `pricing_plan_subscription_details` on enum `InvoiceItem.parent.type`
  * ⚠️ Remove support for value `license_fee_subscription_details` from enum `InvoiceItem.parent.type`
  * Add support for new value `discounts` on enum `InvoiceItem.frozen_fields`
  * Add support for new value `pricing_plan_subscription_details` on enum `InvoiceLineItem.parent.type`
  * ⚠️ Remove support for value `license_fee_subscription_details` from enum `InvoiceLineItem.parent.type`
  * Add support for `token_details` on `Issuing.Authorization`
  * Add support for `failure_code` on `PaymentRecord.report_payment().$params.failed`, `PaymentRecord.report_payment_attempt().$params.failed`, and `PaymentRecord.report_payment_attempt_failed().$params`
  * Change `PaymentRecord.report_payment_attempt_canceled().$params.canceled_at` to be optional
  * Change `PaymentRecord.report_payment_attempt_failed().$params.failed_at` to be optional
  * Change `PaymentRecord.report_payment_attempt_guaranteed().$params.guaranteed_at` to be optional
  * Change `PaymentRecord.report_refund().$params.refunded` to be optional
  * ⚠️ Change `Radar\IssuingAuthorizationEvaluation.create().$params.card_detail.bin_country` to be required
  * Add support for `recurring_interval` on `SharedPayment\GrantedToken.create().$params.usage_limit`
  * Change `SharedPayment\GrantedToken.create().$params.usage_limit.expires_at` to be optional
  * Add support for `home_rule_tax` on `Tax.Registration.country_options.us` and `Tax\Registration.create().$params.country_option.me`
  * Add support for new value `home_rule_tax` on enum `Tax.Registration.country_options.us.type`

## 19.5.0-alpha.3 - 2026-03-11
* [#2026](https://github.com/stripe/stripe-php/pull/2026) Update generated code for private-preview
  * Add support for new resource `Radar.IssuingAuthorizationEvaluation`
  * Add support for `create` method on resource `Radar.IssuingAuthorizationEvaluation`
  * Add support for new value `fee_credits` on enum `BalanceTransaction.balance_type`
  * ⚠️ Rename `affiliate_attributions` to `affiliate_attribution` on `DelegatedCheckout\RequestedSession.confirm().$params` and `DelegatedCheckout\RequestedSession.create().$params`
  * Add support for `amount_to_counter` on `Dispute`
  * Add support for `frozen_fields` on `InvoiceItem`
  * Add support for new value `next_billing_period_start` on enum `V2.Billing.IntentAction.apply.effective_at.type`
  * Add support for `consumer` on `V2.Core.Account.configuration.card_creator.capabilities`, `V2.Core.Account.identity.attestations.terms_of_service.card_creator`, `V2\Core\Account.create().$params.configuration.card_creator.capability`, `V2\Core\Account.create().$params.identity.attestation.terms_of_service.card_creator`, `V2\Core\Account.update().$params.configuration.card_creator.capability`, and `V2\Core\Account.update().$params.identity.attestation.terms_of_service.card_creator`
  * Add support for `fifth_third` on `V2.Core.Account.configuration.card_creator.capabilities.commercial`, `V2.Core.Account.identity.attestations.terms_of_service.card_creator.commercial`, `V2\Core\Account.create().$params.configuration.card_creator.capability.commercial`, `V2\Core\Account.create().$params.identity.attestation.terms_of_service.card_creator.commercial`, `V2\Core\Account.update().$params.configuration.card_creator.capability.commercial`, and `V2\Core\Account.update().$params.identity.attestation.terms_of_service.card_creator.commercial`
  * Add support for `prepaid_card` on `V2.Core.Account.configuration.card_creator.capabilities.commercial.cross_river_bank`, `V2.Core.Account.identity.attestations.terms_of_service.card_creator.commercial.cross_river_bank`, `V2\Core\Account.create().$params.configuration.card_creator.capability.commercial.cross_river_bank`, `V2\Core\Account.create().$params.identity.attestation.terms_of_service.card_creator.commercial.cross_river_bank`, `V2\Core\Account.update().$params.configuration.card_creator.capability.commercial.cross_river_bank`, and `V2\Core\Account.update().$params.identity.attestation.terms_of_service.card_creator.commercial.cross_river_bank`
  * Add support for new values `commercial.cross_river_bank.prepaid_card`, `commercial.fifth_third.charge_card`, `consumer.celtic.revolving_credit_card`, `consumer.cross_river_bank.prepaid_card`, and `consumer.lead.prepaid_card` on enums `V2.Core.Account.future_requirements.entries[].impact.restricts_capabilities[].capability` and `V2.Core.Account.requirements.entries[].impact.restricts_capabilities[].capability`
  * Add support for `payment_method_data` on `V2\Payments\OffSessionPayment.create().$params`
  * Change `V2\Payments\OffSessionPayment.create().$params.payment_method` to be optional
  * Add support for new values `commercial.cross_river_bank.prepaid_card`, `commercial.fifth_third.charge_card`, `consumer.celtic.revolving_credit_card`, `consumer.cross_river_bank.prepaid_card`, and `consumer.lead.prepaid_card` on enum `EventsV2CoreAccountIncludingConfigurationCardCreatorCapabilityStatusUpdatedEvent.updated_capability`

## 19.5.0-alpha.2 - 2026-03-04
This release changes the pinned API version to `2026-03-04.preview`.

* [#2021](https://github.com/stripe/stripe-php/pull/2021) Update generated code for private-preview
  * Add support for new resources `Billing.AlertRecovered` and `Profile`
  * Add support for `reauthorize` method on resource `PaymentIntent`
  * Add support for `settings` on `QuoteLine.actions[].add_discount`, `QuoteLine.actions[].add_item.discounts[]`, `QuoteLine.actions[].set_discounts[]`, `QuoteLine.actions[].set_items[].discounts[]`, `QuotePreviewSubscriptionSchedule.phases[].discounts[]`, `QuotePreviewSubscriptionSchedule.phases[].items[].discounts[]`, `SubscriptionSchedule.phases[].discounts[]`, and `SubscriptionSchedule.phases[].items[].discounts[]`
  * Add support for `smart_disputes` on `Account.create().$params.setting`, `Account.settings`, `Account.update().$params.setting`, `V2.Core.Account.configuration.merchant`, `V2\Core\Account.create().$params.configuration.merchant`, and `V2\Core\Account.update().$params.configuration.merchant`
  * Add support for `email_customers_on_successful_payment` on `Account.create().$params.setting.payment`, `Account.settings.payments`, and `Account.update().$params.setting.payment`
  * Add support for `balance_update_details` on `Billing.CreditBalanceSummary.balances[]`
  * Add support for `reauthorization` and `reauthorize_before` on `Charge.payment_method_details.card_present`, `Charge.payment_method_details.card`, `ConfirmationToken.payment_method_preview.card.generated_from.payment_method_details.card_present`, `PaymentAttemptRecord.payment_method_details.card_present`, `PaymentMethod.card.generated_from.payment_method_details.card_present`, and `PaymentRecord.payment_method_details.card_present`
  * Add support for `location` and `reader` on `Charge.payment_method_details.card_present`, `Charge.payment_method_details.interac_present`, `ConfirmationToken.payment_method_preview.card.generated_from.payment_method_details.card_present`, `PaymentAttemptRecord.payment_method_details.card_present`, `PaymentAttemptRecord.payment_method_details.interac_present`, `PaymentMethod.card.generated_from.payment_method_details.card_present`, `PaymentRecord.payment_method_details.card_present`, and `PaymentRecord.payment_method_details.interac_present`
  * Add support for `managed_payments` on `Checkout.Session`, `Checkout\Session.create().$params`, `PaymentIntent`, `SetupIntent`, and `Subscription`
  * Add support for new value `lk_vat` on enums `Checkout.Session.collected_information.tax_ids[].type`, `Checkout.Session.customer_details.tax_ids[].type`, `Invoice.customer_tax_ids[].type`, `Order.tax_details.tax_ids[].type`, `QuotePreviewInvoice.customer_tax_ids[].type`, `Tax.Calculation.customer_details.tax_ids[].type`, `Tax.Transaction.customer_details.tax_ids[].type`, and `TaxId.type`
  * Add support for `digital` on `DelegatedCheckout.RequestedSession.fulfillment_details.fulfillment_options[]`, `DelegatedCheckout.RequestedSession.fulfillment_details.selected_fulfillment_option`, and `DelegatedCheckout\RequestedSession.update().$params.fulfillment_detail.selected_fulfillment_option`
  * Change `DelegatedCheckout\RequestedSession.update().$params.fulfillment_detail.selected_fulfillment_option.shipping` to be optional
  * Add support for `affiliate_attributions` on `DelegatedCheckout.RequestedSession`, `DelegatedCheckout\RequestedSession.confirm().$params`, and `DelegatedCheckout\RequestedSession.create().$params`
  * Add support for `fulfillment_type` on `DelegatedCheckout.RequestedSession.line_item_details[]`
  * Add support for `marketplace_seller_details`, `network_profile`, `privacy_notice_url`, `return_policy_url`, `store_policy_url`, and `terms_of_service_url` on `DelegatedCheckout.RequestedSession.seller_details`
  * Add support for `amount_to_counter` on `Dispute.update().$params`
  * Add support for new values `reserve.hold.created`, `reserve.hold.updated`, `reserve.plan.created`, `reserve.plan.disabled`, `reserve.plan.expired`, `reserve.plan.updated`, and `reserve.release.created` on enum `Event.type`
  * Add support for new values `terminal_wifi_certificate` and `terminal_wifi_private_key` on enum `File.purpose`
  * Add support for new value `pay_by_bank` on enums `Invoice.payment_settings.payment_method_types`, `QuotePreviewInvoice.payment_settings.payment_method_types`, and `Subscription.payment_settings.payment_method_types`
  * Add support for `display_name` and `service_user_number` on `Mandate.payment_method_details.bacs_debit`
  * ⚠️ Change type of `PaymentAttemptRecord.payment_method_details.boleto.tax_id` and `PaymentRecord.payment_method_details.boleto.tax_id` from `string` to `nullable(string)`
  * Change type of `PaymentAttemptRecord.payment_method_details.us_bank_account.expected_debit_date` and `PaymentRecord.payment_method_details.us_bank_account.expected_debit_date` from `nullable(string)` to `string`
  * Add support for `request_reauthorization` on `PaymentIntent.confirm().$params.payment_method_option.card_present`, `PaymentIntent.confirm().$params.payment_method_option.card`, `PaymentIntent.create().$params.payment_method_option.card_present`, `PaymentIntent.create().$params.payment_method_option.card`, `PaymentIntent.payment_method_options.card_present`, `PaymentIntent.payment_method_options.card`, `PaymentIntent.update().$params.payment_method_option.card_present`, and `PaymentIntent.update().$params.payment_method_option.card`
  * Add support for `transaction_purpose` on `PaymentIntent.confirm().$params.payment_method_option.us_bank_account`, `PaymentIntent.create().$params.payment_method_option.us_bank_account`, `PaymentIntent.payment_method_options.us_bank_account`, and `PaymentIntent.update().$params.payment_method_option.us_bank_account`
  * Add support for new value `requires_reauthorization` on enum `PaymentIntent.status`
  * Add support for `optional_items` on `PaymentLink.update().$params`
  * Add support for new value `billing_schedules_invalid` on enum `Quote.status_details.stale.last_reason.type`
  * ⚠️ Remove support for `card_issuer_decline` on `Radar.PaymentEvaluation.insights`
  * Add support for `payment_behavior` on `SubscriptionItem.delete().$params`
  * Add support for `billing_cycle_anchor` on `Subscription.trial_settings.end_behavior`
  * Add support for `lk` on `Tax.Registration.country_options` and `Tax\Registration.create().$params.country_option`
  * Add support for `cellular` and `stripe_s710` on `Terminal.Configuration`, `Terminal\Configuration.create().$params`, and `Terminal\Configuration.update().$params`
  * Add support for new values `simulated_stripe_s710` and `stripe_s710` on enum `Terminal.Reader.device_type`
  * Add support for new values `ar_bank_account`, `bt_bank_account`, `co_bank_account`, `cr_bank_account`, `do_bank_account`, `gt_bank_account`, `md_bank_account`, `mk_bank_account`, `mo_bank_account`, `mz_bank_account`, `pe_bank_account`, `pk_bank_account`, `tw_bank_account`, and `uz_bank_account` on enums `V2.Account.configuration.recipient_data.default_outbound_destination.type` and `V2.Core.Account.configuration.recipient.default_outbound_destination.type`
  * Add support for `recipient_onboarding` and `recipient_update` on `V2.Core.AccountLink.use_case` and `V2\Core\AccountLink.create().$params.use_case`
  * Add support for new values `recipient_onboarding` and `recipient_update` on enum `V2.Core.AccountLink.use_case.type`
  * Add support for `consumer` on `V2.Core.Account.configuration.storer.capabilities`, `V2\Core\Account.create().$params.configuration.storer.capability`, and `V2\Core\Account.update().$params.configuration.storer.capability`
  * Add support for new value `consumer.holds_currencies.usd` on enums `V2.Core.Account.future_requirements.entries[].impact.restricts_capabilities[].capability` and `V2.Core.Account.requirements.entries[].impact.restricts_capabilities[].capability`
  * Add support for `funds_usage_type` on `V2.MoneyManagement.FinancialAccount.storage` and `V2\MoneyManagement\FinancialAccount.create().$params.storage`
  * Add support for `purpose` on `V2.MoneyManagement.OutboundPayment` and `V2\MoneyManagement\OutboundPayment.create().$params`
  * Add support for `branch_number` and `swift_code` on `V2.MoneyManagement.PayoutMethod.bank_account`
  * Add support for new values `dispute`, `inbound_payment_failure`, `inbound_payment`, `india_mdr_processing_fee`, `payment_method_passthrough_fee`, `refund`, and `tax_withholding` on enums `V2.MoneyManagement.Transaction.category` and `V2.MoneyManagement.TransactionEntry.transaction_details.category`
  * ⚠️ Remove support for values `charge_failure` and `charge` from enums `V2.MoneyManagement.Transaction.category` and `V2.MoneyManagement.TransactionEntry.transaction_details.category`
  * ⚠️ Change `V2.MoneyManagement.Transaction.flow` and `V2.MoneyManagement.TransactionEntry.transaction_details.flow` to be optional
  * Add support for new value `consumer.holds_currencies.usd` on enum `EventsV2CoreAccountIncludingConfigurationStorerCapabilityStatusUpdatedEvent.updated_capability`
  * Add support for snapshot event `BILLING_ALERT_RECOVERED` with resource `Billing.AlertRecovered`
  * Add support for snapshot events `RESERVE_HOLD_CREATED` and `RESERVE_HOLD_UPDATED` with resource `Reserve.Hold`
  * Add support for snapshot events `RESERVE_PLAN_CREATED`, `RESERVE_PLAN_DISABLED`, `RESERVE_PLAN_EXPIRED`, and `RESERVE_PLAN_UPDATED` with resource `Reserve.Plan`
  * Add support for snapshot event `RESERVE_RELEASE_CREATED` with resource `Reserve.Release`
  * Add support for event notification `V2BillingRateCardCustomPricingUnitOverageRateCreatedEvent` with related object `V2.Billing.RateCardCustomPricingUnitOverageRate`
  * Add support for event notifications `V2IamStripeAccessGrantApprovedEvent`, `V2IamStripeAccessGrantCanceledEvent`, `V2IamStripeAccessGrantDeniedEvent`, `V2IamStripeAccessGrantRemovedEvent`, `V2IamStripeAccessGrantRequestedEvent`, and `V2IamStripeAccessGrantUpdatedEvent`
  * Add support for error codes `storer_capability_missing` and `storer_capability_not_active` on `Invoice.last_finalization_error`, `PaymentIntent.last_payment_error`, `QuotePreviewInvoice.last_finalization_error`, `SetupAttempt.setup_error`, `SetupIntent.last_setup_error`, and `StripeError`

## 19.5.0-alpha.1 - 2026-02-25
This release uses the API version `2026-01-28.preview`.

* [#2013](https://github.com/stripe/stripe-php/pull/2013) Update generated code for private-preview
  * Add support for new resource `AccountSignals`
  * Add support for `retrieve` method on resource `AccountSignals`
  * Add support for `aggregation_period`, `group_by`, and `triggered_at` on `Billing.AlertTriggered`
  * Add support for `external_account_collection` on `AccountLink.create().$params.collection_option`
  * Add support for `funding_source` on `ApplicationFee`
  * Change `DelegatedCheckout\RequestedSession.confirm().$params.payment_method_datum.billing_detail.address.line1`, `DelegatedCheckout\RequestedSession.create().$params.fulfillment_detail.address.line1`, `DelegatedCheckout\RequestedSession.create().$params.payment_method_datum.billing_detail.address.line1`, `DelegatedCheckout\RequestedSession.update().$params.fulfillment_detail.address.line1`, and `DelegatedCheckout\RequestedSession.update().$params.payment_method_datum.billing_detail.address.line1` to be optional
  * Add support for `hosted` and `ui_mode` on `FinancialConnections.Session` and `FinancialConnections\Session.create().$params`
  * Add support for `url` on `FinancialConnections.Session`
  * Add support for `billing_cycle_anchor` on `Subscription.create().$params.trial_setting.end_behavior` and `Subscription.update().$params.trial_setting.end_behavior`

## 19.4.1 - 2026-03-06
* [#2024](https://github.com/stripe/stripe-php/pull/2024) Add Stripe-Request-Trigger header
* [#2022](https://github.com/stripe/stripe-php/pull/2022) Add agent information to UserAgent

## 19.4.0 - 2026-02-25
This release changes the pinned API version to `2026-02-25.clover`.

* [#2016](https://github.com/stripe/stripe-php/pull/2016) Update generated code
  * Add support for new resources `Reserve.Hold`, `Reserve.Plan`, and `Reserve.Release`
  * Add support for `location` and `reader` on `Charge.payment_method_details.card_present`, `Charge.payment_method_details.interac_present`, `ConfirmationToken.payment_method_preview.card.generated_from.payment_method_details.card_present`, `PaymentAttemptRecord.payment_method_details.card_present`, `PaymentAttemptRecord.payment_method_details.interac_present`, `PaymentMethod.card.generated_from.payment_method_details.card_present`, `PaymentRecord.payment_method_details.card_present`, and `PaymentRecord.payment_method_details.interac_present`
  * Add support for new value `lk_vat` on enums `Checkout.Session.customer_details.tax_ids[].type`, `Invoice.customer_tax_ids[].type`, `Tax.Calculation.customer_details.tax_ids[].type`, `Tax.Transaction.customer_details.tax_ids[].type`, and `TaxId.type`
  * Add support for new values `reserve.hold.created`, `reserve.hold.updated`, `reserve.plan.created`, `reserve.plan.disabled`, `reserve.plan.expired`, `reserve.plan.updated`, and `reserve.release.created` on enum `Event.type`
  * Add support for new values `terminal_wifi_certificate` and `terminal_wifi_private_key` on enum `File.purpose`
  * Add support for new value `pay_by_bank` on enums `Invoice.payment_settings.payment_method_types` and `Subscription.payment_settings.payment_method_types`
  * Add support for `display_name` and `service_user_number` on `Mandate.payment_method_details.bacs_debit`
  * Change type of `PaymentAttemptRecord.payment_method_details.boleto.tax_id` and `PaymentRecord.payment_method_details.boleto.tax_id` from `string` to `nullable(string)`
  * Change type of `PaymentAttemptRecord.payment_method_details.us_bank_account.expected_debit_date` and `PaymentRecord.payment_method_details.us_bank_account.expected_debit_date` from `nullable(string)` to `string`
  * Add support for `transaction_purpose` on `PaymentIntent.confirm().$params.payment_method_option.us_bank_account`, `PaymentIntent.create().$params.payment_method_option.us_bank_account`, `PaymentIntent.payment_method_options.us_bank_account`, and `PaymentIntent.update().$params.payment_method_option.us_bank_account`
  * Add support for `optional_items` on `PaymentLink.update().$params`
  * Remove support for unused `card_issuer_decline` on `Radar.PaymentEvaluation.insights`
  * Add support for `payment_behavior` on `SubscriptionItem.delete().$params`
  * Add support for `lk` on `Tax.Registration.country_options` and `Tax\Registration.create().$params.country_option`
  * Add support for `cellular` and `stripe_s710` on `Terminal.Configuration`, `Terminal\Configuration.create().$params`, and `Terminal\Configuration.update().$params`
  * Add support for new values `simulated_stripe_s710` and `stripe_s710` on enum `Terminal.Reader.device_type`
  * Add support for snapshot events `RESERVE_HOLD_CREATED` and `RESERVE_HOLD_UPDATED` with resource `Reserve.Hold`
  * Add support for snapshot events `RESERVE_PLAN_CREATED`, `RESERVE_PLAN_DISABLED`, `RESERVE_PLAN_EXPIRED`, and `RESERVE_PLAN_UPDATED` with resource `Reserve.Plan`
  * Add support for snapshot event `RESERVE_RELEASE_CREATED` with resource `Reserve.Release`
  * Add support for error codes `storer_capability_missing` and `storer_capability_not_active` on `Invoice.last_finalization_error`, `PaymentIntent.last_payment_error`, `SetupAttempt.setup_error`, `SetupIntent.last_setup_error`, and `StripeError`

## 19.4.0-alpha.4 - 2026-02-19
* [#2010](https://github.com/stripe/stripe-php/pull/2010) Update generated code for private-preview
  * Add support for `spend_threshold` on `Billing.Alert` and `Billing\Alert.create().$params`
  * ⚠️ Add support for new value `spend_threshold` on enum `Billing.Alert.alert_type`
  * Add support for `invoice_item`, `proration_details`, `proration`, and `subscription` on `InvoiceLineItem.parent.schedule_details`
  * Add support for `custom` on `PaymentMethod.update().$params`
  * Add support for `payment_method_reference` and `usage` on `PaymentMethod.custom`
  * Add support for `outstanding_usage_through` and `unused_time_from` on `Subscription.pause().$params.bill_for`
  * ⚠️ Remove support for `outstanding_usage` and `unused_time` on `Subscription.pause().$params.bill_for`
  * ⚠️ Remove support for `payment_behavior` on `Subscription.resume().$params`

## 19.4.0-alpha.3 - 2026-02-11
* [#2008](https://github.com/stripe/stripe-php/pull/2008) Update generated code for private-preview
  * Add support for new resources `V2.Billing.CadenceSpendModifier`, `V2.Billing.OneTimeItem`, and `V2.Billing.RateCardCustomPricingUnitOverageRate`
  * Add support for `all`, `create`, `delete`, and `retrieve` methods on resource `V2.Billing.RateCardCustomPricingUnitOverageRate`
  * Add support for `all`, `create`, `retrieve`, and `update` methods on resource `V2.Billing.OneTimeItem`
  * Add support for `retrieve` method on resource `V2.Billing.CadenceSpendModifier`
  * Change `EventsV2CoreHealthFraudRateIncreasedEvent.impact.realized_fraud_amount.value`, `EventsV2CoreHealthIssuingAuthorizationRequestErrorsFiringEvent.impact.approved_amount.value`, `EventsV2CoreHealthIssuingAuthorizationRequestErrorsFiringEvent.impact.declined_amount.value`, `EventsV2CoreHealthIssuingAuthorizationRequestErrorsResolvedEvent.impact.approved_amount.value`, `EventsV2CoreHealthIssuingAuthorizationRequestErrorsResolvedEvent.impact.declined_amount.value`, `EventsV2CoreHealthIssuingAuthorizationRequestTimeoutFiringEvent.impact.approved_amount.value`, `EventsV2CoreHealthIssuingAuthorizationRequestTimeoutFiringEvent.impact.declined_amount.value`, `EventsV2CoreHealthIssuingAuthorizationRequestTimeoutResolvedEvent.impact.approved_amount.value`, `EventsV2CoreHealthIssuingAuthorizationRequestTimeoutResolvedEvent.impact.declined_amount.value`, `V2.Billing.ServiceAction.credit_grant.amount.monetary.value`, `V2.Billing.ServiceAction.credit_grant_per_tenant.amount.monetary.value`, `V2.Core.Account.identity.business_details.annual_revenue.amount.value`, `V2.Core.Account.identity.business_details.monthly_estimated_revenue.amount.value`, `V2.FinancialAddressGeneratedMicrodeposits.amounts[].value`, `V2.MoneyManagement.Adjustment.amount.value`, `V2.MoneyManagement.CurrencyConversion.from.amount.value`, `V2.MoneyManagement.CurrencyConversion.to.amount.value`, `V2.MoneyManagement.FinancialAccount.balance.available.value.value`, `V2.MoneyManagement.FinancialAccount.balance.inbound_pending.value.value`, `V2.MoneyManagement.FinancialAccount.balance.outbound_pending.value.value`, `V2.MoneyManagement.FinancialAccount.payments.starting_balance.available.value.value`, `V2.MoneyManagement.InboundTransfer.amount.value`, `V2.MoneyManagement.InboundTransfer.from.debited.value`, `V2.MoneyManagement.InboundTransfer.to.credited.value`, `V2.MoneyManagement.OutboundPayment.amount.value`, `V2.MoneyManagement.OutboundPayment.from.debited.value`, `V2.MoneyManagement.OutboundPayment.to.credited.value`, `V2.MoneyManagement.OutboundPaymentQuote.amount.value`, `V2.MoneyManagement.OutboundPaymentQuote.estimated_fees[].amount.value`, `V2.MoneyManagement.OutboundPaymentQuote.from.debited.value`, `V2.MoneyManagement.OutboundPaymentQuote.to.credited.value`, `V2.MoneyManagement.OutboundTransfer.amount.value`, `V2.MoneyManagement.OutboundTransfer.from.debited.value`, `V2.MoneyManagement.OutboundTransfer.to.credited.value`, `V2.MoneyManagement.ReceivedCredit.amount.value`, `V2.MoneyManagement.ReceivedCredit.external_amount.value`, `V2.MoneyManagement.ReceivedDebit.amount.value`, `V2.MoneyManagement.ReceivedDebit.card_spend.authorization.amount.value`, `V2.MoneyManagement.ReceivedDebit.card_spend.card_transactions[].amount.value`, `V2.MoneyManagement.ReceivedDebit.external_amount.value`, `V2.MoneyManagement.Transaction.amount.value`, `V2.MoneyManagement.Transaction.balance_impact.available.value`, `V2.MoneyManagement.Transaction.balance_impact.inbound_pending.value`, `V2.MoneyManagement.Transaction.balance_impact.outbound_pending.value`, `V2.MoneyManagement.TransactionEntry.balance_impact.available.value`, `V2.MoneyManagement.TransactionEntry.balance_impact.inbound_pending.value`, `V2.MoneyManagement.TransactionEntry.balance_impact.outbound_pending.value`, `V2.Payments.OffSessionPayment.amount_capturable.value`, `V2.Payments.OffSessionPayment.amount_requested.value`, `V2.Payments.SettlementAllocationIntent.amount.value`, `V2.Payments.SettlementAllocationIntentSplit.amount.value`, `V2\Billing\ServiceAction.create().$params.credit_grant.amount.monetary.value`, `V2\Billing\ServiceAction.create().$params.credit_grant_per_tenant.amount.monetary.value`, `V2\Core\Account.create().$params.identity.business_detail.annual_revenue.amount.value`, `V2\Core\Account.create().$params.identity.business_detail.monthly_estimated_revenue.amount.value`, `V2\Core\Account.update().$params.identity.business_detail.annual_revenue.amount.value`, `V2\Core\Account.update().$params.identity.business_detail.monthly_estimated_revenue.amount.value`, `V2\Core\AccountToken.create().$params.identity.business_detail.annual_revenue.amount.value`, `V2\Core\AccountToken.create().$params.identity.business_detail.monthly_estimated_revenue.amount.value`, `V2\FinancialAddressCreditSimulation.credit().$params.amount.value`, `V2\MoneyManagement\CurrencyConversion.create().$params.from.amount.value`, `V2\MoneyManagement\CurrencyConversion.create().$params.to.amount.value`, `V2\MoneyManagement\InboundTransfer.create().$params.amount.value`, `V2\MoneyManagement\OutboundPayment.create().$params.amount.value`, `V2\MoneyManagement\OutboundPaymentQuote.create().$params.amount.value`, `V2\MoneyManagement\OutboundTransfer.create().$params.amount.value`, `V2\Payments\OffSessionPayment.create().$params.amount.value`, `V2\Payments\SettlementAllocationIntent.create().$params.amount.value`, `V2\Payments\SettlementAllocationIntent.update().$params.amount.value`, and `V2\Payments\SettlementAllocationIntentSplit.create().$params.amount.value` to be required
  * Change `EventsV2CoreHealthFraudRateIncreasedEvent.impact.realized_fraud_amount.currency`, `EventsV2CoreHealthIssuingAuthorizationRequestErrorsFiringEvent.impact.approved_amount.currency`, `EventsV2CoreHealthIssuingAuthorizationRequestErrorsFiringEvent.impact.declined_amount.currency`, `EventsV2CoreHealthIssuingAuthorizationRequestErrorsResolvedEvent.impact.approved_amount.currency`, `EventsV2CoreHealthIssuingAuthorizationRequestErrorsResolvedEvent.impact.declined_amount.currency`, `EventsV2CoreHealthIssuingAuthorizationRequestTimeoutFiringEvent.impact.approved_amount.currency`, `EventsV2CoreHealthIssuingAuthorizationRequestTimeoutFiringEvent.impact.declined_amount.currency`, `EventsV2CoreHealthIssuingAuthorizationRequestTimeoutResolvedEvent.impact.approved_amount.currency`, `EventsV2CoreHealthIssuingAuthorizationRequestTimeoutResolvedEvent.impact.declined_amount.currency`, `V2.Billing.ServiceAction.credit_grant.amount.monetary.currency`, `V2.Billing.ServiceAction.credit_grant_per_tenant.amount.monetary.currency`, `V2.Core.Account.identity.business_details.annual_revenue.amount.currency`, `V2.Core.Account.identity.business_details.monthly_estimated_revenue.amount.currency`, `V2.FinancialAddressGeneratedMicrodeposits.amounts[].currency`, `V2.MoneyManagement.Adjustment.amount.currency`, `V2.MoneyManagement.CurrencyConversion.from.amount.currency`, `V2.MoneyManagement.CurrencyConversion.to.amount.currency`, `V2.MoneyManagement.FinancialAccount.balance.available.value.currency`, `V2.MoneyManagement.FinancialAccount.balance.inbound_pending.value.currency`, `V2.MoneyManagement.FinancialAccount.balance.outbound_pending.value.currency`, `V2.MoneyManagement.FinancialAccount.payments.starting_balance.available.value.currency`, `V2.MoneyManagement.InboundTransfer.amount.currency`, `V2.MoneyManagement.InboundTransfer.from.debited.currency`, `V2.MoneyManagement.InboundTransfer.to.credited.currency`, `V2.MoneyManagement.OutboundPayment.amount.currency`, `V2.MoneyManagement.OutboundPayment.from.debited.currency`, `V2.MoneyManagement.OutboundPayment.to.credited.currency`, `V2.MoneyManagement.OutboundPaymentQuote.amount.currency`, `V2.MoneyManagement.OutboundPaymentQuote.estimated_fees[].amount.currency`, `V2.MoneyManagement.OutboundPaymentQuote.from.debited.currency`, `V2.MoneyManagement.OutboundPaymentQuote.to.credited.currency`, `V2.MoneyManagement.OutboundTransfer.amount.currency`, `V2.MoneyManagement.OutboundTransfer.from.debited.currency`, `V2.MoneyManagement.OutboundTransfer.to.credited.currency`, `V2.MoneyManagement.ReceivedCredit.amount.currency`, `V2.MoneyManagement.ReceivedCredit.external_amount.currency`, `V2.MoneyManagement.ReceivedDebit.amount.currency`, `V2.MoneyManagement.ReceivedDebit.card_spend.authorization.amount.currency`, `V2.MoneyManagement.ReceivedDebit.card_spend.card_transactions[].amount.currency`, `V2.MoneyManagement.ReceivedDebit.external_amount.currency`, `V2.MoneyManagement.Transaction.amount.currency`, `V2.MoneyManagement.Transaction.balance_impact.available.currency`, `V2.MoneyManagement.Transaction.balance_impact.inbound_pending.currency`, `V2.MoneyManagement.Transaction.balance_impact.outbound_pending.currency`, `V2.MoneyManagement.TransactionEntry.balance_impact.available.currency`, `V2.MoneyManagement.TransactionEntry.balance_impact.inbound_pending.currency`, `V2.MoneyManagement.TransactionEntry.balance_impact.outbound_pending.currency`, `V2.Payments.OffSessionPayment.amount_capturable.currency`, `V2.Payments.OffSessionPayment.amount_requested.currency`, `V2.Payments.SettlementAllocationIntent.amount.currency`, `V2.Payments.SettlementAllocationIntentSplit.amount.currency`, `V2\Billing\ServiceAction.create().$params.credit_grant.amount.monetary.currency`, `V2\Billing\ServiceAction.create().$params.credit_grant_per_tenant.amount.monetary.currency`, `V2\Core\Account.create().$params.identity.business_detail.annual_revenue.amount.currency`, `V2\Core\Account.create().$params.identity.business_detail.monthly_estimated_revenue.amount.currency`, `V2\Core\Account.update().$params.identity.business_detail.annual_revenue.amount.currency`, `V2\Core\Account.update().$params.identity.business_detail.monthly_estimated_revenue.amount.currency`, `V2\Core\AccountToken.create().$params.identity.business_detail.annual_revenue.amount.currency`, `V2\Core\AccountToken.create().$params.identity.business_detail.monthly_estimated_revenue.amount.currency`, `V2\FinancialAddressCreditSimulation.credit().$params.amount.currency`, `V2\MoneyManagement\CurrencyConversion.create().$params.from.amount.currency`, `V2\MoneyManagement\CurrencyConversion.create().$params.to.amount.currency`, `V2\MoneyManagement\InboundTransfer.create().$params.amount.currency`, `V2\MoneyManagement\OutboundPayment.create().$params.amount.currency`, `V2\MoneyManagement\OutboundPaymentQuote.create().$params.amount.currency`, `V2\MoneyManagement\OutboundTransfer.create().$params.amount.currency`, `V2\Payments\OffSessionPayment.create().$params.amount.currency`, `V2\Payments\SettlementAllocationIntent.create().$params.amount.currency`, `V2\Payments\SettlementAllocationIntent.update().$params.amount.currency`, and `V2\Payments\SettlementAllocationIntentSplit.create().$params.amount.currency` to be required
  * Add support for `settlement_type` on `ApplicationFee`
  * Add support for `rate_card_custom_pricing_unit_overage_rate_details` on `InvoiceItem.pricing` and `InvoiceLineItem.pricing`
  * Add support for new value `rate_card_custom_pricing_unit_overage_rate_details` on enums `InvoiceItem.pricing.type` and `InvoiceLineItem.pricing.type`
  * Add support for `default_settings` on `Invoice.create_preview().$params.schedule_detail`
  * Change type of `Quote.update().$params.subscription_data_override.billing_schedules` from `emptyable(array(billing_schedules_update_specs))` to `array(billing_schedules_update_specs)`
  * Add support for `payment_behavior` on `Subscription.resume().$params`
  * Add support for `effective_at` and `spend_modifier_rule` on `V2.Billing.IntentAction.apply`, `V2.Billing.IntentAction.remove`, `V2\Billing\Intent.create().$params.action.apply`, and `V2\Billing\Intent.create().$params.action.remove`
  * Change type of `V2.Billing.IntentAction.apply.type`, `V2.Billing.IntentAction.remove.type`, `V2\Billing\Intent.create().$params.action.apply.type`, and `V2\Billing\Intent.create().$params.action.remove.type` from `literal('invoice_discount_rule')` to `enum('invoice_discount_rule'|'spend_modifier_rule')`

## 19.4.0-alpha.2 - 2026-02-04
* [#2005](https://github.com/stripe/stripe-php/pull/2005) Update generated code for private-preview
  * Add support for new resource `V2.Core.ConnectionSession`
  * Add support for `create` and `retrieve` methods on resource `V2.Core.ConnectionSession`
  * Add support for `all` method on resources `V2.Payments.SettlementAllocationIntentSplit` and `V2.Payments.SettlementAllocationIntent`
  * Add support for `agentic_commerce_settings` on `AccountSession.create().$params.component`
  * Add support for `terminal_hardware_orders` and `terminal_hardware_shop` on `AccountSession.components` and `AccountSession.create().$params.component`
  * Add support for `network_cost_passthrough_report` on `AccountSession.components`
  * Add support for new values `ae_bank_account`, `ag_bank_account`, `bh_bank_account`, `gm_bank_account`, `hk_bank_account`, `kh_bank_account`, `lc_bank_account`, `mc_bank_account`, `mg_bank_account`, `my_bank_account`, `qa_bank_account`, `rw_bank_account`, `th_bank_account`, `tt_bank_account`, and `vn_bank_account` on enums `V2.Account.configuration.recipient_data.default_outbound_destination.type` and `V2.Core.Account.configuration.recipient.default_outbound_destination.type`
  * Add support for `cadence_data` on `V2.Billing.Intent` and `V2\Billing\Intent.create().$params`
  * Add support for `cancellation_details` on `V2.Billing.IntentAction.deactivate`, `V2.Billing.PricingPlanSubscription`, and `V2\Billing\Intent.create().$params.action.deactivate`
  * Add support for `contact_phone` on `V2.Core.Account`, `V2\Core\Account.create().$params`, `V2\Core\Account.update().$params`, and `V2\Core\AccountToken.create().$params`
  * Add support for `registration_date` on `V2.Core.Account.identity.business_details`, `V2\Core\Account.create().$params.identity.business_detail`, `V2\Core\Account.update().$params.identity.business_detail`, and `V2\Core\AccountToken.create().$params.identity.business_detail`
  * Add support for new value `gb_vat` on enum `V2.Core.Account.identity.business_details.id_numbers[].type`
  * Add support for `reference` on `V2.MoneyManagement.Adjustment`
  * Add support for `accrued_fees` on `V2.MoneyManagement.FinancialAccount`
  * Add support for `starting_balance` on `V2.MoneyManagement.FinancialAccount.payments`
  * Add support for new value `accrued_fees` on enum `V2.MoneyManagement.FinancialAccount.type`
  * Add support for `account_holder_address` and `account_holder_name` on `V2.MoneyManagement.FinancialAddress.credentials.us_bank_account`
  * Add support for `fingerprint` on `V2.MoneyManagement.PayoutMethod.card`
  * Add support for `card_spend` on `V2.MoneyManagement.ReceivedCredit` and `V2.MoneyManagement.ReceivedDebit`
  * Add support for new value `card_spend` on enum `V2.MoneyManagement.ReceivedCredit.type`
  * Add support for new value `card_spend` on enum `V2.MoneyManagement.ReceivedDebit.type`
  * Add support for new values `advance`, `anticipation_repayment`, `balance_transfer`, `charge_failure`, `charge`, `climate_order_purchase`, `climate_order_refund`, `connect_collection_transfer`, `connect_reserved_funds`, `contribution`, `dispute_reversal`, `financing_paydown_reversal`, `financing_paydown`, `inbound_transfer_reversal`, `issuing_dispute_fraud_liability_debit`, `issuing_dispute_provisional_credit_reversal`, `issuing_dispute_provisional_credit`, `issuing_dispute`, `minimum_balance_hold`, `network_cost`, `obligation`, `outbound_payment_reversal`, `outbound_transfer_reversal`, `partial_capture_reversal`, `payment_network_reserved_funds`, `platform_earning_refund`, `platform_earning`, `platform_fee`, `received_credit_reversal`, `received_debit_reversal`, `refund_failure`, `risk_reserved_funds`, `stripe_balance_payment_debit_reversal`, `stripe_balance_payment_debit`, `stripe_fee_tax`, `transfer_reversal`, and `unreconciled_customer_funds` on enums `V2.MoneyManagement.Transaction.category` and `V2.MoneyManagement.TransactionEntry.transaction_details.category`
  * Add support for `application_fee_refund`, `application_fee`, `charge`, `dispute`, `payout`, `refund`, `reserve_hold`, `reserve_release`, `topup`, `transfer_reversal`, and `transfer` on `V2.MoneyManagement.Transaction.flow` and `V2.MoneyManagement.TransactionEntry.transaction_details.flow`
  * Add support for new values `application_fee_refund`, `application_fee`, `charge`, `dispute`, `payout`, `refund`, `reserve_hold`, `reserve_release`, `topup`, `transfer_reversal`, and `transfer` on enums `V2.MoneyManagement.Transaction.flow.type` and `V2.MoneyManagement.TransactionEntry.transaction_details.flow.type`
  * Change `V2.Payments.SettlementAllocationIntentSplit.flow` to be optional
  * Change `V2\Billing\RateCardRate.create().$params.metered_item` to be required

## 19.4.0-alpha.1 - 2026-01-28
This release changes the pinned API version to `2026-01-28.preview`.

* [#2002](https://github.com/stripe/stripe-php/pull/2002) Update generated code for private-preview
  * Add support for new resources `FrMealVouchersOnboarding`, `Reserve.Hold`, `Reserve.Plan`, and `Reserve.Release`
  * Add support for `all`, `create`, `retrieve`, and `update` methods on resource `FrMealVouchersOnboarding`
  * Add support for `all` and `retrieve` methods on resources `Reserve.Hold` and `Reserve.Release`
  * Add support for `retrieve` method on resource `Reserve.Plan`
  * Add support for `pause` method on resource `Subscription`
  * Add support for `service_period_details` on `Discount`
  * Add support for `agentic_commerce_settings` on `AccountSession.components`
  * Add support for new value `risk_reserved` on enum `BalanceTransaction.balance_type`
  * Add support for `service_period` on `Coupon.create().$params` and `Coupon`
  * Add support for new value `service_period` on enum `Coupon.duration`
  * Change type of `InvoiceItem.pricing.price_details.price` and `InvoiceLineItem.pricing.price_details.price` from `string` to `expandable($Price)`
  * Add support for `settings` on `Invoice.create_preview().$params.discount`, `Invoice.create_preview().$params.schedule_detail.amendment.discount_action.add`, `Invoice.create_preview().$params.schedule_detail.amendment.discount_action.set`, `Invoice.create_preview().$params.schedule_detail.amendment.item_action.add.discount`, `Invoice.create_preview().$params.schedule_detail.amendment.item_action.set.discount`, `Invoice.create_preview().$params.schedule_detail.phase.discount`, `Invoice.create_preview().$params.schedule_detail.phase.item.discount`, `Invoice.create_preview().$params.subscription_detail.item.discount`, `Quote.create().$params.line.action.add_discount`, `Quote.create().$params.line.action.add_item.discount`, `Quote.create().$params.line.action.set_discount`, `Quote.create().$params.line.action.set_item.discount`, `Quote.update().$params.line.action.add_discount`, `Quote.update().$params.line.action.add_item.discount`, `Quote.update().$params.line.action.set_discount`, `Quote.update().$params.line.action.set_item.discount`, `Subscription.create().$params.discount`, `Subscription.create().$params.item.discount`, `Subscription.update().$params.discount`, `Subscription.update().$params.item.discount`, `SubscriptionItem.create().$params.discount`, `SubscriptionItem.update().$params.discount`, `SubscriptionSchedule.amend().$params.amendment.discount_action.add`, `SubscriptionSchedule.amend().$params.amendment.discount_action.set`, `SubscriptionSchedule.amend().$params.amendment.item_action.add.discount`, `SubscriptionSchedule.amend().$params.amendment.item_action.set.discount`, `SubscriptionSchedule.create().$params.phase.discount`, `SubscriptionSchedule.create().$params.phase.item.discount`, `SubscriptionSchedule.update().$params.phase.discount`, and `SubscriptionSchedule.update().$params.phase.item.discount`
  * Add support for `subtotal` on `InvoiceLineItem`
  * Add support for `billing_cadence` on `Subscription.all().$params`

## 19.3.0 - 2026-01-28
This release changes the pinned API version to `2026-01-28.clover`.

* [#2001](https://github.com/stripe/stripe-php/pull/2001) Update generated code
  * Add support for new resource `Radar.PaymentEvaluation`
  * Add support for `create` method on resource `Radar.PaymentEvaluation`
  * Add support for `adjustable_quantity` on `LineItem`
  * Add support for new value `risk_reserved` on enum `BalanceTransaction.balance_type`
  * Add support for new values `reserve_hold` and `reserve_release` on enum `BalanceTransaction.type`
  * Add support for new values `2.3.0` and `2.3.1` on enums `Charge.payment_method_details.card.three_d_secure.version` and `SetupAttempt.payment_method_details.card.three_d_secure.version`
  * Add support for new value `adyen` on enums `Charge.payment_method_details.ideal.bank`, `ConfirmationToken.payment_method_preview.ideal.bank`, `PaymentAttemptRecord.payment_method_details.ideal.bank`, `PaymentMethod.ideal.bank`, `PaymentRecord.payment_method_details.ideal.bank`, and `SetupAttempt.payment_method_details.ideal.bank`
  * Add support for new value `ADYBNL2A` on enums `Charge.payment_method_details.ideal.bic`, `ConfirmationToken.payment_method_preview.ideal.bic`, `PaymentAttemptRecord.payment_method_details.ideal.bic`, `PaymentMethod.ideal.bic`, `PaymentRecord.payment_method_details.ideal.bic`, and `SetupAttempt.payment_method_details.ideal.bic`
  * Add support for new value `pl_nip` on enums `Checkout.Session.customer_details.tax_ids[].type`, `Invoice.customer_tax_ids[].type`, `Tax.Calculation.customer_details.tax_ids[].type`, `Tax.Transaction.customer_details.tax_ids[].type`, and `TaxId.type`
  * Change `Invoice.payment_settings.payment_method_options.payto` and `Subscription.payment_settings.payment_method_options.payto` to be required
  * Add support for `enforce_arithmetic_validation` on `PaymentIntent.capture().$params.amount_detail`, `PaymentIntent.confirm().$params.amount_detail`, `PaymentIntent.create().$params.amount_detail`, `PaymentIntent.increment_authorization().$params.amount_detail`, and `PaymentIntent.update().$params.amount_detail`
  * Add support for `error` on `PaymentIntent.amount_details`
  * Remove support for `bgn` on `Terminal.Configuration.tipping`, `Terminal\Configuration.create().$params.tipping`, and `Terminal\Configuration.update().$params.tipping`
  * Add support for `topup` on `Treasury.ReceivedDebit.linked_flows`
  * Add support for `contact_phone` on `V2.Core.Account`, `V2\Core\Account.create().$params`, `V2\Core\Account.update().$params`, and `V2\Core\AccountToken.create().$params`
  * Add support for `registration_date` on `V2.Core.Account.identity.business_details`, `V2\Core\Account.create().$params.identity.business_detail`, `V2\Core\Account.update().$params.identity.business_detail`, and `V2\Core\AccountToken.create().$params.identity.business_detail`
  * Add support for new value `gb_vat` on enum `V2.Core.Account.identity.business_details.id_numbers[].type`
  * Add support for error code `request_blocked` on `Invoice.last_finalization_error`, `PaymentIntent.last_payment_error`, `SetupAttempt.setup_error`, `SetupIntent.last_setup_error`, and `StripeError`
* [#2000](https://github.com/stripe/stripe-php/pull/2000) Add guidance for undocumented API parameters

## 19.3.0-alpha.1 - 2026-01-21
* [#1998](https://github.com/stripe/stripe-php/pull/1998) Update generated code for private-preview
  * Remove support for `pause` method on resource `Subscription`
  * Change type of `Quote.subscription_data.phase_effective_at` and `Quote.subscription_data_overrides[].phase_effective_at` from `enum('billing_period_start'|'phase_start')` to `nullable(enum('billing_period_start'|'phase_start'))`

## 19.2.0 - 2026-01-16
* [#1997](https://github.com/stripe/stripe-php/pull/1997) Update generated code
  * Add support for event notifications `V2CoreAccountClosedEvent`, `V2CoreAccountCreatedEvent`, `V2CoreAccountIncludingConfigurationCustomerCapabilityStatusUpdatedEvent`, `V2CoreAccountIncludingConfigurationCustomerUpdatedEvent`, `V2CoreAccountIncludingConfigurationMerchantCapabilityStatusUpdatedEvent`, `V2CoreAccountIncludingConfigurationMerchantUpdatedEvent`, `V2CoreAccountIncludingConfigurationRecipientCapabilityStatusUpdatedEvent`, `V2CoreAccountIncludingConfigurationRecipientUpdatedEvent`, `V2CoreAccountIncludingDefaultsUpdatedEvent`, `V2CoreAccountIncludingFutureRequirementsUpdatedEvent`, `V2CoreAccountIncludingIdentityUpdatedEvent`, `V2CoreAccountIncludingRequirementsUpdatedEvent`, and `V2CoreAccountUpdatedEvent` with related object `V2.Core.Account`
  * Add support for event notification `V2CoreAccountLinkReturnedEvent`
  * Add support for event notifications `V2CoreAccountPersonCreatedEvent`, `V2CoreAccountPersonDeletedEvent`, and `V2CoreAccountPersonUpdatedEvent` with related object `V2.Core.AccountPerson`
* [#1984](https://github.com/stripe/stripe-php/pull/1984) Improve webhook signature validation doc block

## 19.2.0-alpha.3 - 2026-01-14
* [#1996](https://github.com/stripe/stripe-php/pull/1996) Update generated code for private-preview
  * Add support for `risk_details` on `DelegatedCheckout.RequestedSession`
  * Remove support for `description`, `images`, and `name` on `DelegatedCheckout.RequestedSession.line_item_details[]`
  * Add support for `name` on `ProductCatalog.TrialOffer` and `ProductCatalog\TrialOffer.create().$params`
  * Add support for `login_failed` and `registration_failed` on `Radar.AccountEvaluation.events[]` and `Radar\AccountEvaluation.update().$params`
  * Change type of `Radar\AccountEvaluation.update().$params.type` from `literal('registration_succeeded')` to `enum('login_failed'|'login_succeeded'|'registration_failed'|'registration_succeeded')`

## 19.2.0-alpha.2 - 2026-01-07
* [#1989](https://github.com/stripe/stripe-php/pull/1989) Update generated code for private-preview
  * Add support for `tracking_details` on `V2.MoneyManagement.OutboundPayment`
  * Add support for `paper_check` on `V2.MoneyManagement.OutboundPayment.delivery_options` and `V2\MoneyManagement\OutboundPayment.create().$params.delivery_option`
  * Add support for event notification `V2CoreAccountIncludingFutureRequirementsUpdatedEvent` with related object `V2.Core.Account`
* [#1979](https://github.com/stripe/stripe-php/pull/1979) Update generated code for private-preview
  * Add support for new resource `Tax.Location`
  * Add support for `all`, `create`, and `retrieve` methods on resource `Tax.Location`
  * Add support for `pause` method on resource `Subscription`
  * Add support for `performance_location` on `Checkout\Session.create().$params.line_item.price_datum.product_datum.tax_detail`, `Checkout\Session.update().$params.line_item.price_datum.product_datum.tax_detail`, `Invoice.add_lines().$params.line.price_datum.product_datum.tax_detail`, `Invoice.update_lines().$params.line.price_datum.product_datum.tax_detail`, `InvoiceLineItem.update().$params.price_datum.product_datum.tax_detail`, `PaymentLink.create().$params.line_item.price_datum.product_datum.tax_detail`, `Product.create().$params.tax_detail`, `Product.update().$params.tax_detail`, `Tax.CalculationLineItem`, and `Tax\Calculation.create().$params.line_item`
  * Add support for new value `performance` on enums `Tax.Calculation.shipping_cost.tax_breakdown[].sourcing`, `Tax.CalculationLineItem.tax_breakdown[].sourcing`, and `Tax.Transaction.shipping_cost.tax_breakdown[].sourcing`
  * Add support for new values `admissions_tax`, `attendance_tax`, `entertainment_tax`, `gross_receipts_tax`, `hospitality_tax`, `luxury_tax`, `resort_tax`, and `tourism_tax` on enums `Tax.Calculation.shipping_cost.tax_breakdown[].tax_rate_details.tax_type`, `Tax.Calculation.tax_breakdown[].tax_rate_details.tax_type`, `Tax.CalculationLineItem.tax_breakdown[].tax_rate_details.tax_type`, and `Tax.Transaction.shipping_cost.tax_breakdown[].tax_rate_details.tax_type`
  * Change type of `DelegatedCheckout\RequestedSession.update().$params.metadata` from `map(string: string)` to `emptyable(map(string: string))`
  * Change type of `DelegatedCheckout\RequestedSession.update().$params.payment_method_data` from `payment_method_data` to `emptyable(payment_method_data)`
  * Change type of `DelegatedCheckout\RequestedSession.update().$params.shared_metadata` from `map(string: string)` to `emptyable(map(string: string))`
  * Add support for `subscription` on `Invoice.parent.schedule_details` and `QuotePreviewInvoice.parent.schedule_details`
  * Change type of `PaymentIntent.confirm().$params.payment_detail.benefit.fr_meal_voucher`, `PaymentIntent.create().$params.payment_detail.benefit.fr_meal_voucher`, `PaymentIntent.update().$params.payment_detail.benefit.fr_meal_voucher`, `SetupIntent.confirm().$params.setup_detail.benefit.fr_meal_voucher`, `SetupIntent.create().$params.setup_detail.benefit.fr_meal_voucher`, and `SetupIntent.update().$params.setup_detail.benefit.fr_meal_voucher` from `payment_details_benefit_fr_meal_voucher` to `emptyable(payment_details_benefit_fr_meal_voucher)`
  * Add support for `tax_details` on `Plan.create().$params.product` and `Price.create().$params.product_datum`
  * Add support for `external_reference` on `Plan` and `Price`
  * Add support for new value `phase_start` on enums `Quote.subscription_data.phase_effective_at` and `Quote.subscription_data_overrides[].phase_effective_at`
  * Remove support for value `line_start` from enums `Quote.subscription_data.phase_effective_at` and `Quote.subscription_data_overrides[].phase_effective_at`
  * Add support for `admissions_tax`, `attendance_tax`, `entertainment_tax`, `gross_receipts_tax`, `hospitality_tax`, `luxury_tax`, `resort_tax`, and `tourism_tax` on `Tax.Registration.country_options.us`
  * Add support for new values `admissions_tax`, `attendance_tax`, `entertainment_tax`, `gross_receipts_tax`, `hospitality_tax`, `luxury_tax`, `resort_tax`, and `tourism_tax` on enum `Tax.Registration.country_options.us.type`
  * Add support for `requirements` on `TaxCode`

## 19.2.0-alpha.1 - 2025-12-14
* [#1978](https://github.com/stripe/stripe-php/pull/1978) Update generated code for private-preview
  * Add support for new resources `SharedPayment.GrantedToken`, `V2.Iam.ApiKey`, `V2.Payments.SettlementAllocationIntentSplit`, `V2.Payments.SettlementAllocationIntent`, and `V2.Tax.ManualRule`
  * Add support for `retrieve` method on resource `SharedPayment.GrantedToken`
  * Add support for `create` and `update` test helper methods on resource `SharedPayment.GrantedToken`
  * Add support for `all`, `create`, `deactivate`, `retrieve`, and `update` methods on resource `V2.Tax.ManualRule`
  * Add support for `cancel`, `create`, `retrieve`, `submit`, and `update` methods on resource `V2.Payments.SettlementAllocationIntent`
  * Add support for `cancel`, `create`, and `retrieve` methods on resource `V2.Payments.SettlementAllocationIntentSplit`
  * Add support for `all`, `create`, `expire`, `retrieve`, `rotate`, and `update` methods on resource `V2.Iam.ApiKey`
  * Add support for `check_scanning` on `AccountSession.create().$params.component`
  * Add support for `tax_details` on `Checkout\Session.create().$params.line_item.price_datum.product_datum`, `Checkout\Session.update().$params.line_item.price_datum.product_datum`, `Invoice.add_lines().$params.line.price_datum.product_datum`, `Invoice.update_lines().$params.line.price_datum.product_datum`, `InvoiceLineItem.update().$params.price_datum.product_datum`, `PaymentLink.create().$params.line_item.price_datum.product_datum`, `Product.create().$params`, and `Product.update().$params`
  * Add support for `payment_method_data` on `DelegatedCheckout\RequestedSession.confirm().$params`
  * Add support for `product_details` on `DelegatedCheckout.RequestedSession.line_item_details[]`
  * Add support for `wallets` on `Issuing\Card.all().$params`
  * Add support for `primary_account_identifier` on `Issuing.Card.wallets.apple_pay` and `Issuing.Card.wallets.google_pay`
  * Add support for `shared_payment_granted_token` on `PaymentIntent.confirm().$params`, `PaymentIntent.create().$params`, and `PaymentIntent`
  * Change `ProductCatalog.TrialOffer.duration.relative` to be optional
  * Add support for new values `al_bank_account`, `am_bank_account`, `bn_bank_account`, `bw_bank_account`, `dz_bank_account`, `gy_bank_account`, `jm_bank_account`, `jo_bank_account`, `kw_bank_account`, `lk_bank_account`, `ma_bank_account`, `om_bank_account`, and `tz_bank_account` on enum `V2.Account.configuration.recipient_data.default_outbound_destination.type`
  * Add support for `instant` on `V2.Account.configuration.recipient_data.features.bank_accounts`, `V2.Core.Account.configuration.recipient.capabilities.bank_accounts`, `V2\Account.create().$params.configuration.recipient_datum.feature.bank_account`, `V2\Account.update().$params.configuration.recipient_datum.feature.bank_account`, `V2\Core\Account.create().$params.configuration.recipient.capability.bank_account`, and `V2\Core\Account.update().$params.configuration.recipient.capability.bank_account`
  * Add support for new value `bank_accounts.instant` on enum `V2.Account.requirements[].impact.required_for_features`
  * Add support for `collect_at` on `V2.Billing.IntentAction.deactivate`, `V2.Billing.IntentAction.modify`, `V2.Billing.IntentAction.subscribe`, `V2\Billing\Intent.create().$params.action.deactivate`, `V2\Billing\Intent.create().$params.action.modify`, and `V2\Billing\Intent.create().$params.action.subscribe`
  * Remove support for `billing_details` on `V2.Billing.IntentAction.deactivate`, `V2.Billing.IntentAction.modify`, `V2.Billing.IntentAction.subscribe`, `V2\Billing\Intent.create().$params.action.deactivate`, `V2\Billing\Intent.create().$params.action.modify`, and `V2\Billing\Intent.create().$params.action.subscribe`
  * Add support for `overrides` on `V2.Billing.IntentAction.deactivate.pricing_plan_subscription_details`, `V2.Billing.IntentAction.modify.pricing_plan_subscription_details`, `V2.Billing.IntentAction.subscribe.pricing_plan_subscription_details`, `V2\Billing\Intent.create().$params.action.deactivate.pricing_plan_subscription_detail`, `V2\Billing\Intent.create().$params.action.modify.pricing_plan_subscription_detail`, and `V2\Billing\Intent.create().$params.action.subscribe.pricing_plan_subscription_detail`
  * Remove support for `requested` on `V2.Core.Account.configuration.card_creator.capabilities.commercial.celtic.charge_card`, `V2.Core.Account.configuration.card_creator.capabilities.commercial.celtic.spend_card`, `V2.Core.Account.configuration.card_creator.capabilities.commercial.cross_river_bank.charge_card`, `V2.Core.Account.configuration.card_creator.capabilities.commercial.cross_river_bank.spend_card`, `V2.Core.Account.configuration.card_creator.capabilities.commercial.lead.prepaid_card`, `V2.Core.Account.configuration.card_creator.capabilities.commercial.stripe.charge_card`, `V2.Core.Account.configuration.card_creator.capabilities.commercial.stripe.prepaid_card`, `V2.Core.Account.configuration.recipient.capabilities.crypto_wallets`, `V2.Core.Account.configuration.storer.capabilities.financial_addresses.crypto_wallets`, `V2.Core.Account.configuration.storer.capabilities.holds_currencies.usdc`, `V2.Core.Account.configuration.storer.capabilities.outbound_payments.crypto_wallets`, and `V2.Core.Account.configuration.storer.capabilities.outbound_transfers.crypto_wallets`
  * Add support for new value `bank_accounts.instant` on enums `V2.Core.Account.future_requirements.entries[].impact.restricts_capabilities[].capability` and `V2.Core.Account.requirements.entries[].impact.restricts_capabilities[].capability`
  * Add support for `alternative_reference` on `V2.Core.Vault.GbBankAccount`, `V2.Core.Vault.UsBankAccount`, and `V2.MoneyManagement.PayoutMethod`
  * Add support for `managed_by` and `payments` on `V2.MoneyManagement.FinancialAccount`
  * Add support for new value `payments` on enum `V2.MoneyManagement.FinancialAccount.type`
  * Add support for `speed` on `V2.MoneyManagement.OutboundPayment.delivery_options`, `V2.MoneyManagement.OutboundPaymentQuote.delivery_options`, `V2\MoneyManagement\OutboundPayment.create().$params.delivery_option`, and `V2\MoneyManagement\OutboundPaymentQuote.create().$params.delivery_option`
  * Add support for new value `real_time_payout_fee` on enum `V2.MoneyManagement.OutboundPaymentQuote.estimated_fees[].type`
  * Add support for `types` on `V2\MoneyManagement\FinancialAccount.all().$params`
  * Add support for new value `bank_accounts.instant` on enum `EventsV2CoreAccountIncludingConfigurationRecipientCapabilityStatusUpdatedEvent.updated_capability`
  * Add support for `top_impacted_accounts` on `EventsV2CoreHealthApiErrorFiringEvent.impact`, `EventsV2CoreHealthApiErrorResolvedEvent.impact`, `EventsV2CoreHealthApiLatencyFiringEvent.impact`, `EventsV2CoreHealthApiLatencyResolvedEvent.impact`, `EventsV2CoreHealthPaymentMethodErrorFiringEvent.impact`, and `EventsV2CoreHealthPaymentMethodErrorResolvedEvent.impact`
  * Add support for event notifications `V2CoreHealthSepaDebitDelayedFiringEvent`, `V2CoreHealthSepaDebitDelayedResolvedEvent`, and `V2PaymentsSettlementAllocationIntentNotFoundEvent`
  * Add support for event notifications `V2PaymentsSettlementAllocationIntentCanceledEvent`, `V2PaymentsSettlementAllocationIntentCreatedEvent`, `V2PaymentsSettlementAllocationIntentErroredEvent`, `V2PaymentsSettlementAllocationIntentFundsNotReceivedEvent`, `V2PaymentsSettlementAllocationIntentMatchedEvent`, `V2PaymentsSettlementAllocationIntentSettledEvent`, and `V2PaymentsSettlementAllocationIntentSubmittedEvent` with related object `V2.Payments.SettlementAllocationIntent`
  * Add support for event notifications `V2PaymentsSettlementAllocationIntentSplitCanceledEvent`, `V2PaymentsSettlementAllocationIntentSplitCreatedEvent`, and `V2PaymentsSettlementAllocationIntentSplitSettledEvent` with related object `V2.Payments.SettlementAllocationIntentSplit`

## 19.1.0 - 2025-12-16
This release changes the pinned API version to `2025-12-15.clover`.

* [#1975](https://github.com/stripe/stripe-php/pull/1975) Update generated code
  * Add support for new resources `V2.Core.AccountLink`, `V2.Core.AccountPersonToken`, `V2.Core.AccountPerson`, `V2.Core.AccountToken`, and `V2.Core.Account`
  * Add support for `create` and `retrieve` methods on resources `V2.Core.AccountPersonToken` and `V2.Core.AccountToken`
  * Add support for `create` method on resource `V2.Core.AccountLink`
  * Add support for `all`, `close`, `create`, `retrieve`, and `update` methods on resource `V2.Core.Account`
  * Add support for `all`, `create`, `delete`, `retrieve`, and `update` methods on resource `V2.Core.AccountPerson`
  * Add support for `customer_account` on `Billing.CreditBalanceSummary`, `Billing.CreditGrant`, `BillingPortal.Session`, `BillingPortal\Session.create().$params`, `Billing\CreditBalanceSummary.retrieve().$params`, `Billing\CreditBalanceTransaction.all().$params`, `Billing\CreditGrant.all().$params`, `Billing\CreditGrant.create().$params`, `CashBalance`, `Checkout.Session`, `Checkout\Session.all().$params`, `Checkout\Session.create().$params`, `ConfirmationToken.payment_method_preview`, `CreditNote.all().$params`, `CreditNote`, `CustomerBalanceTransaction`, `CustomerCashBalanceTransaction`, `CustomerSession.create().$params`, `CustomerSession`, `Customer`, `Discount`, `FinancialConnections.Account.account_holder`, `FinancialConnections.Session.account_holder`, `FinancialConnections\Account.all().$params.account_holder`, `FinancialConnections\Session.create().$params.account_holder`, `Invoice.all().$params`, `Invoice.create().$params`, `Invoice.create_preview().$params`, `InvoiceItem.all().$params`, `InvoiceItem.create().$params`, `InvoiceItem`, `Invoice`, `PaymentIntent.all().$params`, `PaymentIntent.create().$params`, `PaymentIntent.update().$params`, `PaymentIntent`, `PaymentMethod.all().$params`, `PaymentMethod.attach().$params`, `PaymentMethod`, `PromotionCode.all().$params`, `PromotionCode.create().$params`, `PromotionCode`, `Quote.all().$params`, `Quote.create().$params`, `Quote.update().$params`, `Quote`, `SetupAttempt`, `SetupIntent.all().$params`, `SetupIntent.create().$params`, `SetupIntent.update().$params`, `SetupIntent`, `Subscription.all().$params`, `Subscription.create().$params`, `SubscriptionSchedule.all().$params`, `SubscriptionSchedule.create().$params`, `SubscriptionSchedule`, `Subscription`, `TaxId.all().$params.owner`, `TaxId.create().$params.owner`, `TaxId.owner`, and `TaxId`
  * Add support for `metadata` on `Checkout\Session.create().$params.line_item` and `LineItem`
  * Add support for `payto_payments` on `Account.capabilities`, `Account.create().$params.capability`, and `Account.update().$params.capability`
  * Add support for `signer` on `Account.create().$params.document.proof_of_registration`, `Account.create().$params.document.proof_of_ultimate_beneficial_ownership`, `Account.update().$params.document.proof_of_registration`, and `Account.update().$params.document.proof_of_ultimate_beneficial_ownership`
  * Change `BillingPortal\Session.create().$params.customer`, `Billing\CreditBalanceSummary.retrieve().$params.customer`, `Billing\CreditBalanceTransaction.all().$params.customer`, `Billing\CreditGrant.create().$params.customer`, `CustomerSession.create().$params.customer`, `InvoiceItem.create().$params.customer`, `PaymentMethod.attach().$params.customer`, and `Subscription.create().$params.customer` to be optional
  * Add support for `billing_cycle_anchor` on `BillingPortal.Configuration.features.subscription_update`, `BillingPortal\Configuration.create().$params.feature.subscription_update`, and `BillingPortal\Configuration.update().$params.feature.subscription_update`
  * Add support for `payto` on `Charge.payment_method_details`, `Checkout.Session.payment_method_options`, `Checkout\Session.create().$params.payment_method_option`, `ConfirmationToken.create().$params.payment_method_datum`, `ConfirmationToken.payment_method_preview`, `Invoice.create().$params.payment_setting.payment_method_option`, `Invoice.payment_settings.payment_method_options`, `Invoice.update().$params.payment_setting.payment_method_option`, `Mandate.payment_method_details`, `PaymentAttemptRecord.payment_method_details`, `PaymentIntent.confirm().$params.payment_method_datum`, `PaymentIntent.confirm().$params.payment_method_option`, `PaymentIntent.create().$params.payment_method_datum`, `PaymentIntent.create().$params.payment_method_option`, `PaymentIntent.payment_method_options`, `PaymentIntent.update().$params.payment_method_datum`, `PaymentIntent.update().$params.payment_method_option`, `PaymentMethod.create().$params`, `PaymentMethod.update().$params`, `PaymentMethodConfiguration.create().$params`, `PaymentMethodConfiguration.update().$params`, `PaymentMethodConfiguration`, `PaymentMethod`, `PaymentRecord.payment_method_details`, `SetupAttempt.payment_method_details`, `SetupIntent.confirm().$params.payment_method_datum`, `SetupIntent.confirm().$params.payment_method_option`, `SetupIntent.create().$params.payment_method_datum`, `SetupIntent.create().$params.payment_method_option`, `SetupIntent.payment_method_options`, `SetupIntent.update().$params.payment_method_datum`, `SetupIntent.update().$params.payment_method_option`, `Subscription.create().$params.payment_setting.payment_method_option`, `Subscription.payment_settings.payment_method_options`, and `Subscription.update().$params.payment_setting.payment_method_option`
  * Add support for `expected_debit_date` on `Charge.payment_method_details.acss_debit`, `Charge.payment_method_details.au_becs_debit`, `Charge.payment_method_details.bacs_debit`, `Charge.payment_method_details.nz_bank_account`, `Charge.payment_method_details.sepa_debit`, `Charge.payment_method_details.us_bank_account`, `PaymentAttemptRecord.payment_method_details.acss_debit`, `PaymentAttemptRecord.payment_method_details.au_becs_debit`, `PaymentAttemptRecord.payment_method_details.bacs_debit`, `PaymentAttemptRecord.payment_method_details.nz_bank_account`, `PaymentAttemptRecord.payment_method_details.sepa_debit`, `PaymentAttemptRecord.payment_method_details.us_bank_account`, `PaymentRecord.payment_method_details.acss_debit`, `PaymentRecord.payment_method_details.au_becs_debit`, `PaymentRecord.payment_method_details.bacs_debit`, `PaymentRecord.payment_method_details.nz_bank_account`, `PaymentRecord.payment_method_details.sepa_debit`, and `PaymentRecord.payment_method_details.us_bank_account`
  * Add support for new value `mollie` on enums `Charge.payment_method_details.ideal.bank`, `ConfirmationToken.payment_method_preview.ideal.bank`, `PaymentAttemptRecord.payment_method_details.ideal.bank`, `PaymentMethod.ideal.bank`, `PaymentRecord.payment_method_details.ideal.bank`, and `SetupAttempt.payment_method_details.ideal.bank`
  * Add support for new value `MLLENL2A` on enums `Charge.payment_method_details.ideal.bic`, `ConfirmationToken.payment_method_preview.ideal.bic`, `PaymentAttemptRecord.payment_method_details.ideal.bic`, `PaymentMethod.ideal.bic`, `PaymentRecord.payment_method_details.ideal.bic`, and `SetupAttempt.payment_method_details.ideal.bic`
  * Add support for `line_items` on `Checkout\Session.update().$params`
  * Add support for new value `payto` on enums `ConfirmationToken.payment_method_preview.type` and `PaymentMethod.type`
  * Add support for `invoice` on `CustomerBalanceTransaction.all().$params`
  * Add support for `related_customer_account` on `Identity.VerificationSession`, `Identity\VerificationSession.all().$params`, and `Identity\VerificationSession.create().$params`
  * Change type of `InvoiceItem.pricing.price_details.price` and `InvoiceLineItem.pricing.price_details.price` from `string` to `expandable($Price)`
  * Add support for new value `payto` on enums `Invoice.payment_settings.payment_method_types` and `Subscription.payment_settings.payment_method_types`
  * Add support for `subtotal` on `InvoiceLineItem`
  * Add support for `authorization_code`, `description`, `iin`, `installments`, `issuer`, `network_advice_code`, `network_decline_code`, and `stored_credential_usage` on `PaymentAttemptRecord.payment_method_details.card` and `PaymentRecord.payment_method_details.card`
  * Add support for new value `payto` on enums `PaymentIntent.excluded_payment_method_types` and `SetupIntent.excluded_payment_method_types`
  * Change `PaymentIntent.transfer_data` to be optional
  * Add support for new value `payto` on enum `PaymentLink.payment_method_types`
  * Add support for `allow_redisplay` on `PaymentMethod.all().$params`
  * Add support for `reported_by` on `PaymentRecord`
  * Change `Product.tax_code` to be optional
  * Add support for `changes` on `V2.Core.Event`
  * Add support for error code `account_token_required_for_v2_account` on `Invoice.last_finalization_error`, `PaymentIntent.last_payment_error`, `SetupAttempt.setup_error`, `SetupIntent.last_setup_error`, and `StripeError`
* [#1976](https://github.com/stripe/stripe-php/pull/1976) Updated bundled CA certs
* [#1973](https://github.com/stripe/stripe-php/pull/1973) Remove deprecated usage of curl_close() for PHP versions > 8.0

## 19.1.0-beta.1 - 2025-11-18
This release changes the pinned API version to `2025-11-17.preview`.

* [#1952](https://github.com/stripe/stripe-php/pull/1952) Update generated code for beta
  * Add support for new resources `V2.Core.AccountPersonToken` and `V2.Core.AccountToken`
  * Remove support for resource `V2.Payments.OffSessionPayment`
  * Add support for `create` and `retrieve` methods on resources `V2.Core.AccountPersonToken` and `V2.Core.AccountToken`
  * Remove support for `all`, `cancel`, `capture`, `create`, and `retrieve` methods on resource `V2.Payments.OffSessionPayment`
  * Change `Tax.Association.tax_transaction_attempts` to be required
  * Add support for `specified_commercial_transactions_act_url` on `Account.business_profile`, `Account.create().$params.business_profile`, and `Account.update().$params.business_profile`
  * Add support for `paypay_payments` on `Account.create().$params.setting`, `Account.settings`, and `Account.update().$params.setting`
  * Change type of `Billing\Analytics\MeterUsage.retrieve().$params.meter.dimension_filters` from `string` to `array(string)`
  * Change type of `Billing\Analytics\MeterUsage.retrieve().$params.meter.tenant_filters` from `string` to `array(string)`
  * Add support for `car_rental_data`, `flight_data`, and `lodging_data` on `Charge.capture().$params.payment_detail`, `Charge.update().$params.payment_detail`, `PaymentIntent.capture().$params.payment_detail`, `PaymentIntent.confirm().$params.payment_detail`, `PaymentIntent.create().$params.payment_detail`, and `PaymentIntent.update().$params.payment_detail`
  * Add support for `supplementary_purchase_data` on `Order.create().$params.payment.setting.payment_method_option.klarna`, `Order.update().$params.payment.setting.payment_method_option.klarna`, `PaymentIntent.confirm().$params.payment_method_option.klarna`, `PaymentIntent.create().$params.payment_method_option.klarna`, and `PaymentIntent.update().$params.payment_method_option.klarna`
  * Add support for `allow_redisplay` and `customer_account` on `PaymentMethod.all().$params`
  * Add support for `future_requirements` on `V2.Core.Account`
  * Add support for `konbini_payments` and `script_statement_descriptor` on `V2.Core.Account.configuration.merchant`, `V2\Core\Account.create().$params.configuration.merchant`, and `V2\Core\Account.update().$params.configuration.merchant`
  * Add support for `eur` on `V2.Core.Account.configuration.storer.capabilities.holds_currencies`, `V2\Core\Account.create().$params.configuration.storer.capability.holds_currency`, and `V2\Core\Account.update().$params.configuration.storer.capability.holds_currency`
  * Add support for `requirements_collector` on `V2.Core.Account.defaults.responsibilities`
  * Add support for new value `ar_cuit` on enum `V2.Core.Account.identity.business_details.id_numbers[].type`
  * Add support for new value `ar_dni` on enums `V2.Core.Account.identity.individual.id_numbers[].type` and `V2.Core.AccountPerson.id_numbers[].type`
  * Remove support for `collector` on `V2.Core.Account.requirements`
  * Add support for new value `holds_currencies.eur` on enum `V2.Core.Account.requirements.entries[].impact.restricts_capabilities[].capability`
  * Add support for new values `payment_method` and `person` on enum `V2.Core.Account.requirements.entries[].reference.type`
  * Remove support for value `resource` from enum `V2.Core.Account.requirements.entries[].reference.type`
  * Remove support for value `future_requirements` from enum `V2.Core.Account.requirements.entries[].requested_reasons[].code`
  * Add support for `changes` on `V2.Core.Event`
  * Remove support for value `sepa_bank_account` from enum `V2.MoneyManagement.FinancialAddress.credentials.type`
  * Add support for `account_token` on `V2\Core\Account.create().$params` and `V2\Core\Account.update().$params`
  * Add support for `person_token` on `V2\Core\AccountPerson.create().$params` and `V2\Core\AccountPerson.update().$params`
  * Add support for thin event `V2CoreHealthEventGenerationFailureResolvedEvent`
  * Remove support for thin events `V2PaymentsOffSessionPaymentAuthorizationAttemptFailedEvent`, `V2PaymentsOffSessionPaymentAuthorizationAttemptStartedEvent`, `V2PaymentsOffSessionPaymentCanceledEvent`, `V2PaymentsOffSessionPaymentCreatedEvent`, `V2PaymentsOffSessionPaymentFailedEvent`, `V2PaymentsOffSessionPaymentRequiresCaptureEvent`, and `V2PaymentsOffSessionPaymentSucceededEvent` with related object `V2.Payments.OffSessionPayment`

## 19.1.0-alpha.4 - 2025-12-04
* [#1977](https://github.com/stripe/stripe-php/pull/1977) Update generated code for private-preview
  * Add support for event notifications `V2IamApiKeyCreatedEvent`, `V2IamApiKeyDefaultSecretRevealedEvent`, `V2IamApiKeyExpiredEvent`, `V2IamApiKeyPermissionsUpdatedEvent`, `V2IamApiKeyRotatedEvent`, and `V2IamApiKeyUpdatedEvent`
* [#1974](https://github.com/stripe/stripe-php/pull/1974) Update generated code for private-preview
  * Add support for `check_scanning` on `AccountSession.components`
  * Add support for `client` on `V2.Core.Event.reason.request`
  * Add support for `stripe_balance_payment` on `V2.MoneyManagement.ReceivedCredit` and `V2.MoneyManagement.ReceivedDebit`
  * Add support for new value `stripe_balance_payment` on enum `V2.MoneyManagement.ReceivedCredit.type`
  * Add support for `balance_transfer` on `V2.MoneyManagement.ReceivedDebit`
  * Add support for new values `balance_transfer` and `stripe_balance_payment` on enum `V2.MoneyManagement.ReceivedDebit.type`
  * Add support for `include` on `V2\Core\Event.all().$params` and `V2\Core\Event.retrieve().$params`

## 19.1.0-alpha.3 - 2025-11-24
* [#1971](https://github.com/stripe/stripe-php/pull/1971) Update generated code for private-preview
  * Add support for new resource `ProductCatalog.TrialOffer`
  * Add support for `create` method on resource `ProductCatalog.TrialOffer`
  * Remove support for `amount_subtotal_after_discount` on `DelegatedCheckout.RequestedSession.line_item_details[]` and `DelegatedCheckout.RequestedSession.total_details`
  * Remove support for `amount_total`, `unit_amount_after_discount`, and `unit_discount` on `DelegatedCheckout.RequestedSession.line_item_details[]`
  * Add support for `amount_cart_discount` and `amount_items_discount` on `DelegatedCheckout.RequestedSession.total_details`
  * Remove support for `amount_discount` on `DelegatedCheckout.RequestedSession.total_details`
  * Add support for `payments_orchestration` on `PaymentIntent.create().$params` and `PaymentIntent`

## 19.1.0-alpha.2 - 2025-11-20
This release changes the pinned API version to `2025-11-17.preview`.

* [#1968](https://github.com/stripe/stripe-php/pull/1968) Update generated code for private-preview
  * Add support for new resources `V2.Core.AccountPersonToken`, `V2.Core.AccountToken`, and `V2.MoneyManagement.CurrencyConversion`
  * Add support for `all`, `create`, and `retrieve` methods on resource `V2.MoneyManagement.CurrencyConversion`
  * Add support for `create` and `retrieve` methods on resources `V2.Core.AccountPersonToken` and `V2.Core.AccountToken`
  * Add support for `effective_at` on `Invoice.create_preview().$params.schedule_detail.amendment`, `Invoice.create_preview().$params.schedule_detail.phase`, `Quote.create().$params.line`, `Quote.update().$params.line`, `QuoteLine`, `QuotePreviewSubscriptionSchedule.phases[]`, `SubscriptionSchedule.amend().$params.amendment`, `SubscriptionSchedule.create().$params.phase`, `SubscriptionSchedule.phases[]`, and `SubscriptionSchedule.update().$params.phase`
  * Add support for `trial_offer` on `Invoice.create_preview().$params.schedule_detail.amendment.item_action.add`, `Invoice.create_preview().$params.schedule_detail.amendment.item_action.set`, `Invoice.create_preview().$params.schedule_detail.phase.item`, `Quote.create().$params.line.action.add_item`, `Quote.create().$params.line.action.set_item`, `Quote.update().$params.line.action.add_item`, `Quote.update().$params.line.action.set_item`, `QuoteLine.actions[].add_item`, `QuoteLine.actions[].set_items[]`, `QuotePreviewSubscriptionSchedule.phases[].items[]`, `SubscriptionSchedule.amend().$params.amendment.item_action.add`, `SubscriptionSchedule.amend().$params.amendment.item_action.set`, `SubscriptionSchedule.create().$params.phase.item`, `SubscriptionSchedule.phases[].items[]`, and `SubscriptionSchedule.update().$params.phase.item`
  * Change type of `DelegatedCheckout.RequestedSession.amount_subtotal` from `longInteger` to `nullable(longInteger)`
  * Change type of `DelegatedCheckout.RequestedSession.amount_total` from `longInteger` to `nullable(longInteger)`
  * Add support for `amount_discount`, `amount_subtotal`, `amount_total`, `unit_amount_after_discount`, and `unit_discount` on `DelegatedCheckout.RequestedSession.line_item_details[]`
  * Add support for `amount_subtotal_after_discount` on `DelegatedCheckout.RequestedSession.line_item_details[]` and `DelegatedCheckout.RequestedSession.total_details`
  * Change type of `Invoice.create_preview().$params.schedule_detail.billing_schedules` from `array(billing_schedules_update_params)` to `emptyable(array(billing_schedules_update_params))`
  * Add support for `current_trial` on `Invoice.create_preview().$params.subscription_detail.item`, `Subscription.create().$params.item`, `Subscription.update().$params.item`, `SubscriptionItem.create().$params`, `SubscriptionItem.update().$params`, and `SubscriptionItem`
  * Change type of `Quote.create().$params.subscription_data_override.billing_schedules` and `Quote.create().$params.subscription_datum.billing_schedules` from `emptyable(array(billing_schedules_create_specs))` to `array(billing_schedules_create_specs)`
  * Change type of `Quote.subscription_data.billing_schedules` and `Quote.subscription_data_overrides[].billing_schedules` from `nullable(array(SubscriptionsResourceBillingSchedules))` to `array(QuotesResourceSubscriptionDataBillingSchedules)`
  * Change type of `Quote.subscription_data.phase_effective_at` and `Quote.subscription_data_overrides[].phase_effective_at` from `nullable(enum('billing_period_start'|'phase_start'))` to `enum('billing_period_start'|'line_start')`
  * Change type of `QuotePreviewSubscriptionSchedule.default_settings.phase_effective_at` and `SubscriptionSchedule.default_settings.phase_effective_at` from `nullable(enum('billing_period_start'|'phase_start'))` to `enum('billing_period_start'|'phase_start')`
  * Change type of `QuotePreviewSubscriptionSchedule.billing_schedules` and `SubscriptionSchedule.billing_schedules` from `nullable(array(SubscriptionsResourceBillingSchedules))` to `array(SubscriptionsResourceBillingSchedules)`
  * Remove support for `amendment_start`, `line_starts_at`, and `relative` on `Subscription.billing_schedules[].bill_from`
  * Change type of `Subscription.billing_schedules[].bill_from.computed_timestamp` from `nullable(DateTime)` to `DateTime`
  * Change type of `Subscription.billing_schedules[].bill_from.type` from `enum` to `literal('timestamp')`
  * Remove support for `amendment_end` and `line_ends_at` on `Subscription.billing_schedules[].bill_until`
  * Remove support for values `amendment_end`, `line_ends_at`, `schedule_end`, and `upcoming_invoice` from enum `Subscription.billing_schedules[].bill_until.type`
  * Change type of `V2.Billing.ServiceAction.credit_grant.amount.monetary`, `V2.Billing.ServiceAction.credit_grant_per_tenant.amount.monetary`, `V2\Billing\ServiceAction.create().$params.credit_grant.amount.monetary`, and `V2\Billing\ServiceAction.create().$params.credit_grant_per_tenant.amount.monetary` from `amount` to `an object`
  * Add support for `future_requirements` on `V2.Core.Account`
  * Add support for `konbini_payments` and `script_statement_descriptor` on `V2.Core.Account.configuration.merchant`, `V2\Core\Account.create().$params.configuration.merchant`, and `V2\Core\Account.update().$params.configuration.merchant`
  * Add support for `eur` on `V2.Core.Account.configuration.storer.capabilities.holds_currencies`, `V2\Core\Account.create().$params.configuration.storer.capability.holds_currency`, and `V2\Core\Account.update().$params.configuration.storer.capability.holds_currency`
  * Add support for `requirements_collector` on `V2.Core.Account.defaults.responsibilities`
  * Add support for new value `ar_cuit` on enum `V2.Core.Account.identity.business_details.id_numbers[].type`
  * Add support for new value `ar_dni` on enums `V2.Core.Account.identity.individual.id_numbers[].type` and `V2.Core.AccountPerson.id_numbers[].type`
  * Remove support for `collector` on `V2.Core.Account.requirements`
  * Add support for new value `holds_currencies.eur` on enum `V2.Core.Account.requirements.entries[].impact.restricts_capabilities[].capability`
  * Add support for new values `payment_method` and `person` on enum `V2.Core.Account.requirements.entries[].reference.type`
  * Remove support for value `resource` from enum `V2.Core.Account.requirements.entries[].reference.type`
  * Remove support for value `future_requirements` from enum `V2.Core.Account.requirements.entries[].requested_reasons[].code`
  * Remove support for `v1_event_id` on `V2.Core.Event`
  * Remove support for `amount_details` and `capture_method` on `V2.Payments.OffSessionPayment` and `V2\Payments\OffSessionPayment.create().$params`
  * Change type of `V2.Payments.OffSessionPayment.amount_capturable` from `amount` to `an object`
  * Change type of `V2.Payments.OffSessionPayment.amount_requested` from `amount` to `an object`
  * Change type of `V2\Payments\OffSessionPayment.create().$params.amount` from `amount` to `an object`
  * Change `V2\Payments\OffSessionPayment.create().$params.retry_detail.retry_strategy` to be optional
  * Remove support for `destination` on `V2\Payments\OffSessionPayment.capture().$params.transfer_datum`
  * Change `V2\Payments\OffSessionPayment.capture().$params.amount_to_capture` to be optional
  * Add support for `created` on `V2\Core\Event.all().$params`
  * Remove support for `gt`, `gte`, `lt`, and `lte` on `V2\Core\Event.all().$params`
  * Add support for `account_token` on `V2\Core\Account.create().$params` and `V2\Core\Account.update().$params`
  * Add support for `person_token` on `V2\Core\AccountPerson.create().$params` and `V2\Core\AccountPerson.update().$params`
  * Add support for `impacted_requests_percentage` on `EventsV2CoreHealthApiErrorFiringEvent.impact`, `EventsV2CoreHealthApiErrorResolvedEvent.impact`, `EventsV2CoreHealthApiLatencyFiringEvent.impact`, `EventsV2CoreHealthApiLatencyResolvedEvent.impact`, `EventsV2CoreHealthPaymentMethodErrorFiringEvent.impact`, and `EventsV2CoreHealthPaymentMethodErrorResolvedEvent.impact`
  * Add support for `context` and `related_object` on `EventsV2CoreHealthEventGenerationFailureResolvedEvent.impact`
  * Remove support for `account`, `livemode`, `missing_delivery_attempts`, and `related_object_id` on `EventsV2CoreHealthEventGenerationFailureResolvedEvent.impact`
  * Change type of `EventsV2CoreHealthFraudRateIncreasedEvent.impact.realized_fraud_amount` from `amount` to `an object`
  * Change type of `EventsV2CoreHealthIssuingAuthorizationRequestErrorsFiringEvent.impact.approved_amount`, `EventsV2CoreHealthIssuingAuthorizationRequestErrorsResolvedEvent.impact.approved_amount`, `EventsV2CoreHealthIssuingAuthorizationRequestTimeoutFiringEvent.impact.approved_amount`, and `EventsV2CoreHealthIssuingAuthorizationRequestTimeoutResolvedEvent.impact.approved_amount` from `amount` to `an object`
  * Change type of `EventsV2CoreHealthIssuingAuthorizationRequestErrorsFiringEvent.impact.declined_amount`, `EventsV2CoreHealthIssuingAuthorizationRequestErrorsResolvedEvent.impact.declined_amount`, `EventsV2CoreHealthIssuingAuthorizationRequestTimeoutFiringEvent.impact.declined_amount`, and `EventsV2CoreHealthIssuingAuthorizationRequestTimeoutResolvedEvent.impact.declined_amount` from `amount` to `an object`
  * Add support for thin events `V2PaymentsOffSessionPaymentAttemptFailedEvent` and `V2PaymentsOffSessionPaymentAttemptStartedEvent` with related object `V2.Payments.OffSessionPayment`
  * Remove support for thin event `V1AccountUpdatedEvent` with related object `Account`
  * Remove support for thin events `V1ApplicationFeeCreatedEvent` and `V1ApplicationFeeRefundedEvent` with related object `ApplicationFee`
  * Remove support for thin events `V1BillingPortalConfigurationCreatedEvent` and `V1BillingPortalConfigurationUpdatedEvent` with related object `BillingPortal.Configuration`
  * Remove support for thin event `V1CapabilityUpdatedEvent` with related object `Capability`
  * Remove support for thin events `V1ChargeCapturedEvent`, `V1ChargeExpiredEvent`, `V1ChargeFailedEvent`, `V1ChargePendingEvent`, `V1ChargeRefundedEvent`, `V1ChargeSucceededEvent`, and `V1ChargeUpdatedEvent` with related object `Charge`
  * Remove support for thin events `V1ChargeDisputeClosedEvent`, `V1ChargeDisputeCreatedEvent`, `V1ChargeDisputeFundsReinstatedEvent`, `V1ChargeDisputeFundsWithdrawnEvent`, and `V1ChargeDisputeUpdatedEvent` with related object `Dispute`
  * Remove support for thin events `V1ChargeRefundUpdatedEvent`, `V1RefundCreatedEvent`, `V1RefundFailedEvent`, and `V1RefundUpdatedEvent` with related object `Refund`
  * Remove support for thin events `V1CheckoutSessionAsyncPaymentFailedEvent`, `V1CheckoutSessionAsyncPaymentSucceededEvent`, `V1CheckoutSessionCompletedEvent`, and `V1CheckoutSessionExpiredEvent` with related object `Checkout.Session`
  * Remove support for thin events `V1ClimateOrderCanceledEvent`, `V1ClimateOrderCreatedEvent`, `V1ClimateOrderDelayedEvent`, `V1ClimateOrderDeliveredEvent`, and `V1ClimateOrderProductSubstitutedEvent` with related object `Climate.Order`
  * Remove support for thin events `V1ClimateProductCreatedEvent` and `V1ClimateProductPricingUpdatedEvent` with related object `Climate.Product`
  * Remove support for thin events `V1CouponCreatedEvent`, `V1CouponDeletedEvent`, and `V1CouponUpdatedEvent` with related object `Coupon`
  * Remove support for thin events `V1CreditNoteCreatedEvent`, `V1CreditNoteUpdatedEvent`, and `V1CreditNoteVoidedEvent` with related object `CreditNote`
  * Remove support for thin events `V1CustomerCreatedEvent`, `V1CustomerDeletedEvent`, and `V1CustomerUpdatedEvent` with related object `Customer`
  * Remove support for thin events `V1CustomerSubscriptionCreatedEvent`, `V1CustomerSubscriptionDeletedEvent`, `V1CustomerSubscriptionPausedEvent`, `V1CustomerSubscriptionPendingUpdateAppliedEvent`, `V1CustomerSubscriptionPendingUpdateExpiredEvent`, `V1CustomerSubscriptionResumedEvent`, `V1CustomerSubscriptionTrialWillEndEvent`, and `V1CustomerSubscriptionUpdatedEvent` with related object `Subscription`
  * Remove support for thin events `V1CustomerTaxIdCreatedEvent`, `V1CustomerTaxIdDeletedEvent`, and `V1CustomerTaxIdUpdatedEvent` with related object `TaxId`
  * Remove support for thin event `V1FileCreatedEvent` with related object `File`
  * Remove support for thin events `V1FinancialConnectionsAccountCreatedEvent`, `V1FinancialConnectionsAccountDeactivatedEvent`, `V1FinancialConnectionsAccountDisconnectedEvent`, `V1FinancialConnectionsAccountReactivatedEvent`, `V1FinancialConnectionsAccountRefreshedBalanceEvent`, `V1FinancialConnectionsAccountRefreshedOwnershipEvent`, and `V1FinancialConnectionsAccountRefreshedTransactionsEvent` with related object `FinancialConnections.Account`
  * Remove support for thin events `V1IdentityVerificationSessionCanceledEvent`, `V1IdentityVerificationSessionCreatedEvent`, `V1IdentityVerificationSessionProcessingEvent`, `V1IdentityVerificationSessionRedactedEvent`, `V1IdentityVerificationSessionRequiresInputEvent`, and `V1IdentityVerificationSessionVerifiedEvent` with related object `Identity.VerificationSession`
  * Remove support for thin events `V1InvoiceCreatedEvent`, `V1InvoiceDeletedEvent`, `V1InvoiceFinalizationFailedEvent`, `V1InvoiceFinalizedEvent`, `V1InvoiceMarkedUncollectibleEvent`, `V1InvoiceOverdueEvent`, `V1InvoiceOverpaidEvent`, `V1InvoicePaidEvent`, `V1InvoicePaymentActionRequiredEvent`, `V1InvoicePaymentFailedEvent`, `V1InvoicePaymentSucceededEvent`, `V1InvoiceSentEvent`, `V1InvoiceUpcomingEvent`, `V1InvoiceUpdatedEvent`, `V1InvoiceVoidedEvent`, and `V1InvoiceWillBeDueEvent` with related object `Invoice`
  * Remove support for thin event `V1InvoicePaymentPaidEvent` with related object `InvoicePayment`
  * Remove support for thin events `V1InvoiceitemCreatedEvent` and `V1InvoiceitemDeletedEvent` with related object `InvoiceItem`
  * Remove support for thin events `V1IssuingAuthorizationCreatedEvent`, `V1IssuingAuthorizationRequestEvent`, and `V1IssuingAuthorizationUpdatedEvent` with related object `Issuing.Authorization`
  * Remove support for thin events `V1IssuingCardCreatedEvent` and `V1IssuingCardUpdatedEvent` with related object `Issuing.Card`
  * Remove support for thin events `V1IssuingCardholderCreatedEvent` and `V1IssuingCardholderUpdatedEvent` with related object `Issuing.Cardholder`
  * Remove support for thin events `V1IssuingDisputeClosedEvent`, `V1IssuingDisputeCreatedEvent`, `V1IssuingDisputeFundsReinstatedEvent`, `V1IssuingDisputeFundsRescindedEvent`, `V1IssuingDisputeSubmittedEvent`, and `V1IssuingDisputeUpdatedEvent` with related object `Issuing.Dispute`
  * Remove support for thin events `V1IssuingPersonalizationDesignActivatedEvent`, `V1IssuingPersonalizationDesignDeactivatedEvent`, `V1IssuingPersonalizationDesignRejectedEvent`, and `V1IssuingPersonalizationDesignUpdatedEvent` with related object `Issuing.PersonalizationDesign`
  * Remove support for thin events `V1IssuingTokenCreatedEvent` and `V1IssuingTokenUpdatedEvent` with related object `Issuing.Token`
  * Remove support for thin events `V1IssuingTransactionCreatedEvent`, `V1IssuingTransactionPurchaseDetailsReceiptUpdatedEvent`, and `V1IssuingTransactionUpdatedEvent` with related object `Issuing.Transaction`
  * Remove support for thin event `V1MandateUpdatedEvent` with related object `Mandate`
  * Remove support for thin events `V1PaymentIntentAmountCapturableUpdatedEvent`, `V1PaymentIntentCanceledEvent`, `V1PaymentIntentCreatedEvent`, `V1PaymentIntentPartiallyFundedEvent`, `V1PaymentIntentPaymentFailedEvent`, `V1PaymentIntentProcessingEvent`, `V1PaymentIntentRequiresActionEvent`, and `V1PaymentIntentSucceededEvent` with related object `PaymentIntent`
  * Remove support for thin events `V1PaymentLinkCreatedEvent` and `V1PaymentLinkUpdatedEvent` with related object `PaymentLink`
  * Remove support for thin events `V1PaymentMethodAttachedEvent`, `V1PaymentMethodAutomaticallyUpdatedEvent`, `V1PaymentMethodDetachedEvent`, and `V1PaymentMethodUpdatedEvent` with related object `PaymentMethod`
  * Remove support for thin events `V1PayoutCanceledEvent`, `V1PayoutCreatedEvent`, `V1PayoutFailedEvent`, `V1PayoutPaidEvent`, `V1PayoutReconciliationCompletedEvent`, and `V1PayoutUpdatedEvent` with related object `Payout`
  * Remove support for thin events `V1PersonCreatedEvent`, `V1PersonDeletedEvent`, and `V1PersonUpdatedEvent` with related object `Person`
  * Remove support for thin events `V1PlanCreatedEvent`, `V1PlanDeletedEvent`, and `V1PlanUpdatedEvent` with related object `Plan`
  * Remove support for thin events `V1PriceCreatedEvent`, `V1PriceDeletedEvent`, and `V1PriceUpdatedEvent` with related object `Price`
  * Remove support for thin events `V1ProductCreatedEvent`, `V1ProductDeletedEvent`, and `V1ProductUpdatedEvent` with related object `Product`
  * Remove support for thin events `V1PromotionCodeCreatedEvent` and `V1PromotionCodeUpdatedEvent` with related object `PromotionCode`
  * Remove support for thin events `V1QuoteAcceptedEvent`, `V1QuoteCanceledEvent`, `V1QuoteCreatedEvent`, and `V1QuoteFinalizedEvent` with related object `Quote`
  * Remove support for thin events `V1RadarEarlyFraudWarningCreatedEvent` and `V1RadarEarlyFraudWarningUpdatedEvent` with related object `Radar.EarlyFraudWarning`
  * Remove support for thin events `V1ReviewClosedEvent` and `V1ReviewOpenedEvent` with related object `Review`
  * Remove support for thin events `V1SetupIntentCanceledEvent`, `V1SetupIntentCreatedEvent`, `V1SetupIntentRequiresActionEvent`, `V1SetupIntentSetupFailedEvent`, and `V1SetupIntentSucceededEvent` with related object `SetupIntent`
  * Remove support for thin event `V1SigmaScheduledQueryRunCreatedEvent` with related object `Sigma.ScheduledQueryRun`
  * Remove support for thin events `V1SourceCanceledEvent`, `V1SourceChargeableEvent`, `V1SourceFailedEvent`, and `V1SourceRefundAttributesRequiredEvent` with related object `Source`
  * Remove support for thin events `V1SubscriptionScheduleAbortedEvent`, `V1SubscriptionScheduleCanceledEvent`, `V1SubscriptionScheduleCompletedEvent`, `V1SubscriptionScheduleCreatedEvent`, `V1SubscriptionScheduleExpiringEvent`, `V1SubscriptionScheduleReleasedEvent`, and `V1SubscriptionScheduleUpdatedEvent` with related object `SubscriptionSchedule`
  * Remove support for thin events `V1TaxRateCreatedEvent` and `V1TaxRateUpdatedEvent` with related object `TaxRate`
  * Remove support for thin events `V1TerminalReaderActionFailedEvent`, `V1TerminalReaderActionSucceededEvent`, and `V1TerminalReaderActionUpdatedEvent` with related object `Terminal.Reader`
  * Remove support for thin events `V1TestHelpersTestClockAdvancingEvent`, `V1TestHelpersTestClockCreatedEvent`, `V1TestHelpersTestClockDeletedEvent`, `V1TestHelpersTestClockInternalFailureEvent`, and `V1TestHelpersTestClockReadyEvent` with related object `TestHelpers.TestClock`
  * Remove support for thin events `V1TopupCanceledEvent`, `V1TopupCreatedEvent`, `V1TopupFailedEvent`, `V1TopupReversedEvent`, and `V1TopupSucceededEvent` with related object `Topup`
  * Remove support for thin events `V1TransferCreatedEvent`, `V1TransferReversedEvent`, and `V1TransferUpdatedEvent` with related object `Transfer`
* [#1967](https://github.com/stripe/stripe-php/pull/1967) Update CHANGELOG.md for private preview

## 19.1.0-alpha.1 - 2025-11-18
This release changes the pinned API version to `2025-11-17.preview`.

* [#1963](https://github.com/stripe/stripe-php/pull/1963) Update generated code for private-preview
  * Add support for `billing_schedules_actions` on `Invoice.create_preview().$params.schedule_detail.amendment` and `SubscriptionSchedule.amend().$params.amendment`
* [#1962](https://github.com/stripe/stripe-php/pull/1962) Update generated code for private-preview
  * Add support for new resources `BalanceTransfer` and `Radar.AccountEvaluation`
  * Add support for `create` method on resource `BalanceTransfer`
  * Add support for `create`, `retrieve`, and `update` methods on resource `Radar.AccountEvaluation`
  * Change `Tax.Association.tax_transaction_attempts` to be required
  * Add support for `specified_commercial_transactions_act_url` on `Account.business_profile`, `Account.create().$params.business_profile`, and `Account.update().$params.business_profile`
  * Add support for `paypay_payments` on `Account.create().$params.setting`, `Account.settings`, and `Account.update().$params.setting`
  * Change type of `Billing\Analytics\MeterUsage.retrieve().$params.meter.dimension_filters` from `string` to `array(string)`
  * Change type of `Billing\Analytics\MeterUsage.retrieve().$params.meter.tenant_filters` from `string` to `array(string)`
  * Add support for `payment_method_configuration` on `BillingPortal.Configuration.features.payment_method_update`
  * Add support for `car_rental_data`, `flight_data`, and `lodging_data` on `Charge.capture().$params.payment_detail`, `Charge.update().$params.payment_detail`, `PaymentIntent.capture().$params.payment_detail`, `PaymentIntent.confirm().$params.payment_detail`, `PaymentIntent.create().$params.payment_detail`, and `PaymentIntent.update().$params.payment_detail`
  * Add support for `transaction_id` on `Charge.payment_method_details.ideal`, `PaymentAttemptRecord.payment_method_details.ideal`, and `PaymentRecord.payment_method_details.ideal`
  * Add support for new value `finom` on enums `Charge.payment_method_details.ideal.bank`, `ConfirmationToken.payment_method_preview.ideal.bank`, `PaymentAttemptRecord.payment_method_details.ideal.bank`, `PaymentMethod.ideal.bank`, `PaymentRecord.payment_method_details.ideal.bank`, and `SetupAttempt.payment_method_details.ideal.bank`
  * Add support for new value `FNOMNL22` on enums `Charge.payment_method_details.ideal.bic`, `ConfirmationToken.payment_method_preview.ideal.bic`, `PaymentAttemptRecord.payment_method_details.ideal.bic`, `PaymentMethod.ideal.bic`, `PaymentRecord.payment_method_details.ideal.bic`, and `SetupAttempt.payment_method_details.ideal.bic`
  * Add support for new value `tokenized_account_number_deactivated` on enums `ConfirmationToken.payment_method_preview.us_bank_account.status_details.blocked.reason` and `PaymentMethod.us_bank_account.status_details.blocked.reason`
  * Add support for `created` on `CustomerBalanceTransaction.all().$params` and `InvoicePayment.all().$params`
  * Add support for new values `capital.financing_offer.accepted_other_offer`, `financial_connections.account.account_numbers_updated`, and `financial_connections.account.upcoming_account_number_expiry` on enum `Event.type`
  * Add support for `account_numbers` on `FinancialConnections.Account`
  * Change type of `FinancialConnections.Session.client_secret` from `string` to `nullable(string)`
  * Add support for `fraud_risk` on `Issuing\Authorization.create().$params.risk_assessment`
  * Add support for `latest_fraud_warning` on `Issuing.Card`
  * Add support for `supplementary_purchase_data` on `Order.create().$params.payment.setting.payment_method_option.klarna`, `Order.update().$params.payment.setting.payment_method_option.klarna`, `PaymentIntent.confirm().$params.payment_method_option.klarna`, `PaymentIntent.create().$params.payment_method_option.klarna`, and `PaymentIntent.update().$params.payment_method_option.klarna`
  * Add support for `capture_method` on `PaymentIntent.confirm().$params.payment_method_option.card_present`, `PaymentIntent.create().$params.payment_method_option.card_present`, `PaymentIntent.payment_method_options.card_present`, and `PaymentIntent.update().$params.payment_method_option.card_present`
  * Add support for `allow_redisplay` and `customer_account` on `PaymentMethod.all().$params`
  * Add support for `mb_way` and `twint` on `Refund.destination_details`
  * Change type of `SubscriptionSchedule.update().$params.billing_schedules` from `array(billing_schedules_update_params)` to `emptyable(array(billing_schedules_update_params))`
  * Add support for snapshot events `FINANCIAL_CONNECTIONS_ACCOUNT_ACCOUNT_NUMBERS_UPDATED` and `FINANCIAL_CONNECTIONS_ACCOUNT_UPCOMING_ACCOUNT_NUMBER_EXPIRY` with resource `FinancialConnections.Account`

## 19.0.0 - 2025-11-18
This release changes the pinned API version to `2025-11-17.clover`.

* [#1961](https://github.com/stripe/stripe-php/pull/1961) Update generated code
  * ⚠️ Remove `gt`, `gte`, `lt`, and `lte` on `V2\Core\Event.all().$params` in favor of `created`.
* [#1958](https://github.com/stripe/stripe-php/pull/1958) Update v2 array parameter serialization to use indexed format
  - `Retrieve` and `List` calls for `/v2` endpoints now use indexed format (e.g., `?include[0]=foo&include[1]=bar`) instead of repeated parameter format (e.g., `?include=foo&include=bar`) when communicating with the Stripe API. This may break any unit tests that expect the latter behavior when setting up a mock server. Instead, they should now expect the former.
* [#1956](https://github.com/stripe/stripe-php/pull/1956) Update generated code
  * Add support for new resources `Tax.Association` and `Terminal.OnboardingLink`
  * Add support for `find` method on resource `Tax.Association`
  * Add support for `create` method on resource `Terminal.OnboardingLink`
  * Add support for `payment_method_configuration` on `BillingPortal.Configuration.features.payment_method_update`
  * Add support for `transaction_id` on `Charge.payment_method_details.ideal`, `PaymentAttemptRecord.payment_method_details.ideal`, and `PaymentRecord.payment_method_details.ideal`
  * Add support for new value `finom` on enums `Charge.payment_method_details.ideal.bank`, `ConfirmationToken.payment_method_preview.ideal.bank`, `PaymentAttemptRecord.payment_method_details.ideal.bank`, `PaymentMethod.ideal.bank`, `PaymentRecord.payment_method_details.ideal.bank`, and `SetupAttempt.payment_method_details.ideal.bank`
  * Add support for new value `FNOMNL22` on enums `Charge.payment_method_details.ideal.bic`, `ConfirmationToken.payment_method_preview.ideal.bic`, `PaymentAttemptRecord.payment_method_details.ideal.bic`, `PaymentMethod.ideal.bic`, `PaymentRecord.payment_method_details.ideal.bic`, and `SetupAttempt.payment_method_details.ideal.bic`
  * Add support for new value `tokenized_account_number_deactivated` on enums `ConfirmationToken.payment_method_preview.us_bank_account.status_details.blocked.reason` and `PaymentMethod.us_bank_account.status_details.blocked.reason`
  * Add support for `created` on `CustomerBalanceTransaction.all().$params` and `InvoicePayment.all().$params`
  * Add support for new values `financial_connections.account.account_numbers_updated` and `financial_connections.account.upcoming_account_number_expiry` on enum `Event.type`
  * Add support for `account_numbers` on `FinancialConnections.Account`
  * Change type of `FinancialConnections.Session.client_secret` from `string` to `nullable(string)`
  * Add support for `fraud_risk` on `Issuing\Authorization.create().$params.risk_assessment`
  * Add support for `latest_fraud_warning` on `Issuing.Card`
  * Add support for `hooks` on `PaymentIntent.capture().$params`, `PaymentIntent.confirm().$params`, `PaymentIntent.create().$params`, `PaymentIntent.increment_authorization().$params`, `PaymentIntent.update().$params`, and `PaymentIntent`
  * Add support for `mb_way` and `twint` on `Refund.destination_details`
  * Add support for snapshot events `FINANCIAL_CONNECTIONS_ACCOUNT_ACCOUNT_NUMBERS_UPDATED` and `FINANCIAL_CONNECTIONS_ACCOUNT_UPCOMING_ACCOUNT_NUMBER_EXPIRY` with resource `FinancialConnections.Account`

## 18.3.0-alpha.2 - 2025-11-13
This release changes the pinned API version to `2025-10-29.preview`.

* [#1960](https://github.com/stripe/stripe-php/pull/1960) Update generated code for private-preview
  * Add support for new resource `Issuing.Program`
  * Add support for `all`, `create`, `retrieve`, and `update` methods on resource `Issuing.Program`
  * Add support for `schedule` on `Discount`
  * Add support for `applicable_fees` on `DelegatedCheckout.RequestedSession.total_details`
  * Add support for `schedule_details` on `Invoice.parent`, `InvoiceItem.parent`, `InvoiceLineItem.parent`, and `QuotePreviewInvoice.parent`
  * Add support for new value `schedule_details` on enum `InvoiceItem.parent.type`
  * Add support for `billing_schedules` on `Invoice.create_preview().$params.schedule_detail`, `QuotePreviewSubscriptionSchedule`, `SubscriptionSchedule.create().$params`, `SubscriptionSchedule.update().$params`, and `SubscriptionSchedule`
  * Add support for new value `schedule_details` on enums `Invoice.parent.type` and `QuotePreviewInvoice.parent.type`
  * Add support for new value `schedule_details` on enum `InvoiceLineItem.parent.type`
  * Add support for `latest_invoice` on `QuotePreviewSubscriptionSchedule` and `SubscriptionSchedule`
  * Add support for `phase_effective_at` on `QuotePreviewSubscriptionSchedule.default_settings`, `SubscriptionSchedule.create().$params.default_setting`, `SubscriptionSchedule.default_settings`, and `SubscriptionSchedule.update().$params.default_setting`
* [#1954](https://github.com/stripe/stripe-php/pull/1954) Update generated code for private-preview
  * Remove support for resource `V2.Tax.AutomaticRule`
  * Remove support for `create`, `deactivate`, `find`, `retrieve`, and `update` methods on resource `V2.Tax.AutomaticRule`
  * Add support for `self_reported_income` and `self_reported_monthly_housing_payment` on `Account.create().$params.individual`, `Account.update().$params.individual`, `Person.create().$params`, `Person.update().$params`, `Person`, `Token.create().$params.account.individual`, and `Token.create().$params.person`
  * Add support for `billing_schedules` and `phase_effective_at` on `Quote.create().$params.subscription_data_override`, `Quote.create().$params.subscription_datum`, `Quote.subscription_data_overrides[]`, `Quote.subscription_data`, `Quote.update().$params.subscription_data_override`, and `Quote.update().$params.subscription_datum`
  * Add support for `bill_from` on `Subscription.billing_schedules[]`
  * Add support for `amendment_end` and `line_ends_at` on `Subscription.billing_schedules[].bill_until`
  * Add support for new values `amendment_end`, `line_ends_at`, `schedule_end`, and `upcoming_invoice` on enum `Subscription.billing_schedules[].bill_until.type`

## 18.3.0-alpha.1 - 2025-11-06
* [#1951](https://github.com/stripe/stripe-php/pull/1951) Update generated code for private-preview
  * Add support for new resources `TransitBalance`, `V2.Reporting.ReportRun`, `V2.Reporting.Report`
  * Add support for `create` and `retrieve` methods on resource `V2.Reporting.ReportRun`
  * Add support for `retrieve` method on resource `V2.Reporting.Report`
  * Add support for `create` and `refill` test helper methods on resource `Capital.FinancingOffer`
  * Add support for `allocated_funds` on `Charge`, `PaymentIntent.confirm().$params`, `PaymentIntent.create().$params`, and `PaymentIntent.update().$params`
  * Add support for thin events `V2ReportingReportRunCreatedEvent`, `V2ReportingReportRunFailedEvent`, `V2ReportingReportRunSucceededEvent`, and `V2ReportingReportRunUpdatedEvent` with related object `V2.Reporting.ReportRun`

## 18.2.0 - 2025-11-05
* [#1953](https://github.com/stripe/stripe-php/pull/1953) Update generated code
  * Add support for `capture_method` on `PaymentIntent.confirm().$params.payment_method_option.card_present`, `PaymentIntent.create().$params.payment_method_option.card_present`, `PaymentIntent.payment_method_options.card_present`, and `PaymentIntent.update().$params.payment_method_option.card_present`

## 18.2.0-beta.1 - 2025-10-29

This release changes the pinned API version to `2025-10-29.preview`.

* [#1945](https://github.com/stripe/stripe-php/pull/1945) Update generated code for beta
  * Add support for `crypto_storer` on `V2\Core\Account.update().$params.identity.attestation.terms_of_service`
* [#1937](https://github.com/stripe/stripe-php/pull/1937) Update generated code for beta
  * Add support for `update` method on resource `V2.MoneyManagement.FinancialAccount`
  * Add support for `all`, `confirm_microdeposits`, and `send_microdeposits` methods on resource `V2.Core.Vault.UsBankAccount`
  * Add support for `all` method on resource `V2.Core.Vault.GbBankAccount`
  * Add support for new value `verification_data_not_found` on enums `Account.future_requirements.errors[].code`, `Account.requirements.errors[].code`, `BankAccount.future_requirements.errors[].code`, `BankAccount.requirements.errors[].code`, `Capability.future_requirements.errors[].code`, `Capability.requirements.errors[].code`, `Person.future_requirements.errors[].code`, and `Person.requirements.errors[].code`
  * Add support for `payment_portal_url` on `Charge.payment_method_details.rechnung`, `PaymentAttemptRecord.payment_method_details.rechnung`, and `PaymentRecord.payment_method_details.rechnung`
  * Add support for `tax_id_element` on `CustomerSession.components` and `CustomerSession.create().$params.component`
  * Add support for `starting_after` on `PaymentAttemptRecord.all().$params`
  * Add support for new value `solana` on enums `PaymentAttemptRecord.payment_method_details.crypto.network` and `PaymentRecord.payment_method_details.crypto.network`
  * Add support for `reference` on `PaymentIntent.capture().$params.amount_detail.line_item.payment_method_option.klarna`, `PaymentIntent.confirm().$params.amount_detail.line_item.payment_method_option.klarna`, `PaymentIntent.create().$params.amount_detail.line_item.payment_method_option.klarna`, `PaymentIntent.increment_authorization().$params.amount_detail.line_item.payment_method_option.klarna`, `PaymentIntent.update().$params.amount_detail.line_item.payment_method_option.klarna`, and `PaymentIntentAmountDetailsLineItem.payment_method_options.klarna`
  * Change `PaymentIntent.payment_details.customer_reference` to be required
  * Change `PaymentIntent.payment_details.order_reference` to be required
  * Add support for `subscription_reference` on `PaymentIntentAmountDetailsLineItem.payment_method_options.klarna`
  * Add support for `closed` on `V2.Core.Account` and `V2\Core\Account.all().$params`
  * Add support for new value `payment_method` on enum `V2.Core.Account.configuration.customer.automatic_indirect_tax.location_source`
  * Add support for `usd` on `V2.Core.Account.configuration.storer.capabilities.holds_currencies`, `V2\Core\Account.create().$params.configuration.storer.capability.holds_currency`, and `V2\Core\Account.update().$params.configuration.storer.capability.holds_currency`
  * Add support for new values `application_custom` and `application_express` on enum `V2.Core.Account.defaults.responsibilities.fees_collector`
  * Add support for `representative_declaration` on `V2.Core.Account.identity.attestations`, `V2\Core\Account.create().$params.identity.attestation`, and `V2\Core\Account.update().$params.identity.attestation`
  * Add support for new value `holds_currencies.usd` on enum `V2.Core.Account.requirements.entries[].impact.restricts_capabilities[].capability`
  * Add support for `verification` on `V2.Core.Vault.UsBankAccount`
  * Add support for `v1_id` on `EventsV2MoneyManagementTransactionCreatedEvent`
  * Remove support for thin event `V2BillingBillSettingUpdatedEvent` with related object `V2.Billing.BillSetting`
  * Add support for error code `payment_intent_rate_limit_exceeded` on `QuotePreviewInvoice.last_finalization_error`
* [#1930](https://github.com/stripe/stripe-php/pull/1930) Update generated code for beta
  * Add support for `last_seen_at` on `Terminal.Reader`

## 18.2.0-alpha.2 - 2025-10-30
* [#1949](https://github.com/stripe/stripe-php/pull/1949) Update generated code for private-preview
  * Change `DelegatedCheckout\RequestedSession.update().$params.line_item_detail.quantity` to be required
  * Add support for `payment_method_preview` on `DelegatedCheckout.RequestedSession`
  * Add support for `order_id` on `DelegatedCheckout.RequestedSession.order_details`
  * Add support for `lead` on `V2.Core.Account.configuration.card_creator.capabilities.commercial`, `V2.Core.Account.identity.attestations.terms_of_service.card_creator.commercial`, `V2\Core\Account.create().$params.configuration.card_creator.capability.commercial`, `V2\Core\Account.create().$params.identity.attestation.terms_of_service.card_creator.commercial`, `V2\Core\Account.update().$params.configuration.card_creator.capability.commercial`, and `V2\Core\Account.update().$params.identity.attestation.terms_of_service.card_creator.commercial`
  * Add support for `global_account_holder` on `V2.Core.Account.identity.attestations.terms_of_service.card_creator.commercial`, `V2\Core\Account.create().$params.identity.attestation.terms_of_service.card_creator.commercial`, and `V2\Core\Account.update().$params.identity.attestation.terms_of_service.card_creator.commercial`
  * Add support for new value `commercial.lead.prepaid_card` on enum `V2.Core.Account.requirements.entries[].impact.restricts_capabilities[].capability`
  * Add support for new value `commercial.lead.prepaid_card` on enum `EventsV2CoreAccountIncludingConfigurationCardCreatorCapabilityStatusUpdatedEvent.updated_capability`

## 18.2.0-alpha.1 - 2025-10-29

* [#1944](https://github.com/stripe/stripe-php/pull/1944) Update generated code for private-preview
  * Add support for `report_refund` method on resource `PaymentRecord`
  * Add support for new value `verification_data_not_found` on enums `Account.future_requirements.errors[].code`, `Account.requirements.errors[].code`, `BankAccount.future_requirements.errors[].code`, `BankAccount.requirements.errors[].code`, `Capability.future_requirements.errors[].code`, `Capability.requirements.errors[].code`, `Person.future_requirements.errors[].code`, and `Person.requirements.errors[].code`
  * Add support for `tenants` on `Billing.Analytics.MeterUsageRow`
  * Add support for `representative_declaration` on `Account.company`, `Account.create().$params.company`, `Account.update().$params.company`, and `Token.create().$params.account.company`
  * Add support for `transfer` on `ApplicationFee.fee_source`
  * Add support for new value `transfer` on enum `ApplicationFee.fee_source.type`
  * Add support for `transit_balances_total` on `Balance`
  * Add support for new value `transit` on enum `BalanceTransaction.balance_type`
  * Add support for `tenant_group_by_keys` on `Billing\Analytics\MeterUsage.retrieve().$params.meter`
  * Change `Billing\CreditGrant.create().$params.category` to be optional
  * Add support for `payment_method_configuration` on `BillingPortal\Configuration.create().$params.feature.payment_method_update` and `BillingPortal\Configuration.update().$params.feature.payment_method_update`
  * Add support for new value `solana` on enums `Charge.payment_method_details.crypto.network`, `PaymentAttemptRecord.payment_method_details.crypto.network`, and `PaymentRecord.payment_method_details.crypto.network`
  * Add support for `payment_portal_url` on `Charge.payment_method_details.rechnung`, `PaymentAttemptRecord.payment_method_details.rechnung`, and `PaymentRecord.payment_method_details.rechnung`
  * Add support for `twint` on `Checkout.Session.payment_method_options` and `Checkout\Session.create().$params.payment_method_option`
  * Add support for new value `custom` on enums `ConfirmationToken.payment_method_preview.type` and `PaymentMethod.type`
  * Change `CreditNote.refunds[].payment_record_refund` to be required
  * Change `CreditNote.refunds[].type` to be required
  * Add support for `customer_sheet`, `mobile_payment_element`, and `tax_id_element` on `CustomerSession.components` and `CustomerSession.create().$params.component`
  * Add support for `provider` on `Customer.tax`
  * Remove support for `risk_details` on `DelegatedCheckout\RequestedSession.create().$params`
  * Add support for `risk_details` on `DelegatedCheckout\RequestedSession.confirm().$params`
  * Add support for new value `platform_terms_of_service` on enum `File.purpose`
  * Add support for `starting_after` on `PaymentAttemptRecord.all().$params`
  * Add support for `reference` on `PaymentIntent.capture().$params.amount_detail.line_item.payment_method_option.klarna`, `PaymentIntent.confirm().$params.amount_detail.line_item.payment_method_option.klarna`, `PaymentIntent.create().$params.amount_detail.line_item.payment_method_option.klarna`, `PaymentIntent.increment_authorization().$params.amount_detail.line_item.payment_method_option.klarna`, `PaymentIntent.update().$params.amount_detail.line_item.payment_method_option.klarna`, and `PaymentIntentAmountDetailsLineItem.payment_method_options.klarna`
  * Add support for `allocated_funds` on `PaymentIntent`
  * Change `PaymentIntent.payment_details.customer_reference` to be required
  * Change `PaymentIntent.payment_details.order_reference` to be required
  * Add support for `subscription_reference` on `PaymentIntentAmountDetailsLineItem.payment_method_options.klarna`
  * Add support for `name_collection` on `PaymentLink.create().$params`, `PaymentLink.update().$params`, and `PaymentLink`
  * Add support for `crypto` on `PaymentMethodConfiguration.create().$params`, `PaymentMethodConfiguration.update().$params`, `PaymentMethodConfiguration`, and `Refund.destination_details`
  * Add support for `mb_way` on `PaymentMethodConfiguration.create().$params`, `PaymentMethodConfiguration.update().$params`, and `PaymentMethodConfiguration`
  * Add support for `custom` on `PaymentMethod.create().$params` and `PaymentMethod`
  * Add support for `excluded_payment_method_types` on `SetupIntent.create().$params`, `SetupIntent.update().$params`, and `SetupIntent`
  * Change `SetupIntent.flow_directions` to be optional
  * Add support for `tw` on `Tax.Registration.country_options` and `Tax\Registration.create().$params.country_option`
  * Add support for `gip` on `Terminal.Configuration.tipping`, `Terminal\Configuration.create().$params.tipping`, and `Terminal\Configuration.update().$params.tipping`
  * Add support for `last_seen_at` on `Terminal.Reader`
  * Add support for `application_fee_amount` on `Transfer.create().$params` and `Transfer`
  * Add support for `application_fee` on `Transfer`
  * Add support for `high_risk_activities_description`, `high_risk_activities`, `money_services_description`, `operates_in_prohibited_countries`, `participates_in_regulated_activity`, `purpose_of_funds_description`, `purpose_of_funds`, `regulated_activity`, `source_of_funds_description`, and `source_of_funds` on `V2.Core.Account.configuration.storer`, `V2\Core\Account.create().$params.configuration.storer`, and `V2\Core\Account.update().$params.configuration.storer`
  * Add support for `crypto_wallets` on `V2.Core.Account.configuration.storer.capabilities.financial_addresses`, `V2.Core.Account.configuration.storer.capabilities.outbound_payments`, `V2.Core.Account.configuration.storer.capabilities.outbound_transfers`, `V2\Core\Account.create().$params.configuration.storer.capability.financial_address`, `V2\Core\Account.create().$params.configuration.storer.capability.outbound_payment`, `V2\Core\Account.create().$params.configuration.storer.capability.outbound_transfer`, `V2\Core\Account.update().$params.configuration.storer.capability.financial_address`, `V2\Core\Account.update().$params.configuration.storer.capability.outbound_payment`, and `V2\Core\Account.update().$params.configuration.storer.capability.outbound_transfer`
  * Add support for `usdc` on `V2.Core.Account.configuration.storer.capabilities.holds_currencies`, `V2\Core\Account.create().$params.configuration.storer.capability.holds_currency`, and `V2\Core\Account.update().$params.configuration.storer.capability.holds_currency`
  * Add support for `crypto_storer` on `V2.Core.Account.identity.attestations.terms_of_service` and `V2\Core\Account.create().$params.identity.attestation.terms_of_service`
  * Add support for `compliance_screening_description` on `V2.Core.Account.identity.business_details`, `V2\Core\Account.create().$params.identity.business_detail`, and `V2\Core\Account.update().$params.identity.business_detail`
  * Add support for `external_amount` on `V2.MoneyManagement.ReceivedCredit` and `V2.MoneyManagement.ReceivedDebit`
  * Add support for error code `payment_intent_rate_limit_exceeded` on `Invoice.last_finalization_error`, `PaymentIntent.last_payment_error`, `QuotePreviewInvoice.last_finalization_error`, `SetupAttempt.setup_error`, `SetupIntent.last_setup_error`, and `StripeError`

## 18.1.0 - 2025-10-29

This release changes the pinned API version to `2025-10-29.clover`.

* [#1946](https://github.com/stripe/stripe-php/pull/1946) Update generated code
  * Improve docs for PaymentIntent related endpoints
* [#1942](https://github.com/stripe/stripe-php/pull/1942) Update generated code
  * Add support for new resources `PaymentAttemptRecord`, `PaymentIntentAmountDetailsLineItem`, and `PaymentRecord`
  * Add support for `all` and `retrieve` methods on resource `PaymentAttemptRecord`
  * Add support for `report_payment_attempt_canceled`, `report_payment_attempt_failed`, `report_payment_attempt_guaranteed`, `report_payment_attempt_informational`, `report_payment_attempt`, `report_payment`, `report_refund`, and `retrieve` methods on resource `PaymentRecord`
  * Add support for `all` method on resource `PaymentIntentAmountDetailsLineItem`
  * Add support for `representative_declaration` on `Account.company`, `Account.create().$params.company`, `Account.update().$params.company`, and `Token.create().$params.account.company`
  * Change `Billing\CreditGrant.create().$params.category` to be optional
  * Add support for `payment_method_configuration` on `BillingPortal\Configuration.create().$params.feature.payment_method_update` and `BillingPortal\Configuration.update().$params.feature.payment_method_update`
  * Add support for new value `solana` on enum `Charge.payment_method_details.crypto.network`
  * Add support for `twint` on `Checkout.Session.payment_method_options` and `Checkout\Session.create().$params.payment_method_option`
  * Add support for new value `custom` on enums `ConfirmationToken.payment_method_preview.type` and `PaymentMethod.type`
  * Add support for `payment_record_refund` and `type` on `CreditNote.create().$params.refund`, `CreditNote.preview().$params.refund`, `CreditNote.preview_lines().$params.refund`, and `CreditNote.refunds[]`
  * Add support for `customer_sheet` and `mobile_payment_element` on `CustomerSession.components` and `CustomerSession.create().$params.component`
  * Add support for `provider` on `Customer.tax`
  * Add support for new values `balance_settings.updated` and `invoice.payment_attempt_required` on enum `Event.type`
  * Add support for new value `platform_terms_of_service` on enum `File.purpose`
  * Add support for `payment_record` on `Invoice.attach_payment().$params`, `InvoicePayment.all().$params.payment`, and `InvoicePayment.payment`
  * Change type of `InvoicePayment.all().$params.payment.type` from `literal('payment_intent')` to `enum('payment_intent'|'payment_record')`
  * Add support for new value `custom` on enums `Invoice.payment_settings.payment_method_types` and `Subscription.payment_settings.payment_method_types`
  * Add support for `amount_details` on `PaymentIntent.capture().$params`, `PaymentIntent.confirm().$params`, `PaymentIntent.create().$params`, `PaymentIntent.increment_authorization().$params`, and `PaymentIntent.update().$params`
  * Add support for `payment_details` on `PaymentIntent.capture().$params`, `PaymentIntent.confirm().$params`, `PaymentIntent.create().$params`, `PaymentIntent.increment_authorization().$params`, `PaymentIntent.update().$params`, and `PaymentIntent`
  * Add support for `discount_amount`, `line_items`, `shipping`, and `tax` on `PaymentIntent.amount_details`
  * Add support for `name_collection` on `PaymentLink.create().$params`, `PaymentLink.update().$params`, and `PaymentLink`
  * Add support for new value `mb_way` on enum `PaymentLink.payment_method_types`
  * Add support for `crypto` on `PaymentMethodConfiguration.create().$params`, `PaymentMethodConfiguration.update().$params`, `PaymentMethodConfiguration`, and `Refund.destination_details`
  * Add support for `mb_way` on `PaymentMethodConfiguration.create().$params`, `PaymentMethodConfiguration.update().$params`, and `PaymentMethodConfiguration`
  * Add support for `custom` on `PaymentMethod.create().$params` and `PaymentMethod`
  * Add support for `excluded_payment_method_types` on `SetupIntent.create().$params`, `SetupIntent.update().$params`, and `SetupIntent`
  * Add support for `tw` on `Tax.Registration.country_options` and `Tax\Registration.create().$params.country_option`
  * Add support for `gip` on `Terminal.Configuration.tipping`, `Terminal\Configuration.create().$params.tipping`, and `Terminal\Configuration.update().$params.tipping`
  * Add support for `last_seen_at` on `Terminal.Reader`
  * Add support for `gt`, `gte`, `lt`, `lte`, and `types` on `V2\Core\Event.all().$params`
  * Change `V2\Core\Event.all().$params.object_id` to be optional
  * Add support for snapshot event `BALANCE_SETTINGS_UPDATED` with resource `BalanceSettings`
  * Add support for snapshot event `INVOICE_PAYMENT_ATTEMPT_REQUIRED` with resource `Invoice`
  * Add support for error code `payment_intent_rate_limit_exceeded` on `Invoice.last_finalization_error`, `PaymentIntent.last_payment_error`, `SetupAttempt.setup_error`, `SetupIntent.last_setup_error`, and `StripeError`

## 18.1.0-beta.1 - 2025-09-30
This release changes the pinned API version to `2025-09-30.preview`. It is built on top of SDK version 18.0.0 which contains breaking changes. Please review the [changelog for 18.0.0](https://github.com/stripe/stripe-php/blob/master/CHANGELOG.md#1800---2025-09-30) if upgrading from older SDK versions.

* [#1914](https://github.com/stripe/stripe-php/pull/1914) Update generated code for beta
  * Add support for `attach_cadence` method on resource `Subscription`
  * Add support for `billing_cadence` on `Invoice.create_preview().$params`, `Subscription.create().$params`, `Subscription.update().$params`, and `Subscription`
  * Add support for `billing_cadence_details` on `Invoice.parent` and `QuotePreviewInvoice.parent`
  * Add support for new value `billing_cadence_details` on enums `Invoice.parent.type` and `QuotePreviewInvoice.parent.type`
* [#1907](https://github.com/stripe/stripe-php/pull/1907) Update generated code for beta
  * Add support for new resources `V2.Billing.BillSettingVersion`, `V2.Billing.BillSetting`, `V2.Billing.Cadence`, `V2.Billing.CollectionSettingVersion`, `V2.Billing.CollectionSetting`, and `V2.Billing.Profile`
  * Add support for `all`, `create`, `retrieve`, and `update` methods on resources `V2.Billing.BillSetting`, `V2.Billing.CollectionSetting`, and `V2.Billing.Profile`
  * Add support for `all` and `retrieve` methods on resources `V2.Billing.BillSettingVersion` and `V2.Billing.CollectionSettingVersion`
  * Add support for `all`, `cancel`, `create`, `retrieve`, and `update` methods on resource `V2.Billing.Cadence`
  * Add support for thin event `V2BillingBillSettingUpdatedEvent` with related object `V2.Billing.BillSetting`
  * Remove support for `currency` on `V2\MoneyManagement\FinancialAddress.create().$params`
  * Add support for `amount_details` and `payments_orchestration` on `V2.Payments.OffSessionPayment` and `V2\Payments\OffSessionPayment.create().$params`
  * Add support for `mandate_data` and `payment_method_options` on `V2\Payments\OffSessionPayment.create().$params`
  * Add support for `retry_policy` on `V2.Payments.OffSessionPayment.retry_details` and `V2\Payments\OffSessionPayment.create().$params.retry_detail`
  * Add support for `profile` on `V2.Core.Account.defaults`, `V2\Core\Account.create().$params.default`, and `V2\Core\Account.update().$params.default`
  * Add support for `sepa_bank_account` on `V2.MoneyManagement.FinancialAddress.credentials` and `V2.MoneyManagement.ReceivedCredit.bank_transfer`
  * Add support for new value `sepa_bank_account` on enum `V2.MoneyManagement.FinancialAddress.credentials.type`
  * Add support for new value `crypto_wallet` on enum `V2.Core.Account.configuration.recipient.default_outbound_destination.type`
  * Add support for `settlement_currency` on `V2.MoneyManagement.FinancialAddress`
  * Add support for new value `authorization_expired` on enum `V2.Payments.OffSessionPayment.failure_reason`
  * Change type of `V2.MoneyManagement.OutboundPaymentQuote.fx_quote.lock_expires_at` from `DateTime` to `nullable(DateTime)`
  * Add support for `i_p` on `V2.Core.Account.identity.attestations.directorship_declaration`, `V2.Core.Account.identity.attestations.ownership_declaration`, `V2.Core.Account.identity.attestations.terms_of_service.account`, `V2.Core.Account.identity.attestations.terms_of_service.storer`, `V2.Core.Account.identity.individual.additional_terms_of_service.account`, `V2.Core.Person.additional_terms_of_service.account`, `V2\Core\Account.create().$params.identity.attestation.terms_of_service.account`, `V2\Core\Account.create().$params.identity.attestation.terms_of_service.storer`, `V2\Core\Account.update().$params.identity.attestation.terms_of_service.account`, `V2\Core\Account.update().$params.identity.attestation.terms_of_service.storer`, `V2\Core\Person.create().$params.additional_terms_of_service.account`, and `V2\Core\Person.update().$params.additional_terms_of_service.account`
  * Remove support for `ip` on `V2.Core.Account.identity.attestations.directorship_declaration`, `V2.Core.Account.identity.attestations.ownership_declaration`, `V2.Core.Account.identity.attestations.terms_of_service.account`, `V2.Core.Account.identity.attestations.terms_of_service.storer`, `V2.Core.Account.identity.individual.additional_terms_of_service.account`, `V2.Core.Person.additional_terms_of_service.account`, `V2\Core\Account.create().$params.identity.attestation.terms_of_service.account`, `V2\Core\Account.create().$params.identity.attestation.terms_of_service.storer`, `V2\Core\Account.update().$params.identity.attestation.terms_of_service.account`, `V2\Core\Account.update().$params.identity.attestation.terms_of_service.storer`, `V2\Core\Person.create().$params.additional_terms_of_service.account`, and `V2\Core\Person.update().$params.additional_terms_of_service.account`
  * Remove support for `doing_business_as`, `product_description`, and `url` on `V2.Core.Account.identity.business_details`, `V2\Core\Account.create().$params.identity.business_detail`, and `V2\Core\Account.update().$params.identity.business_detail`
  * Add support for new values `heuristic` and `scheduled` on enum `V2.Payments.OffSessionPayment.retry_details.retry_strategy`
  * Change type of `V2.MoneyManagement.OutboundPaymentQuote.fx_quote.lock_duration` from `literal('five_minutes')` to `enum('five_minutes'|'none')`
  * Add support for new value `none` on enum `V2.MoneyManagement.OutboundPaymentQuote.fx_quote.lock_status`
  * Add support for new value `crypto_wallet` on enum `V2.MoneyManagement.PayoutMethod.type`
  * Add support for `origin_type` on `V2.MoneyManagement.ReceivedCredit.bank_transfer`
  * Remove support for `payment_method_type` on `V2.MoneyManagement.ReceivedCredit.bank_transfer`
  * Add support for `type` on `V2\MoneyManagement\FinancialAddress.create().$params`
  * Add support for new values `financial_addressses.crypto_wallets`, `holds_currencies.usdc`, `outbound_payments.crypto_wallets`, and `outbound_transfers.crypto_wallets` on enum `EventsV2CoreAccountIncludingConfigurationStorerCapabilityStatusUpdatedEvent.updated_capability`
* [#1896](https://github.com/stripe/stripe-php/pull/1896) Update generated code for beta
  * Add support for new resources `Billing.Analytics.MeterUsageRow` and `Billing.Analytics.MeterUsage`
  * Remove support for resources `Billing.MeterUsageRow` and `Billing.MeterUsage`
  * Add support for `retrieve` method on resource `Billing.Analytics.MeterUsage`
  * Remove support for `retrieve` method on resource `Billing.MeterUsage`
  * Add support for `report_payment_attempt_informational` method on resource `PaymentRecord`
  * Add support for `minimum_balance_by_currency` on `BalanceSettings.payments.payouts` and `BalanceSettings.update().$params.payment.payout`
  * Change type of `BalanceSettings.update().$params.payment.settlement_timing.delay_days_override` from `longInteger` to `emptyable(longInteger)`
  * Change `BalanceSettings.update().$params.payments` to be optional
  * Remove support for values `saturday` and `sunday` from enum `BalanceSettings.payments.payouts.schedule.weekly_payout_days`
  * Add support for `delay_days_override` on `BalanceSettings.payments.settlement_timing`
  * Add support for `automatic_tax` and `invoice_creation` on `Checkout\Session.update().$params`
  * Add support for `unit_label` on `Checkout\Session.update().$params.line_item.price_datum.product_datum`
  * Add support for `invoice_settings` on `Checkout\Session.update().$params.subscription_datum`
  * Change `Checkout.Session.collected_information.business_name` to be required
  * Add support for `intended_submission_method` on `Dispute.update().$params` and `Dispute`
  * Change type of `Dispute.smart_disputes.recommended_evidence` from `string` to `array(string)`
  * Add support for `pix` on `Invoice.create().$params.payment_setting.payment_method_option`, `Invoice.payment_settings.payment_method_options`, `Invoice.update().$params.payment_setting.payment_method_option`, `QuotePreviewInvoice.payment_settings.payment_method_options`, `Subscription.create().$params.payment_setting.payment_method_option`, `Subscription.payment_settings.payment_method_options`, and `Subscription.update().$params.payment_setting.payment_method_option`
  * Add support for `billing_schedules` on `Invoice.create_preview().$params.subscription_detail`, `Subscription.create().$params`, `Subscription.update().$params`, and `Subscription`
  * Add support for new value `pix` on enums `Invoice.payment_settings.payment_method_types`, `QuotePreviewInvoice.payment_settings.payment_method_types`, and `Subscription.payment_settings.payment_method_types`
  * Add support for `paypay` on `PaymentAttemptRecord.payment_method_details` and `PaymentRecord.payment_method_details`
  * Add support for `wallet` on `PaymentAttemptRecord.payment_method_details.card` and `PaymentRecord.payment_method_details.card`
  * Change type of `PaymentAttemptRecord.processor_details.custom.payment_reference` and `PaymentRecord.processor_details.custom.payment_reference` from `string` to `nullable(string)`
  * Add support for `flexible` on `QuotePreviewSubscriptionSchedule.billing_mode`
  * Add support for `billed_until` on `SubscriptionItem`
  * Add support for error codes `financial_connections_account_pending_account_numbers` and `financial_connections_account_unavailable_account_numbers` on `QuotePreviewInvoice.last_finalization_error`

## 18.1.0-alpha.4 - 2025-10-23
* [#1941](https://github.com/stripe/stripe-php/pull/1941) Update generated code for private-preview
  * Add support for new resource `V2.Billing.PricingPlanSubscriptionComponents`
  * Add support for `retrieve` method on resource `V2.Billing.PricingPlanSubscriptionComponents`
  * Add support for `dimension_payload_keys` on `Billing.Meter` and `Billing\Meter.create().$params`
  * Add support for `dimension_filters` and `dimension_group_by_keys` on `Billing\MeterEventSummary.all().$params`
  * Add support for `dimensions` on `Billing.MeterEventSummary`
  * Add support for `fulfillment_details` and `payment_method_data` on `DelegatedCheckout\RequestedSession.create().$params` and `DelegatedCheckout\RequestedSession.update().$params`
  * Add support for `line_item_details`, `metadata`, `payment_method`, and `shared_metadata` on `DelegatedCheckout.RequestedSession`, `DelegatedCheckout\RequestedSession.create().$params`, and `DelegatedCheckout\RequestedSession.update().$params`
  * Add support for `currency`, `customer`, and `risk_details` on `DelegatedCheckout\RequestedSession.create().$params`
  * Add support for `seller_details` and `setup_future_usage` on `DelegatedCheckout.RequestedSession` and `DelegatedCheckout\RequestedSession.create().$params`
  * Add support for `amount_subtotal`, `amount_total`, `created_at`, `expires_at`, `order_details`, `shared_payment_issued_token`, `status`, `total_details`, and `updated_at` on `DelegatedCheckout.RequestedSession`
  * Add support for `address`, `email`, `fulfillment_options`, `name`, `phone`, and `selected_fulfillment_option` on `DelegatedCheckout.RequestedSession.fulfillment_details`
  * Add support for new values `billie`, `crypto`, `kr_card`, `kriya`, `mb_way`, `mondu`, `ng_bank_transfer`, `ng_bank`, `ng_card`, `ng_market`, `ng_ussd`, `ng_wallet`, `payco`, `paypay`, `rechnung`, `samsung_pay`, `satispay`, `scalapay`, `sequra`, `sunbit`, `us_bank_account`, and `vipps` on enums `EventsV2CoreHealthAuthorizationRateDropFiringEvent.impact.payment_method_type`, `EventsV2CoreHealthAuthorizationRateDropResolvedEvent.impact.payment_method_type`, `EventsV2CoreHealthPaymentMethodErrorFiringEvent.impact.payment_method_type`, and `EventsV2CoreHealthPaymentMethodErrorResolvedEvent.impact.payment_method_type`

## 18.1.0-alpha.3 - 2025-10-17
* [#1939](https://github.com/stripe/stripe-php/pull/1939) Update generated code for private-preview
  * Add support for new resources `DelegatedCheckout.RequestedSession` and `Identity.BlocklistEntry`
  * Add support for `confirm`, `create`, `expire`, `retrieve`, and `update` methods on resource `DelegatedCheckout.RequestedSession`
  * Add support for `all`, `create`, `disable`, and `retrieve` methods on resource `Identity.BlocklistEntry`
  * Add support for `blocked_by_entry` on `Identity.VerificationReport.document`, `Identity.VerificationReport.selfie`, and `Identity\VerificationReport.all().$params`

## 18.1.0-alpha.2 - 2025-10-09
* [#1938](https://github.com/stripe/stripe-php/pull/1938) Update generated code for private-preview
  * Add support for new resource `PaymentMethodBalance`
  * Add support for `check_balance` method on resource `PaymentMethod`
  * Add support for `benefits` on `Card`, `Charge.payment_method_details.card`, `ConfirmationToken.payment_method_preview.card`, and `PaymentMethod.card`
  * Add support for `benefit` on `PaymentIntent.confirm().$params.payment_detail`, `PaymentIntent.create().$params.payment_detail`, `PaymentIntent.payment_details`, and `PaymentIntent.update().$params.payment_detail`
  * Add support for `setup_details` on `SetupIntent.confirm().$params`, `SetupIntent.create().$params`, `SetupIntent.update().$params`, and `SetupIntent`
  * Add support for new value `card_creator` on enum `V2.Core.Account.applied_configurations`
  * Add support for `card_creator` on `V2.Core.Account.configuration`, `V2.Core.Account.identity.attestations.terms_of_service`, `V2\Core\Account.create().$params.configuration`, `V2\Core\Account.create().$params.identity.attestation.terms_of_service`, `V2\Core\Account.update().$params.configuration`, and `V2\Core\Account.update().$params.identity.attestation.terms_of_service`
  * Add support for new values `commercial.celtic.charge_card`, `commercial.celtic.spend_card`, `commercial.cross_river_bank.charge_card`, `commercial.cross_river_bank.spend_card`, `commercial.stripe.charge_card`, and `commercial.stripe.prepaid_card` on enum `V2.Core.Account.requirements.entries[].impact.restricts_capabilities[].capability`
  * Add support for new value `card_creator` on enum `V2.Core.Account.requirements.entries[].impact.restricts_capabilities[].configuration`
  * Add support for thin events `V2CoreAccountIncludingConfigurationCardCreatorCapabilityStatusUpdatedEvent` and `V2CoreAccountIncludingConfigurationCardCreatorUpdatedEvent` with related object `V2.Core.Account`
  * Remove support for thin events `V1CustomerDiscountCreatedEvent`, `V1CustomerDiscountDeletedEvent`, and `V1CustomerDiscountUpdatedEvent` with related object `Discount`
* [#1933](https://github.com/stripe/stripe-php/pull/1933) Update private preview changelog

## 18.1.0-alpha.1 - 2025-10-01
This release changes the pinned API version to `2025-09-30.preview`. It is built on top of SDK version 18.0.0 and 18.1.0-beta.1 which contain breaking changes. Please review the changelog for these versions if upgrading from older SDK versions.

* [#1906](https://github.com/stripe/stripe-php/pull/1906) Update generated code for private-preview
  * Add support for `paypay_payments` on `Account.capabilities`, `Account.create().$params.capability`, and `Account.update().$params.capability`
  * Add support for `billing_cadence` on `Invoice.all().$params`
  * Add support for `credit_grants` on `Billing\Alert.create().$params.credit_balance_threshold.filter`
  * Add support for `payment_record_refund` and `type` on `CreditNote.create().$params.refund`, `CreditNote.preview().$params.refund`, `CreditNote.preview_lines().$params.refund`, and `CreditNote.refunds[]`
  * Remove support for values `saturday` and `sunday` from enums `Account.settings.payouts.schedule.weekly_payout_days`
  * Add support for `location` and `reader` on `Charge.payment_method_details.paynow`
  * Add support for `paypay` on `Charge.payment_method_details`, `ConfirmationToken.create().$params.payment_method_datum`, `ConfirmationToken.payment_method_preview`, `PaymentIntent.confirm().$params.payment_method_datum`, `PaymentIntent.confirm().$params.payment_method_option`, `PaymentIntent.create().$params.payment_method_datum`, `PaymentIntent.create().$params.payment_method_option`, `PaymentIntent.payment_method_options`, `PaymentIntent.update().$params.payment_method_datum`, `PaymentIntent.update().$params.payment_method_option`, `PaymentMethod.create().$params`, `PaymentMethodConfiguration.create().$params`, `PaymentMethodConfiguration.update().$params`, `PaymentMethodConfiguration`, `PaymentMethod`, `SetupIntent.confirm().$params.payment_method_datum`, `SetupIntent.create().$params.payment_method_datum`, and `SetupIntent.update().$params.payment_method_datum`
* Add support for new value `paypay` on enums `ConfirmationToken.payment_method_preview.type` and `PaymentMethod.type`
* Add support for new value `paypay` on enums `PaymentIntent.excluded_payment_method_types` and `PaymentLink.payment_method_types`
* Remove support for `link` and `pay_by_bank` on `PaymentMethod.update().$params`
* Remove support for `iterations` on `Invoice.create_preview().$params.schedule_detail.phase`, `SubscriptionSchedule.create().$params.phase`, and `SubscriptionSchedule.update().$params.phase`
  * Add support for new resource `V2.MoneyManagement.RecipientVerification`
  * Add support for `acknowledge`, `create`, `recipient_verifications`, and `retrieve` methods on resource `V2.MoneyManagement.RecipientVerification`
  * Add support for `update` method on resources `V2.Billing.PricingPlanSubscription` and `V2.Billing.ServiceAction`
  * Add support for `crypto_wallets` on `V2.Account.configuration.recipient_data.features`, `V2.Core.Account.configuration.recipient.capabilities`, `V2\Account.create().$params.configuration.recipient_datum.feature`, `V2\Account.update().$params.configuration.recipient_datum.feature`, `V2\Core\Account.create().$params.configuration.recipient.capability`, and `V2\Core\Account.update().$params.configuration.recipient.capability`
  * Add support for new value `crypto` on enum `V2.Core.Account.requirements.entries[].impact.restricts_capabilities[].capability`
  * Add support for new value `crypto_wallet` on enum `V2.Account.configuration.recipient_data.default_outbound_destination.type`
  * Add support for new value `crypto_wallets` on enum `V2.Account.configuration.supportable_features.recipient_data`
  * Add support for new value `crypto_wallets` on enum `V2.Account.requirements[].impact.required_for_features`
  * Add support for `lookup_key` on `V2.Billing.Cadence`, `V2\Billing\Cadence.create().$params`, and `V2\Billing\Cadence.update().$params`
  * Add support for `settings_data` on `V2.Billing.Cadence`
  * Change type of `V2.Billing.Cadence.payer.billing_profile` from `nullable(string)` to `string`
  * Add support for `v1_event_id` on `V2.Event`
  * Add support for `recipient_verification` on `V2.MoneyManagement.OutboundPayment`, `V2.MoneyManagement.OutboundTransfer`, `V2\MoneyManagement\OutboundPayment.create().$params`, and `V2\MoneyManagement\OutboundTransfer.create().$params`
  * Add support for `crypto_wallet` on `V2.MoneyManagement.PayoutMethod` and `V2\MoneyManagement\OutboundSetupIntent.create().$params.payout_method_datum`
  * Add support for `custom_pricing_unit_details` on `V2.Billing.RateCardRate.custom_pricing_unit_amount`, `V2.Billing.ServiceAction.credit_grant.amount.custom_pricing_unit`, and `V2.Billing.ServiceAction.credit_grant_per_tenant.amount.custom_pricing_unit`
  * Add support for `origin_type` on `V2.MoneyManagement.ReceivedDebit.bank_transfer`
  * Add support for `sepa_bank_account` on `V2\MoneyManagement\FinancialAddress.create().$params`
  * Remove support for `price` on `V2\Billing\RateCardRate.create().$params`
  * Add support for `lookup_keys` on `V2\Billing\Cadence.all().$params`
  * Change type of `V2\Billing\Cadence.all().$params.include`, `V2\Billing\Cadence.cancel().$params.include`, `V2\Billing\Cadence.create().$params.include`, `V2\Billing\Cadence.retrieve().$params.include`, and `V2\Billing\Cadence.update().$params.include` from `literal('invoice_discount_rules')` to `enum('invoice_discount_rules'|'settings_data')`
  * Remove support for `customer` and `type` on `V2\Billing\Cadence.create().$params.payer`
  * Change `V2\Billing\Cadence.create().$params.payer.billing_profile` to be required
  * Add support for new value `crypto_wallets` on enum `EventsAccountConfigurationRecipientDataFeatureStatusUpdatedEvent.feature_name`
  * Add support for new value `crypto_wallets_v2` on enum `EventsV2CoreAccountIncludingConfigurationRecipientCapabilityStatusUpdatedEvent.updated_capability`
  * Remove support for `alert_id` on `EventsV2CoreHealthApiErrorResolvedEvent`, `EventsV2CoreHealthApiLatencyResolvedEvent`, `EventsV2CoreHealthAuthorizationRateDropResolvedEvent`, `EventsV2CoreHealthIssuingAuthorizationRequestTimeoutResolvedEvent`, `EventsV2CoreHealthPaymentMethodErrorResolvedEvent`, `EventsV2CoreHealthTrafficVolumeDropResolvedEvent`, and `EventsV2CoreHealthWebhookLatencyResolvedEvent`
  * Add support for thin event `V1AccountUpdatedEvent` with related object `V2.Account`
  * Add support for thin events `V1ApplicationFeeCreatedEvent`, `V1ApplicationFeeRefundedEvent`, `V1BillingPortalConfigurationCreatedEvent`, `V1BillingPortalConfigurationUpdatedEvent`, `V1CapabilityUpdatedEvent`, `V1ChargeCapturedEvent`, `V1ChargeDisputeClosedEvent`, `V1ChargeDisputeCreatedEvent`, `V1ChargeDisputeFundsReinstatedEvent`, `V1ChargeDisputeFundsWithdrawnEvent`, `V1ChargeDisputeUpdatedEvent`, `V1ChargeExpiredEvent`, `V1ChargeFailedEvent`, `V1ChargePendingEvent`, `V1ChargeRefundUpdatedEvent`, `V1ChargeRefundedEvent`, `V1ChargeSucceededEvent`, `V1ChargeUpdatedEvent`, `V1CheckoutSessionAsyncPaymentFailedEvent`, `V1CheckoutSessionAsyncPaymentSucceededEvent`, `V1CheckoutSessionCompletedEvent`, `V1CheckoutSessionExpiredEvent`, `V1ClimateOrderCanceledEvent`, `V1ClimateOrderCreatedEvent`, `V1ClimateOrderDelayedEvent`, `V1ClimateOrderDeliveredEvent`, `V1ClimateOrderProductSubstitutedEvent`, `V1ClimateProductCreatedEvent`, `V1ClimateProductPricingUpdatedEvent`, `V1CouponCreatedEvent`, `V1CouponDeletedEvent`, `V1CouponUpdatedEvent`, `V1CreditNoteCreatedEvent`, `V1CreditNoteUpdatedEvent`, `V1CreditNoteVoidedEvent`, `V1CustomerCreatedEvent`, `V1CustomerDeletedEvent`, `V1CustomerDiscountCreatedEvent`, `V1CustomerDiscountDeletedEvent`, `V1CustomerDiscountUpdatedEvent`, `V1CustomerSubscriptionCreatedEvent`, `V1CustomerSubscriptionDeletedEvent`, `V1CustomerSubscriptionPausedEvent`, `V1CustomerSubscriptionPendingUpdateAppliedEvent`, `V1CustomerSubscriptionPendingUpdateExpiredEvent`, `V1CustomerSubscriptionResumedEvent`, `V1CustomerSubscriptionTrialWillEndEvent`, `V1CustomerSubscriptionUpdatedEvent`, `V1CustomerTaxIdCreatedEvent`, `V1CustomerTaxIdDeletedEvent`, `V1CustomerTaxIdUpdatedEvent`, `V1CustomerUpdatedEvent`, `V1FileCreatedEvent`, `V1FinancialConnectionsAccountCreatedEvent`, `V1FinancialConnectionsAccountDeactivatedEvent`, `V1FinancialConnectionsAccountDisconnectedEvent`, `V1FinancialConnectionsAccountReactivatedEvent`, `V1FinancialConnectionsAccountRefreshedBalanceEvent`, `V1FinancialConnectionsAccountRefreshedOwnershipEvent`, `V1FinancialConnectionsAccountRefreshedTransactionsEvent`, `V1IdentityVerificationSessionCanceledEvent`, `V1IdentityVerificationSessionCreatedEvent`, `V1IdentityVerificationSessionProcessingEvent`, `V1IdentityVerificationSessionRedactedEvent`, `V1IdentityVerificationSessionRequiresInputEvent`, `V1IdentityVerificationSessionVerifiedEvent`, `V1InvoiceCreatedEvent`, `V1InvoiceDeletedEvent`, `V1InvoiceFinalizationFailedEvent`, `V1InvoiceFinalizedEvent`, `V1InvoiceMarkedUncollectibleEvent`, `V1InvoiceOverdueEvent`, `V1InvoiceOverpaidEvent`, `V1InvoicePaidEvent`, `V1InvoicePaymentActionRequiredEvent`, `V1InvoicePaymentFailedEvent`, `V1InvoicePaymentPaidEvent`, `V1InvoicePaymentSucceededEvent`, `V1InvoiceSentEvent`, `V1InvoiceUpcomingEvent`, `V1InvoiceUpdatedEvent`, `V1InvoiceVoidedEvent`, `V1InvoiceWillBeDueEvent`, `V1InvoiceitemCreatedEvent`, `V1InvoiceitemDeletedEvent`, `V1IssuingAuthorizationCreatedEvent`, `V1IssuingAuthorizationRequestEvent`, `V1IssuingAuthorizationUpdatedEvent`, `V1IssuingCardCreatedEvent`, `V1IssuingCardUpdatedEvent`, `V1IssuingCardholderCreatedEvent`, `V1IssuingCardholderUpdatedEvent`, `V1IssuingDisputeClosedEvent`, `V1IssuingDisputeCreatedEvent`, `V1IssuingDisputeFundsReinstatedEvent`, `V1IssuingDisputeFundsRescindedEvent`, `V1IssuingDisputeSubmittedEvent`, `V1IssuingDisputeUpdatedEvent`, `V1IssuingPersonalizationDesignActivatedEvent`, `V1IssuingPersonalizationDesignDeactivatedEvent`, `V1IssuingPersonalizationDesignRejectedEvent`, `V1IssuingPersonalizationDesignUpdatedEvent`, `V1IssuingTokenCreatedEvent`, `V1IssuingTokenUpdatedEvent`, `V1IssuingTransactionCreatedEvent`, `V1IssuingTransactionPurchaseDetailsReceiptUpdatedEvent`, `V1IssuingTransactionUpdatedEvent`, `V1MandateUpdatedEvent`, `V1PaymentIntentAmountCapturableUpdatedEvent`, `V1PaymentIntentCanceledEvent`, `V1PaymentIntentCreatedEvent`, `V1PaymentIntentPartiallyFundedEvent`, `V1PaymentIntentPaymentFailedEvent`, `V1PaymentIntentProcessingEvent`, `V1PaymentIntentRequiresActionEvent`, `V1PaymentIntentSucceededEvent`, `V1PaymentLinkCreatedEvent`, `V1PaymentLinkUpdatedEvent`, `V1PaymentMethodAttachedEvent`, `V1PaymentMethodAutomaticallyUpdatedEvent`, `V1PaymentMethodDetachedEvent`, `V1PaymentMethodUpdatedEvent`, `V1PayoutCanceledEvent`, `V1PayoutCreatedEvent`, `V1PayoutFailedEvent`, `V1PayoutPaidEvent`, `V1PayoutReconciliationCompletedEvent`, `V1PayoutUpdatedEvent`, `V1PersonCreatedEvent`, `V1PersonDeletedEvent`, `V1PersonUpdatedEvent`, `V1PlanCreatedEvent`, `V1PlanDeletedEvent`, `V1PlanUpdatedEvent`, `V1PriceCreatedEvent`, `V1PriceDeletedEvent`, `V1PriceUpdatedEvent`, `V1ProductCreatedEvent`, `V1ProductDeletedEvent`, `V1ProductUpdatedEvent`, `V1PromotionCodeCreatedEvent`, `V1PromotionCodeUpdatedEvent`, `V1QuoteAcceptedEvent`, `V1QuoteCanceledEvent`, `V1QuoteCreatedEvent`, `V1QuoteFinalizedEvent`, `V1RadarEarlyFraudWarningCreatedEvent`, `V1RadarEarlyFraudWarningUpdatedEvent`, `V1RefundCreatedEvent`, `V1RefundFailedEvent`, `V1RefundUpdatedEvent`, `V1ReviewClosedEvent`, `V1ReviewOpenedEvent`, `V1SetupIntentCanceledEvent`, `V1SetupIntentCreatedEvent`, `V1SetupIntentRequiresActionEvent`, `V1SetupIntentSetupFailedEvent`, `V1SetupIntentSucceededEvent`, `V1SigmaScheduledQueryRunCreatedEvent`, `V1SourceCanceledEvent`, `V1SourceChargeableEvent`, `V1SourceFailedEvent`, `V1SourceRefundAttributesRequiredEvent`, `V1SubscriptionScheduleAbortedEvent`, `V1SubscriptionScheduleCanceledEvent`, `V1SubscriptionScheduleCompletedEvent`, `V1SubscriptionScheduleCreatedEvent`, `V1SubscriptionScheduleExpiringEvent`, `V1SubscriptionScheduleReleasedEvent`, `V1SubscriptionScheduleUpdatedEvent`, `V1TaxRateCreatedEvent`, `V1TaxRateUpdatedEvent`, `V1TerminalReaderActionFailedEvent`, `V1TerminalReaderActionSucceededEvent`, `V1TerminalReaderActionUpdatedEvent`, `V1TestHelpersTestClockAdvancingEvent`, `V1TestHelpersTestClockCreatedEvent`, `V1TestHelpersTestClockDeletedEvent`, `V1TestHelpersTestClockInternalFailureEvent`, `V1TestHelpersTestClockReadyEvent`, `V1TopupCanceledEvent`, `V1TopupCreatedEvent`, `V1TopupFailedEvent`, `V1TopupReversedEvent`, `V1TopupSucceededEvent`, `V1TransferCreatedEvent`, `V1TransferReversedEvent`, `V1TransferUpdatedEvent`, `V2CoreHealthIssuingAuthorizationRequestErrorsFiringEvent`, and `V2CoreHealthIssuingAuthorizationRequestErrorsResolvedEvent`
  * Add support for thin event `V2CoreClaimableSandboxCreatedEvent` with related object `V2.Core.ClaimableSandbox`
  * Add support for thin events `V2MoneyManagementRecipientVerificationCreatedEvent` and `V2MoneyManagementRecipientVerificationUpdatedEvent` with related object `V2.MoneyManagement.RecipientVerification`
  * Remove support for resources `V2.Reporting.ReportRun`, `V2.Reporting.Report`
  * Remove support for thin events `V2ReportingReportRunCreatedEvent`, `V2ReportingReportRunFailedEvent`, `V2ReportingReportRunSucceededEvent`, and `V2ReportingReportRunUpdatedEvent` with related object `V2.Reporting.ReportRun`

## 18.0.0 - 2025-09-30

This release changes the pinned API version to `2025-09-30.clover` and contains breaking changes (prefixed with ⚠️ below)

* [#1903](https://github.com/stripe/stripe-php/pull/1903) ⚠️ Add strongly typed EventNotifications
  We've overhauled how V2 Events are handled in the SDK! This approach should provide a lot more information at authoring and compile time, leading to more robust integrations. As part of this process, there are a number of changes to be aware of.
  - Added matching `EventNotification` classes for every v2 `Event`. For example, there's now a `V1BillingMeterErrorReportTriggeredEventNotification` to match the existing `V1BillingMeterErrorReportTriggeredEvent`. Each of these interfaces defines a `fetchEvent()` method to retrieve its corresponding event. For events with related objects, there's a `fetchRelatedObject()` method that performs the API call and casts the response to the correct type.
  - ⚠️ Rename function `StripeClient->parseThinEvent` to `StripeClient->parseEventNotification` and remove the `ThinEvent` class.
      - This function now returns a `Stripe\V2\Core\EventNotification` (which is the shared base class that all of the more specific `Stripe\*EventNotifications` classes  share) instead of `ThinEvent`. When applicable, these event notifications will have the `relatedObject` property and a `fetchRelatedObject()` function. They also have a `fetchEvent()` method to retrieve their corresponding `Stripe\Event\*Event` instance.
      - If you parse an event the SDK doesn't have types for (e.g. it's newer than the SDK you're using), you'll get an instance of `Stripe\Events\UnknownEventNotification` instead of a more specific type. It has both the `relatedObject` property and the `FetchRelatedObject()` function (but they may be/return `null`)
  - ⚠️ removed the `Util::json_decode_thin_event_object`. Its functionality was folded into the new `\Stripe\V2\EventNotification::fromJson` method.
* [#1925](https://github.com/stripe/stripe-php/pull/1925) add version deprecation note to README
  - NOTE: we'll be dropping support for PHP 5.6, 7.0, and 7.1 in the next major version (March 2026). The README has been updated with a link to our new [language version support policy](https://docs.stripe.com/sdks/versioning?lang=php#stripe-sdk-language-version-support-policy)
* [#1921](https://github.com/stripe/stripe-php/pull/1921) Update generated code
  * Change `Invoice.id` to be required.
* [#1923](https://github.com/stripe/stripe-php/pull/1923) Update generated code
  * Remove support for `balance_report` and `payout_reconciliation_report` on `AccountSession.components` and `AccountSession.create().$params.component`
* [#1920](https://github.com/stripe/stripe-php/pull/1920) Move `V2.Event` API resources to `V2.Core.Events`
  - ⚠️ Move all V2 Event-related resources (`Event`, `RelatedObject`, etc) from `Stripe\V2` to `Stripe\V2\Core`. They now correctly match their API path and are in line with all other resources. To update your code:
  ```diff
  -Stripe\V2\Event
  +Stripe\V2\Core\Event
  ```
* [#1916](https://github.com/stripe/stripe-php/pull/1916) Add `StripeContext` object
  - Add the `StripeContext` class. Previously you could only send a string for `stripe-context` header.
  - ⚠️ Change `EventNotification` (formerly known as `ThinEvent`)'s `context` property from `string` to `StripeContext`
* [#1905](https://github.com/stripe/stripe-php/pull/1905) Added StripeContext, StripeAccount and StripeVersion to BaseStripeClientInterface
  - ⚠️ Add getter methods `getStripeContext`, `getStripeVersion` and `getStripeAccount` to `BaseStripeClientInterface`. Users with custom StripeClient that implement `StripeClientInterface`, `StripeStreamingClientInterface` or `BaseStripeClientInterface` will have to add implementations for these methods.
* [#1898](https://github.com/stripe/stripe-php/pull/1898) ⚠️ Build SDK w/ V2 OpenAPI spec
  - ⚠️ The delete methods for v2 APIs (the ones in the `StripeClient.v2` namespace) now return a `V2DeletedObject` which has the id of the object that has been deleted and a string representing the type of the object that has been deleted.
  - the generated types of some properties in `EventDestination` changed from `something: null|string` to `something?: string`

* [#1900](https://github.com/stripe/stripe-php/pull/1900), [#1912](https://github.com/stripe/stripe-php/pull/1912) Update generated code based on incoming API changes in the `2025-09-30.clover` API version.
  * ⚠️ Remove support for `link` and `pay_by_bank` on `PaymentMethod.update().$params`
  * ⚠️ Remove support for `coupon` on `Discount`, `PromotionCode.create().$params`, and `PromotionCode`. Use `Discount.source.coupon`, `PromotionCode.create().$params.promotion.code`, and `PromotionCode.promotion.code` instead.
  * ⚠️ Remove support for values `saturday` and `sunday` from enum `Account.settings.payouts.schedule.weekly_payout_days`
  * ⚠️ Remove support for `iterations` on `Invoice.create_preview().$params.schedule_detail.phase`, `SubscriptionSchedule.create().$params.phase`, and `SubscriptionSchedule.update().$params.phase`
  * Add support for new value `prevented` on enum `Dispute.status`
  * Add support for new resource `BalanceSettings`
  * Add support for `retrieve` and `update` methods on resource `BalanceSettings`
  * Add support for new values `external_request` and `unsupported_business_type` on enums `Account.future_requirements.errors[].code`, `Account.requirements.errors[].code`, `BankAccount.future_requirements.errors[].code`, `BankAccount.requirements.errors[].code`, `Capability.future_requirements.errors[].code`, `Capability.requirements.errors[].code`, `Person.future_requirements.errors[].code`, and `Person.requirements.errors[].code`
  * Add support for `source` on `Discount`
  * Add support for `mb_way_payments` on `Account.capabilities`, `Account.create().$params.capability`, and `Account.update().$params.capability`
  * Add support for `trial_update_behavior` on `BillingPortal.Configuration.features.subscription_update`, `BillingPortal\Configuration.create().$params.feature.subscription_update`, and `BillingPortal\Configuration.update().$params.feature.subscription_update`
  * Add support for `mb_way` on `Charge.payment_method_details`, `ConfirmationToken.create().$params.payment_method_datum`, `ConfirmationToken.payment_method_preview`, `PaymentIntent.confirm().$params.payment_method_datum`, `PaymentIntent.confirm().$params.payment_method_option`, `PaymentIntent.create().$params.payment_method_datum`, `PaymentIntent.create().$params.payment_method_option`, `PaymentIntent.payment_method_options`, `PaymentIntent.update().$params.payment_method_datum`, `PaymentIntent.update().$params.payment_method_option`, `PaymentMethod.create().$params`, `PaymentMethod`, `SetupIntent.confirm().$params.payment_method_datum`, `SetupIntent.create().$params.payment_method_datum`, and `SetupIntent.update().$params.payment_method_datum`
  * Add support for `branding_settings` and `name_collection` on `Checkout.Session` and `Checkout\Session.create().$params`
  * Add support for `excluded_payment_method_types` on `Checkout.Session`, `Checkout\Session.create().$params`, `PaymentIntent.confirm().$params`, and `PaymentIntent.update().$params`
  * Add support for `unit_label` on `Checkout\Session.create().$params.line_item.price_datum.product_datum`, `Invoice.add_lines().$params.line.price_datum.product_datum`, `Invoice.update_lines().$params.line.price_datum.product_datum`, `InvoiceLineItem.update().$params.price_datum.product_datum`, and `PaymentLink.create().$params.line_item.price_datum.product_datum`
  * Add support for `alma`, `billie`, and `satispay` on `Checkout.Session.payment_method_options` and `Checkout\Session.create().$params.payment_method_option`
  * Add support for `demo_pay` on `Checkout\Session.create().$params.payment_method_option`
  * Add support for `capture_method` on `Checkout.Session.payment_method_options.affirm`, `Checkout.Session.payment_method_options.afterpay_clearpay`, `Checkout.Session.payment_method_options.amazon_pay`, `Checkout.Session.payment_method_options.card`, `Checkout.Session.payment_method_options.cashapp`, `Checkout.Session.payment_method_options.klarna`, `Checkout.Session.payment_method_options.link`, `Checkout.Session.payment_method_options.mobilepay`, `Checkout.Session.payment_method_options.revolut_pay`, `Checkout\Session.create().$params.payment_method_option.affirm`, `Checkout\Session.create().$params.payment_method_option.afterpay_clearpay`, `Checkout\Session.create().$params.payment_method_option.amazon_pay`, `Checkout\Session.create().$params.payment_method_option.card`, `Checkout\Session.create().$params.payment_method_option.cashapp`, `Checkout\Session.create().$params.payment_method_option.klarna`, `Checkout\Session.create().$params.payment_method_option.link`, `Checkout\Session.create().$params.payment_method_option.mobilepay`, and `Checkout\Session.create().$params.payment_method_option.revolut_pay`
  * Add support for `flexible` on `Checkout\Session.create().$params.subscription_datum.billing_mode`, `Invoice.create_preview().$params.schedule_detail.billing_mode`, `Invoice.create_preview().$params.subscription_detail.billing_mode`, `Quote.create().$params.subscription_datum.billing_mode`, `Quote.subscription_data.billing_mode`, `Subscription.billing_mode`, `Subscription.create().$params.billing_mode`, `Subscription.migrate().$params.billing_mode`, `SubscriptionSchedule.billing_mode`, and `SubscriptionSchedule.create().$params.billing_mode`
  * Add support for `business_name` and `individual_name` on `Checkout.Session.collected_information`, `Checkout.Session.customer_details`, `Customer.create().$params`, `Customer.update().$params`, and `Customer`
  * Add support for new values `mb_way` on enums `ConfirmationToken.payment_method_preview.type` and `PaymentMethod.type`
  * Add support for `chargeback_loss_reason_code` on `Dispute.payment_method_details.klarna`
  * Add support for `net_amount` and `proration_details` on `InvoiceItem`
  * Add support for `fraud_disputability_likelihood` and `risk_assessment` on `Issuing\Authorization.create().$params`
  * Add support for `second_line` on `Issuing.Card`
  * Add support for new values `mb_way` on enum `PaymentIntent.excluded_payment_method_types`
  * Add support for `fr_meal_voucher_conecs` on `PaymentMethodConfiguration.create().$params` and `PaymentMethodConfiguration.update().$params`
  * Add support for `promotion` on `PromotionCode.create().$params` and `PromotionCode`
  * Add support for new values `acknowledged` and `payment_never_settled` on enum `Review.closed_reason`
  * Add support for `provider` on `Tax.Settings.defaults`
  * Add support for `bbpos_wisepad3` on `Terminal.Configuration`, `Terminal\Configuration.create().$params`, and `Terminal\Configuration.update().$params`
  * Add support for `address_kana`, `address_kanji`, `display_name_kana`, `display_name_kanji`, and `phone` on `Terminal.Location`, `Terminal\Location.create().$params`, and `Terminal\Location.update().$params`
  * Change `Terminal\Location.create().$params.address` to be optional
  * Change `Terminal\Location.create().$params.display_name` to be optional
  * Add support for error codes `financial_connections_account_pending_account_numbers` and `financial_connections_account_unavailable_account_numbers` on `Invoice.last_finalization_error`, `PaymentIntent.last_payment_error`, `SetupAttempt.setup_error`, `SetupIntent.last_setup_error`, and `StripeError`

## 17.7.0-alpha.2 - 2025-09-17
* [#1904](https://github.com/stripe/stripe-php/pull/1904) generate private-preview SDK w/ mid Sept changes
  * Add support for `retrieve` method on resource `V2.Core.ClaimableSandbox`
  * Add support for `month_of_year` on `V2.Billing.Cadence.billing_cycle.month` and `V2\Billing\Cadence.create().$params.billing_cycle.month`
  * Add support for `claimed_at`, `expires_at`, `sandbox_details`, and `status` on `V2.Core.ClaimableSandbox`
  * Remove support for `api_keys` on `V2.Core.ClaimableSandbox`
  * Change type of `V2.Core.ClaimableSandbox.claim_url` from `string` to `nullable(string)`
  * Add support for new value `current_billing_period_end` on enum `V2.Billing.IntentAction.deactivate.effective_at.type`
  * Add support for `will_activate_at` and `will_cancel_at` on `V2.Billing.PricingPlanSubscription.servicing_status_transitions` and `V2.Billing.RateCardSubscription.servicing_status_transitions`
  * Add support for `category` and `priority` on `V2.Billing.ServiceAction.credit_grant_per_tenant`, `V2.Billing.ServiceAction.credit_grant`, `V2\Billing\ServiceAction.create().$params.credit_grant_per_tenant`, and `V2\Billing\ServiceAction.create().$params.credit_grant`
  * Change `V2\Billing\LicenseFee.update().$params.display_name` to be optional
  * Add support for `invoices` on `EventsV2BillingCadenceBilledEvent`
  * Add support for thin events `V2CoreClaimableSandboxClaimedEvent`, `V2CoreClaimableSandboxExpiredEvent`, `V2CoreClaimableSandboxExpiringEvent`, and `V2CoreClaimableSandboxSandboxDetailsOwnerAccountUpdatedEvent` with related object `V2.Core.ClaimableSandbox`
  * Remove support for thin event `V2BillingCadenceErroredEvent` with related object `V2.Billing.Cadence`

## 17.7.0-alpha.1 - 2025-08-27
* [#1897](https://github.com/stripe/stripe-php/pull/1897) Use the right API version 2025-08-27.preview
* [#1892](https://github.com/stripe/stripe-php/pull/1892) Update generated code for private-preview
  * Add support for `attach_cadence` method on resource `Subscription`
  * Add support for `currency` and `external_customer_id` on `Billing.AlertTriggered`
  * Add support for `custom_pricing_unit` on `Billing.AlertTriggered`, `Billing.CreditBalanceSummary.balances[].available_balance`, `Billing.CreditBalanceSummary.balances[].ledger_balance`, `Billing.CreditBalanceTransaction.credit.amount`, `Billing.CreditBalanceTransaction.debit.amount`, `Billing.CreditGrant.amount`, and `Billing\CreditGrant.create().$params.amount`
  * Add support for `customer` on `Billing\Alert.all().$params`
  * Change type of `Billing.Alert.alert_type`, `Billing\Alert.all().$params.alert_type`, and `Billing\Alert.create().$params.alert_type` from `literal('usage_threshold')` to `enum('credit_balance_threshold'|'usage_threshold')`
  * Add support for `credit_balance_threshold` on `Billing.Alert` and `Billing\Alert.create().$params`
  * Add support for `billable_items` on `Billing.CreditGrant.applicability_config.scope`, `Billing\CreditBalanceSummary.retrieve().$params.filter.applicability_scope`, and `Billing\CreditGrant.create().$params.applicability_config.scope`
  * Change type of `Billing.CreditBalanceSummary.balances[].available_balance.type`, `Billing.CreditBalanceSummary.balances[].ledger_balance.type`, `Billing.CreditBalanceTransaction.credit.amount.type`, `Billing.CreditBalanceTransaction.debit.amount.type`, `Billing.CreditGrant.amount.type`, and `Billing\CreditGrant.create().$params.amount.type` from `literal('monetary')` to `enum('custom_pricing_unit'|'monetary')`
  * Add support for `license_fee_subscription_details` and `rate_card_subscription_details` on `InvoiceItem.parent` and `InvoiceLineItem.parent`
  * Change type of `InvoiceItem.parent.type` from `literal('subscription_details')` to `enum('license_fee_subscription_details'|'rate_card_subscription_details'|'subscription_details')`
  * Add support for `license_fee_details` and `rate_card_rate_details` on `InvoiceItem.pricing` and `InvoiceLineItem.pricing`
  * Change type of `InvoiceItem.pricing.type` and `InvoiceLineItem.pricing.type` from `literal('price_details')` to `enum('license_fee_details'|'price_details'|'rate_card_rate_details')`
  * Add support for `billing_cadence` on `Invoice.create_preview().$params`, `Subscription.create().$params`, and `Subscription`
  * Add support for `billing_cadence_details` on `Invoice.parent` and `QuotePreviewInvoice.parent`
  * Add support for new value `billing_cadence_details` on enums `Invoice.parent.type` and `QuotePreviewInvoice.parent.type`
  * Add support for new values `license_fee_subscription_details` and `rate_card_subscription_details` on enum `InvoiceLineItem.parent.type`
  * Add support for new resources `V2.Billing.BillSettingVersion`, `V2.Billing.BillSetting`, `V2.Billing.Cadence`, `V2.Billing.CollectionSettingVersion`, `V2.Billing.CollectionSetting`, `V2.Billing.CustomPricingUnit`, `V2.Billing.IntentAction`, `V2.Billing.Intent`, `V2.Billing.LicenseFeeSubscription`, `V2.Billing.LicenseFeeVersion`, `V2.Billing.LicenseFee`, `V2.Billing.LicensedItem`, `V2.Billing.MeteredItem`, `V2.Billing.PricingPlanComponent`, `V2.Billing.PricingPlanSubscription`, `V2.Billing.PricingPlanVersion`, `V2.Billing.PricingPlan`, `V2.Billing.Profile`, `V2.Billing.RateCardRate`, `V2.Billing.RateCardSubscription`, `V2.Billing.RateCardVersion`, `V2.Billing.RateCard`, `V2.Billing.ServiceAction`, `V2.Core.ClaimableSandbox`, `V2.Reporting.ReportRun`, `V2.Reporting.Report`, and `V2.Tax.AutomaticRule`
  * Add support for `create`, `deactivate`, `find`, `retrieve`, and `update` methods on resource `V2.Tax.AutomaticRule`
  * Add support for `create` and `retrieve` methods on resources `V2.Billing.ServiceAction` and `V2.Reporting.ReportRun`
  * Add support for `retrieve` method on resources `V2.Billing.LicenseFeeSubscription` and `V2.Reporting.Report`
  * Add support for `create` method on resource `V2.Core.ClaimableSandbox`
  * Add support for `all`, `cancel`, `create`, `retrieve`, and `update` methods on resources `V2.Billing.Cadence` and `V2.Billing.RateCardSubscription`
  * Add support for `all`, `create`, `retrieve`, and `update` methods on resources `V2.Billing.BillSetting`, `V2.Billing.CollectionSetting`, `V2.Billing.CustomPricingUnit`, `V2.Billing.LicenseFee`, `V2.Billing.LicensedItem`, `V2.Billing.MeteredItem`, `V2.Billing.PricingPlan`, `V2.Billing.Profile`, and `V2.Billing.RateCard`
  * Add support for `all` and `retrieve` methods on resources `V2.Billing.BillSettingVersion`, `V2.Billing.CollectionSettingVersion`, `V2.Billing.IntentAction`, `V2.Billing.LicenseFeeVersion`, `V2.Billing.PricingPlanSubscription`, `V2.Billing.PricingPlanVersion`, and `V2.Billing.RateCardVersion`
  * Add support for `all`, `create`, `delete`, and `retrieve` methods on resource `V2.Billing.RateCardRate`
  * Add support for `all`, `create`, `delete`, `retrieve`, and `update` methods on resource `V2.Billing.PricingPlanComponent`
  * Add support for `all`, `cancel`, `commit`, `create`, `release_reservation`, `reserve`, and `retrieve` methods on resource `V2.Billing.Intent`
  * Add support for `changes` on `V2.Event`
  * Add support for thin events `V2BillingCadenceBilledEvent`, `V2BillingCadenceCanceledEvent`, `V2BillingCadenceCreatedEvent`, and `V2BillingCadenceErroredEvent` with related object `V2.Billing.Cadence`
  * Add support for thin events `V2BillingLicenseFeeCreatedEvent` and `V2BillingLicenseFeeUpdatedEvent` with related object `V2.Billing.LicenseFee`
  * Add support for thin event `V2BillingLicenseFeeVersionCreatedEvent` with related object `V2.Billing.LicenseFeeVersion`
  * Add support for thin events `V2BillingLicensedItemCreatedEvent` and `V2BillingLicensedItemUpdatedEvent` with related object `V2.Billing.LicensedItem`
  * Add support for thin events `V2BillingMeteredItemCreatedEvent` and `V2BillingMeteredItemUpdatedEvent` with related object `V2.Billing.MeteredItem`
  * Add support for thin events `V2BillingPricingPlanCreatedEvent` and `V2BillingPricingPlanUpdatedEvent` with related object `V2.Billing.PricingPlan`
  * Add support for thin events `V2BillingPricingPlanComponentCreatedEvent` and `V2BillingPricingPlanComponentUpdatedEvent` with related object `V2.Billing.PricingPlanComponent`
  * Add support for thin events `V2BillingPricingPlanSubscriptionCollectionAwaitingCustomerActionEvent`, `V2BillingPricingPlanSubscriptionCollectionCurrentEvent`, `V2BillingPricingPlanSubscriptionCollectionPastDueEvent`, `V2BillingPricingPlanSubscriptionCollectionPausedEvent`, `V2BillingPricingPlanSubscriptionCollectionUnpaidEvent`, `V2BillingPricingPlanSubscriptionServicingActivatedEvent`, `V2BillingPricingPlanSubscriptionServicingCanceledEvent`, and `V2BillingPricingPlanSubscriptionServicingPausedEvent` with related object `V2.Billing.PricingPlanSubscription`
  * Add support for thin event `V2BillingPricingPlanVersionCreatedEvent` with related object `V2.Billing.PricingPlanVersion`
  * Add support for thin events `V2BillingRateCardCreatedEvent` and `V2BillingRateCardUpdatedEvent` with related object `V2.Billing.RateCard`
  * Add support for thin event `V2BillingRateCardRateCreatedEvent` with related object `V2.Billing.RateCardRate`
  * Add support for thin events `V2BillingRateCardSubscriptionActivatedEvent`, `V2BillingRateCardSubscriptionCanceledEvent`, `V2BillingRateCardSubscriptionCollectionAwaitingCustomerActionEvent`, `V2BillingRateCardSubscriptionCollectionCurrentEvent`, `V2BillingRateCardSubscriptionCollectionPastDueEvent`, `V2BillingRateCardSubscriptionCollectionPausedEvent`, `V2BillingRateCardSubscriptionCollectionUnpaidEvent`, `V2BillingRateCardSubscriptionServicingActivatedEvent`, `V2BillingRateCardSubscriptionServicingCanceledEvent`, and `V2BillingRateCardSubscriptionServicingPausedEvent` with related object `V2.Billing.RateCardSubscription`
  * Add support for thin event `V2BillingRateCardVersionCreatedEvent` with related object `V2.Billing.RateCardVersion`
  * Add support for thin events `V2CoreHealthApiErrorFiringEvent`, `V2CoreHealthApiErrorResolvedEvent`, `V2CoreHealthApiLatencyFiringEvent`, `V2CoreHealthApiLatencyResolvedEvent`, `V2CoreHealthAuthorizationRateDropFiringEvent`, `V2CoreHealthAuthorizationRateDropResolvedEvent`, `V2CoreHealthEventGenerationFailureResolvedEvent`, `V2CoreHealthFraudRateIncreasedEvent`, `V2CoreHealthIssuingAuthorizationRequestTimeoutFiringEvent`, `V2CoreHealthIssuingAuthorizationRequestTimeoutResolvedEvent`, `V2CoreHealthPaymentMethodErrorFiringEvent`, `V2CoreHealthPaymentMethodErrorResolvedEvent`, `V2CoreHealthTrafficVolumeDropFiringEvent`, `V2CoreHealthTrafficVolumeDropResolvedEvent`, `V2CoreHealthWebhookLatencyFiringEvent`, and `V2CoreHealthWebhookLatencyResolvedEvent`
  * Add support for thin events `V2ReportingReportRunCreatedEvent`, `V2ReportingReportRunFailedEvent`, `V2ReportingReportRunSucceededEvent`, and `V2ReportingReportRunUpdatedEvent` with related object `V2.Reporting.ReportRun`
  * Add support for error type `RateLimitException`
  * Adds `getStripeParam` and `setStripeParam` to ApiErrorException base class.  Currently, this is only used by `RateLimitExceptions` returned from v2 services.

## 17.7.0-beta.1 - 2025-08-27
This release changes the pinned API version to `2025-08-27.preview`.

* [#1888](https://github.com/stripe/stripe-php/pull/1888) Update generated code for beta
  * Add support for `all` and `retrieve` methods on resource `InvoicePayment`
  * Add support for `all` method on resource `Mandate`
  * Add support for `applied` on `V2.Core.Account.configuration.customer`, `V2.Core.Account.configuration.merchant`, `V2.Core.Account.configuration.recipient`, `V2.Core.Account.configuration.storer`, `V2\Core\Account.update().$params.configuration.customer`, `V2\Core\Account.update().$params.configuration.merchant`, `V2\Core\Account.update().$params.configuration.recipient`, and `V2\Core\Account.update().$params.configuration.storer`
  * Add support for new values `ao_nif`, `az_tin`, `bd_etin`, `cr_cpj`, `cr_nite`, `do_rcn`, `gt_nit`, `kz_bin`, `mz_nuit`, `pe_ruc`, `pk_ntn`, `sa_crn`, and `sa_tin` on enum `V2.Core.Account.identity.business_details.id_numbers[].type`
  * Add support for new values `ao_nif`, `az_tin`, `bd_brc`, `bd_etin`, `bd_nid`, `cr_cpf`, `cr_dimex`, `cr_nite`, `do_rcn`, `gt_nit`, `kz_iin`, `mz_nuit`, `pe_dni`, `pk_cnic`, `pk_snic`, and `sa_tin` on enums `V2.Core.Account.identity.individual.id_numbers[].type` and `V2.Core.Person.id_numbers[].type`
  * Change type of `Billing.AlertTriggered.value` from `longInteger` to `decimal_string`
  * Add support for `display_name` on `V2.MoneyManagement.FinancialAccount` and `V2\MoneyManagement\FinancialAccount.create().$params`
  * Add support for new value `currency_conversion` on enums `V2.MoneyManagement.Transaction.category` and `V2.MoneyManagement.TransactionEntry.transaction_details.category`
  * Add support for `currency_conversion` on `V2.MoneyManagement.Transaction.flow` and `V2.MoneyManagement.TransactionEntry.transaction_details.flow`
  * Add support for new value `currency_conversion` on enums `V2.MoneyManagement.Transaction.flow.type` and `V2.MoneyManagement.TransactionEntry.transaction_details.flow.type`
  * Add support for `payments` on `BalanceSettings.update().$params` and `BalanceSettings`
  * Remove support for `debit_negative_balances`, `payouts`, and `settlement_timing` on `BalanceSettings.update().$params` and `BalanceSettings`
  * Add support for `mandate` on `Charge.payment_method_details.pix`, `PaymentAttemptRecord.payment_method_details.pix`, and `PaymentRecord.payment_method_details.pix`
  * Add support for `coupon_data` on `Checkout\Session.create().$params.discount`
  * Add support for `mandate_options` on `Checkout.Session.payment_method_options.pix`, `Checkout\Session.create().$params.payment_method_option.pix`, `PaymentIntent.confirm().$params.payment_method_option.pix`, `PaymentIntent.create().$params.payment_method_option.pix`, `PaymentIntent.payment_method_options.pix`, and `PaymentIntent.update().$params.payment_method_option.pix`
  * Change type of `Checkout.Session.payment_method_options.pix.setup_future_usage`, `Checkout\Session.create().$params.payment_method_option.pix.setup_future_usage`, `PaymentIntent.confirm().$params.payment_method_option.pix.setup_future_usage`, `PaymentIntent.create().$params.payment_method_option.pix.setup_future_usage`, `PaymentIntent.payment_method_options.pix.setup_future_usage`, and `PaymentIntent.update().$params.payment_method_option.pix.setup_future_usage` from `literal('none')` to `enum('none'|'off_session')`
  * Add support for `amount` on `Mandate.multi_use`, `PaymentAttemptRecord`, and `PaymentRecord`
  * Add support for `currency` on `Mandate.multi_use`
  * Add support for `pix` on `Mandate.payment_method_details`, `SetupAttempt.payment_method_details`, `SetupIntent.confirm().$params.payment_method_option`, `SetupIntent.create().$params.payment_method_option`, `SetupIntent.payment_method_options`, and `SetupIntent.update().$params.payment_method_option`
  * Add support for `limit` on `PaymentAttemptRecord.all().$params`
  * Add support for `amount_authorized`, `amount_refunded`, and `application` on `PaymentAttemptRecord` and `PaymentRecord`
  * Add support for `processor_details` on `PaymentAttemptRecord`, `PaymentRecord.report_payment().$params`, and `PaymentRecord`
  * Remove support for `payment_reference` on `PaymentAttemptRecord`, `PaymentRecord.report_payment().$params`, and `PaymentRecord`
  * Add support for `installments` on `PaymentAttemptRecord.payment_method_details.alma` and `PaymentRecord.payment_method_details.alma`
  * Add support for `transaction_id` on `PaymentAttemptRecord.payment_method_details.alma`, `PaymentAttemptRecord.payment_method_details.amazon_pay`, `PaymentAttemptRecord.payment_method_details.billie`, `PaymentAttemptRecord.payment_method_details.kakao_pay`, `PaymentAttemptRecord.payment_method_details.kr_card`, `PaymentAttemptRecord.payment_method_details.naver_pay`, `PaymentAttemptRecord.payment_method_details.payco`, `PaymentAttemptRecord.payment_method_details.revolut_pay`, `PaymentAttemptRecord.payment_method_details.samsung_pay`, `PaymentAttemptRecord.payment_method_details.satispay`, `PaymentRecord.payment_method_details.alma`, `PaymentRecord.payment_method_details.amazon_pay`, `PaymentRecord.payment_method_details.billie`, `PaymentRecord.payment_method_details.kakao_pay`, `PaymentRecord.payment_method_details.kr_card`, `PaymentRecord.payment_method_details.naver_pay`, `PaymentRecord.payment_method_details.payco`, `PaymentRecord.payment_method_details.revolut_pay`, `PaymentRecord.payment_method_details.samsung_pay`, and `PaymentRecord.payment_method_details.satispay`
  * Add support for `location` and `reader` on `PaymentAttemptRecord.payment_method_details.paynow` and `PaymentRecord.payment_method_details.paynow`
  * Add support for `latest_active_mandate` on `PaymentMethod`
  * Change `Payout.payout_method` to be required
  * Add support for `metadata` and `period` on `QuotePreviewSubscriptionSchedule.phases[].add_invoice_items[]`
  * Add support for `pix_display_qr_code` on `SetupIntent.next_action`
  * Add support for `reader_security` on `Terminal.Configuration`, `Terminal\Configuration.create().$params`, and `Terminal\Configuration.update().$params`
  * Add support for error codes `customer_session_expired` and `india_recurring_payment_mandate_canceled` on `QuotePreviewInvoice.last_finalization_error`

## 17.6.0 - 2025-08-27
* [#1895](https://github.com/stripe/stripe-php/pull/1895) Add section on private preview SDKs in readme
* [#1890](https://github.com/stripe/stripe-php/pull/1890) Update generated code. This release changes the pinned API version to `2025-08-27.basil`.
  * Add support for `balance_report`, `payout_details`, and `payout_reconciliation_report` on `AccountSession.components` and `AccountSession.create().$params.component`
  * Add support for `name` on `BillingPortal.Configuration`, `BillingPortal\Configuration.create().$params`, and `BillingPortal\Configuration.update().$params`
  * Add support for `installments` on `Charge.payment_method_details.alma`
  * Add support for `transaction_id` on `Charge.payment_method_details.alma`, `Charge.payment_method_details.amazon_pay`, `Charge.payment_method_details.billie`, `Charge.payment_method_details.kakao_pay`, `Charge.payment_method_details.kr_card`, `Charge.payment_method_details.naver_pay`, `Charge.payment_method_details.payco`, `Charge.payment_method_details.revolut_pay`, `Charge.payment_method_details.samsung_pay`, and `Charge.payment_method_details.satispay`
  * Add support for `location` and `reader` on `Charge.payment_method_details.paynow`
  * Add support for `amount_includes_iof` on `Checkout.Session.payment_method_options.pix`, `Checkout\Session.create().$params.payment_method_option.pix`, `PaymentIntent.confirm().$params.payment_method_option.pix`, `PaymentIntent.create().$params.payment_method_option.pix`, `PaymentIntent.payment_method_options.pix`, and `PaymentIntent.update().$params.payment_method_option.pix`
  * Add support for new values `block` and `resolution` on enum `Dispute.payment_method_details.card.case_type`
  * Add support for new value `terminal_android_apk` on enum `File.purpose`
  * Add support for `metadata` and `period` on `Invoice.create_preview().$params.schedule_detail.phase.add_invoice_item`, `Subscription.create().$params.add_invoice_item`, `Subscription.update().$params.add_invoice_item`, `SubscriptionSchedule.create().$params.phase.add_invoice_item`, `SubscriptionSchedule.phases[].add_invoice_items[]`, and `SubscriptionSchedule.update().$params.phase.add_invoice_item`
  * Add support for `exp_month` and `exp_year` on `Issuing\Card.create().$params`
  * Add support for `excluded_payment_method_types` on `PaymentIntent.create().$params` and `PaymentIntent`
  * Add support for `payout_method` on `Payout.create().$params` and `Payout`
  * Add support for `mxn` on `Terminal.Configuration.tipping`, `Terminal\Configuration.create().$params.tipping`, and `Terminal\Configuration.update().$params.tipping`
  * Add support for `card` on `Terminal\Reader.present_payment_method().$params`
  * Add support for error codes `customer_session_expired` and `india_recurring_payment_mandate_canceled` on `Invoice.last_finalization_error`, `PaymentIntent.last_payment_error`, `SetupAttempt.setup_error`, `SetupIntent.last_setup_error`, and `StripeError`
* [#1894](https://github.com/stripe/stripe-php/pull/1894) Add getter for Stripe Account on BaseStripeClient
  - Add `getStripeAccount` method on `BaseStripeClient` to retrieve [Stripe Account ID](https://docs.stripe.com/connect/authentication?lang=php) from a `StripeClient` instance.

## 17.6.0-beta.2 - 2025-08-08
* [#1891](https://github.com/stripe/stripe-php/pull/1891) Bring back invoice payments APIs that were missing in the public preview SDKs
  * Add support for new resource `InvoicePayment`
  * Add support for `all` and `retrieve` methods on resource `InvoicePayment`

## 17.6.0-beta.1 - 2025-07-30
This release changes the pinned API version to `2025-07-30.preview`.

* [#1885](https://github.com/stripe/stripe-php/pull/1885) Update generated code for beta
  * Add support for new resources `Billing.MeterUsageRow`, `Billing.MeterUsage`, and `Terminal.OnboardingLink`
  * Add support for `retrieve` method on resource `Billing.MeterUsage`
  * Add support for `create` method on resource `Terminal.OnboardingLink`
  * Add support for `smart_disputes` on `Dispute`
  * Add support for new value `upi` on enums `Invoice.payment_settings.payment_method_types`, `QuotePreviewInvoice.payment_settings.payment_method_types`, and `Subscription.payment_settings.payment_method_types`
  * Add support for thin event `V2CoreAccountLinkReturnedEvent`
  * Add support for thin event `V2MoneyManagementPayoutMethodUpdatedEvent` with related object `V2.MoneyManagement.PayoutMethod`
  * Remove support for thin event `V2CoreAccountLinkCompletedEvent`
  * Remove support for thin event `V2OffSessionPaymentRequiresCaptureEvent` with related object `V2.Payments.OffSessionPayment`

## 17.5.0 - 2025-07-30
This release changes the pinned API version to `2025-07-30.basil`.

* [#1887](https://github.com/stripe/stripe-php/pull/1887) Update generated code
  * Add support for `origin_context` on `Checkout.Session`
* [#1881](https://github.com/stripe/stripe-php/pull/1881) Ensure compatibility with POST on older versions of libcurl
  * Fixes an issue with older versions of php/libcurl where certain SDK calls that have empty POST bodies will result in a 400 Bad Request returned from the server.

## 17.5.0-beta.2 - 2025-07-09
* [#1886](https://github.com/stripe/stripe-php/pull/1886) Pull in V2 FinancialAccount changes for June release
  * Add support for `close` and `create` methods on resource `V2.MoneyManagement.FinancialAccount`
  * Add support for new value `storer` on enum `V2.Core.Account.applied_configurations`
  * Add support for `status_details` on `V2.MoneyManagement.FinancialAccount`
  * Add support for thin events `V2CoreAccountIncludingConfigurationStorerCapabilityStatusUpdatedEvent` and `V2CoreAccountIncludingConfigurationStorerUpdatedEvent` with related object `V2.Core.Account`
  * Add support for error types `AlreadyExistsException` and `NonZeroBalanceException`

## 17.5.0-beta.1 - 2025-07-01
This release changes the pinned API version to `2025-06-30.preview`.

* [#1876](https://github.com/stripe/stripe-php/pull/1876) Update generated code for beta
  * Change type of `Quote.subscription_data.billing_mode` from `enum('classic'|'flexible')` to `QuotesResourceSubscriptionDataBillingMode`
  * Add support for new value `crypto` on enum `QuotePreviewInvoice.payment_settings.payment_method_types`
  * Change type of `QuotePreviewSubscriptionSchedule.billing_mode`, `Subscription.billing_mode`, and `SubscriptionSchedule.billing_mode` from `enum('classic'|'flexible')` to `SubscriptionsResourceBillingMode`
  * Remove support for `billing_mode_details` on `Subscription`
  * Add support for new value `xx` on enums `V2.Core.Account.identity.country`, `V2.Core.Person.additional_addresses[].country`, `V2.Core.Person.address.country`, and `V2.MoneyManagement.FinancialAccount.country`
  * Add support for new value `xx` on enum `V2.Core.Person.nationalities`
  * Add support for `metadata` on `V2.MoneyManagement.FinancialAccount`
  * Remove support for `description` on `V2.MoneyManagement.FinancialAccount`
  * Add support for new value `pending` on enum `V2.MoneyManagement.FinancialAccount.status`
  * Remove support for `attempts` on `V2.Payments.OffSessionPayment`
  * Change type of `V2.Payments.OffSessionPayment.transfer_data.amount` from `integer` to `nullable(integer)`
  * Change type of `V2.MoneyManagement.ReceivedCredit.balance_transfer.type` from `literal('payout_v1')` to `enum('outbound_payment'|'outbound_transfer'|'payout_v1')`
  * Change type of `V2.MoneyManagement.ReceivedCredit.balance_transfer.payout_v1` from `string` to `nullable(string)`

## 17.4.0 - 2025-07-01
This release changes the pinned API version to `2025-06-30.basil`.

* [#1880](https://github.com/stripe/stripe-php/pull/1880) Update generated code
  * Add support for `migrate` method on resource `Subscription`
  * Add support for `collect_payment_method` and `confirm_payment_intent` methods on resource `Terminal.Reader`
  * Add support for new value `crypto` on enums `ConfirmationToken.payment_method_preview.type` and `PaymentMethod.type`
  * Change type of `Dispute.enhanced_eligibility_types` from `literal('visa_compelling_evidence_3')` to `enum('visa_compelling_evidence_3'|'visa_compliance')`
  * Add support for new value `terminal.reader.action_updated` on enum `Event.type`
  * Add support for `related_person` on `Identity.VerificationSession`
  * Add support for new value `crypto` on enums `Invoice.payment_settings.payment_method_types` and `Subscription.payment_settings.payment_method_types`
  * Add support for `crypto` on `PaymentMethod`
  * Add support for new value `buut` on enum `PaymentMethod.ideal.bank`
  * Add support for new value `BUUTNL2A` on enum `PaymentMethod.ideal.bic`
  * Add support for `billing_mode` on `SubscriptionSchedule` and `Subscription`
  * Add support for new values `collect_payment_method` and `confirm_payment_intent` on enum `Terminal.Reader.action.type`
  * Add support for snapshot event `TERMINAL_READER_ACTION_UPDATED` with resource `Terminal.Reader`
* [#1878](https://github.com/stripe/stripe-php/pull/1878) Update generated code
  * Add constant `CURRENT_MAJOR` in `ApiVersion`

## 17.4.0-beta.2 - 2025-06-26
* [#1883](https://github.com/stripe/stripe-php/pull/1883) Pull in OffSessionPayment changes for the May release

## 17.4.0-beta.1 - 2025-05-29
This release changes the pinned API version to `2025-05-28.preview`.

* [#1864](https://github.com/stripe/stripe-php/pull/1864) Update generated code for beta
  ### Breaking changes
  * Remove support for deprecated previews
    * Remove support for resources `Billing.MeterErrorReport`, `GiftCards.Card`, `GiftCards.Transaction`, and `Privacy.RedactionJobRootObjects`
    * Remove support for `all`, `create`, `retrieve`, `update`, and `validate` methods on resource `GiftCards.Card`
    * Remove support for `all`, `cancel`, `confirm`, `create`, `retrieve`, and `update` methods on resource `GiftCards.Transaction`
    * Remove support for `provisioning` on `Product`
    * Remove support for snapshot event `BILLING_METER_ERROR_REPORT_TRIGGERED` with resource `Billing.MeterErrorReport`
    * Remove support for error codes `gift_card_balance_insufficient`, `gift_card_code_exists`, and `gift_card_inactive` on `QuotePreviewInvoice.last_finalization_error`
  * Remove support for `amount_remaining` and `credits` on `Order`
  * Change type of `PaymentAttemptRecord.metadata` and `PaymentRecord.metadata` from `nullable(map(string: string))` to `map(string: string)`
  * Remove support for `async_workflows` on `PaymentIntent`
  * Change type of `Privacy.RedactionJob.objects` from `$Privacy.RedactionJobRootObjects` to `RedactionResourceRootObjects`
  * Change type of `Privacy.RedactionJob.status` from `string` to `enum`
  * Change type of `Privacy.RedactionJob.validation_behavior` from `string` to `enum('error'|'fix')`
  * Change type of `Privacy.RedactionJobValidationError.code` from `string` to `enum`
  * Change type of `Privacy.RedactionJobValidationError.erroring_object` from `map(string: string)` to `RedactionResourceErroringObject`
  * Remove support for values `credits_attributed_to_debits` and `legacy_prorations` from enums `Quote.subscription_data.billing_mode`, `QuotePreviewSubscriptionSchedule.billing_mode`, `Subscription.billing_mode`, and `SubscriptionSchedule.billing_mode`
  * Remove support for `status_details` and `status` on `Tax.Association`

  ### Other changes
  * Add support for `migrate` method on resource `Subscription`
  * Add support for `institution` on `FinancialConnections.Account`
  * Add support for `countries` on `FinancialConnections.Institution`
  * Add support for `hooks` on `PaymentIntent`
  * Add support for `livemode` on `Privacy.RedactionJob`
  * Add support for new values `classic` and `flexible` on enums `Quote.subscription_data.billing_mode`, `QuotePreviewSubscriptionSchedule.billing_mode`, `Subscription.billing_mode`, and `SubscriptionSchedule.billing_mode`
  * Add support for `billing_mode_details` on `Subscription`
  * Add support for `tax_transaction_attempts` on `Tax.Association`
  * Add support for error code `forwarding_api_upstream_error` on `QuotePreviewInvoice.last_finalization_error`

## 17.3.0 - 2025-05-29
 This release changes the pinned API version to `2025-05-28.basil`.

* [#1871](https://github.com/stripe/stripe-php/pull/1871) Update generated code
  * Add support for `attach_payment` method on resource `Invoice`
  * Add support for `collect_inputs` method on resource `Terminal.Reader`
  * Add support for `succeed_input_collection` and `timeout_input_collection` test helper methods on resource `Terminal.Reader`
  * Add support for `refund_and_dispute_prefunding` on `Balance`
  * Add support for `balance_type` on `BalanceTransaction`
  * Add support for `post_payment_amount` and `pre_payment_amount` on `CreditNote`
  * Add support for new value `mixed` on enum `CreditNote.type`
  * Add support for new value `invoice_payment.paid` on enum `Event.type`
  * Add support for `kakao_pay`, `kr_card`, `naver_pay`, `payco`, and `samsung_pay` on `PaymentMethodConfiguration`
  * Add support for `billing_thresholds` on `SubscriptionItem` and `Subscription`
  * Add support for `metadata` on `Tax.CalculationLineItem`
  * Add support for new value `collect_inputs` on enum `Terminal.Reader.action.type`
  * Add support for new value `simulated_stripe_s700` on enum `Terminal.Reader.device_type`
  * Add support for snapshot event `INVOICE_PAYMENT_PAID` with resource `InvoicePayment`
  * Add support for error code `forwarding_api_upstream_error` on `Invoice.last_finalization_error`, `PaymentIntent.last_payment_error`, `SetupAttempt.setup_error`, `SetupIntent.last_setup_error`, and `StripeError`

## 17.3.0-beta.1 - 2025-04-30
* [#1859](https://github.com/stripe/stripe-php/pull/1859) Update generated code for beta
  This release changes the pinned API version to `2025-04-30.preview`.

  * Add support for new value `balance_settings.updated` on enum `Event.type`
  * Add support for new values `aw_tin`, `az_tin`, `bd_bin`, `bf_ifu`, `bj_ifu`, `cm_niu`, `cv_nif`, `et_tin`, `kg_tin`, and `la_tin` on enum `QuotePreviewInvoice.customer_tax_ids[].type`
  * Add support for `billing_mode` on `QuotePreviewSubscriptionSchedule`, `SubscriptionSchedule`, and `Subscription`

## 17.2.1 - 2025-05-19
* [#1869](https://github.com/stripe/stripe-php/pull/1869) Fixed type of map parameters(eg. metadata, currency_options) from `StripeObject` to `array<KType, VType>` in all methods.
* [#1866](https://github.com/stripe/stripe-php/pull/1866) Adds CONTRIBUTING.md

## 17.2.0 - 2025-04-30

  This release changes the pinned API version to `2025-04-30.basil`.

* [#1839](https://github.com/stripe/stripe-php/pull/1839) Update generated code
  * Add support for new value `tax_id_prohibited` on enums `Invoice.last_finalization_error.code`, `PaymentIntent.last_payment_error.code`, `SetupAttempt.setup_error.code`, `SetupIntent.last_setup_error.code`, and `StripeError.code`
  * Add support for `wallet_options` on `Checkout.Session`
  * Add support for `context` on `Event`
  * Add support for new values `aw_tin`, `az_tin`, `bd_bin`, `bf_ifu`, `bj_ifu`, `cm_niu`, `cv_nif`, `et_tin`, `kg_tin`, and `la_tin` on enums `Invoice.customer_tax_ids[].type` and `TaxId.type`
  * Add support for new value `affirm` on enums `Invoice.payment_settings.payment_method_types` and `Subscription.payment_settings.payment_method_types`
  * Add support for `pix` on `PaymentMethodConfiguration`
  * Add support for `klarna` on `PaymentMethodDomain`
  * Add support for `us_cfpb_data` on `Person`
  * Add support for `pending_reason` on `Refund`
  * Change type of `Tax.CalculationLineItem.reference` from `nullable(string)` to `string`
* [#1857](https://github.com/stripe/stripe-php/pull/1857) Include new PHP 8.3 and 8.4 in CI
* [#1856](https://github.com/stripe/stripe-php/pull/1856) Faster parallel runner for PHP formatter

## 17.2.0-beta.4 - 2025-04-17
* [#1855](https://github.com/stripe/stripe-php/pull/1855) Update generated code for beta
  * Add support for new resources `FxQuote` and `PaymentIntentAmountDetailsLineItem`
  * Add support for `all`, `create`, and `retrieve` methods on resource `FxQuote`
  * Remove support for `attach_payment_intent` method on resource `Invoice`
  * Add support for `script` and `type` on `Coupon`
  * Add support for new value `fx_quote.expired` on enum `Event.type`
  * Add support for new value `affirm` on enums `Invoice.payment_settings.payment_method_types`, `QuotePreviewInvoice.payment_settings.payment_method_types`, and `Subscription.payment_settings.payment_method_types`
  * Add support for `fx_quote` on `PaymentIntent` and `Transfer`
  * Add support for `pix` on `PaymentMethodConfiguration`
  * Add support for `us_cfpb_data` on `Person`
  * Add support for `pending_reason` on `Refund`
  * Add support for snapshot event `FX_QUOTE_EXPIRED` with resource `FxQuote`

## 17.2.0-beta.3 - 2025-04-10
* [#1849](https://github.com/stripe/stripe-php/pull/1849) Update generated code for beta

  ### Breaking changes
  * Change type of `V2.MoneyManagement.ReceivedDebit.status_transitions` from `an object` to `nullable(an object)`
  * Remove support for values `bank_accounts.local_uk`, `bank_accounts.wire_uk`, `cards_uk`, and `crypto_wallets_v2` from enum `EventsV2CoreAccountIncludingConfigurationRecipientCapabilityStatusUpdatedEvent.updated_capability`

  ### Additions
  * Add support for new resources `Privacy.RedactionJobRootObjects`, `Privacy.RedactionJobValidationError`, and `Privacy.RedactionJob`
  * Add support for `all`, `cancel`, `create`, `retrieve`, `run`, `update`, and `validate` methods on resource `RedactionJob`
  * Add support for `all` and `retrieve` methods on resource `RedactionJobValidationError`
  * Add support for new value `tax_id_prohibited` on enums `Invoice.last_finalization_error.code`, `PaymentIntent.last_payment_error.code`, `QuotePreviewInvoice.last_finalization_error.code`, `SetupAttempt.setup_error.code`, `SetupIntent.last_setup_error.code`, and `StripeError.code`
  * Add support for new value `fixed_term_loan` on enum `Capital.FinancingOffer.type`
  * Add support for `wallet_options` on `Checkout.Session`
  * Add support for new values `privacy.redaction_job.canceled`, `privacy.redaction_job.created`, `privacy.redaction_job.ready`, `privacy.redaction_job.succeeded`, and `privacy.redaction_job.validation_error` on enum `Event.type`
  * Add support for `klarna` on `PaymentMethodDomain`
  * Change type of `Tax.CalculationLineItem.reference` from `nullable(string)` to `string`
* [#1851](https://github.com/stripe/stripe-php/pull/1851) Handle external_account field
  - Changes `external_account` field in `externalAccounts.create` from a `string` to a union type.
* [#1850](https://github.com/stripe/stripe-php/pull/1850) Xavdid/merge php beta

## 17.2.0-beta.2 - 2025-04-04
* [#1847](https://github.com/stripe/stripe-php/pull/1847) Remove stdClass from object shapes
  * Remove intersection with `stdClass` in resource properties and fixed `instanceof` checks.

## 17.2.0-beta.1 - 2025-04-02

* [#1830](https://github.com/stripe/stripe-php/pull/1830) Update logic for Stripe::addBetaVersion
  * Stripe::addBetaVersion will use the highest version number used for a beta feature instead of throwing an `Exception` on a conflict as it had done previously.
* [#1814](https://github.com/stripe/stripe-php/pull/1814), [#1840](https://github.com/stripe/stripe-php/pull/1840) Update generated code for beta

    This release changes the pinned API version to `2025-03-31.preview`

    ### Breaking Changes
    * Remove support for values `repeating` and `variable` from enum `Coupon.duration`
    * Remove support for `amount_overpaid` on `InvoicePayment`
    * Remove support for values `out_of_band_payment` and `payment_record` from enum `InvoicePayment.payment.type`
    * Remove support for `interchange_fees`, `net_total`, `network_fees`, and `transaction_volume` on `Issuing.Settlement`
    * Remove support for `application_fee_amount`, `discount`, `paid_out_of_band`, `paid`, `payment_intent`, `quote`, `subscription_details`, `subscription_proration_date`, `tax`, `total_tax_amounts`, and `transfer_data` on `QuotePreviewInvoice`
    * Change type of `PaymentAttemptRecord.payment_method_details.type` and `PaymentRecord.payment_method_details.type` from `literal('custom')` to `string`
    * Change type of `PaymentAttemptRecord.payment_record` from `string` to `nullable(string)`
    * Change type of `PaymentRecord.latest_payment_attempt_record` from `string` to `nullable(string)`

    ### Additions
    * Add support for new value `repeating` on enum `Coupon.duration`
    * Add support for new resources `BalanceSettings`
    * Add support for `retrieve` and `update` methods on resource `BalanceSettings`
    * Add support for `all`, `create`, `delete`, `retrieve`, and `update` methods on a new `ExternalAccountService` class to access cards and bank accounts made available in the new path `v1/external_accounts`. Access this via `StripeClient.externalAccounts`
    * Add support for new values `stripe_balance_payment_debit_reversal` and `stripe_balance_payment_debit` on enum `BalanceTransaction.type`
    * Add support for `customer_account` on `Billing.CreditBalanceSummary`, `Billing.CreditGrant`, `BillingPortal.Session`, `CashBalance`, `Checkout.Session`, `CreditNote`, `CustomerBalanceTransaction`, `CustomerCashBalanceTransaction`, `CustomerSession`, `Customer`, `Discount`, `InvoiceItem`, `Invoice`, `PaymentIntent`, `PaymentMethod`, `PromotionCode`, `QuotePreviewInvoice`, `QuotePreviewSubscriptionSchedule`, `Quote`, `SetupAttempt`, `SetupIntent`, `SubscriptionSchedule`, `Subscription`, and `TaxId`
    * Add support for `tax_calculation_reference` on `CreditNoteLineItem`, `InvoiceLineItem`, and `LineItem`
    * Add support for `context` on `Event`
    * Add support for `related_customer_account` on `Identity.VerificationSession`
    * Add support for `network_data` on `Issuing.DisputeSettlementDetail`
    * Add support for `interchange_fees_amount`, `net_total_amount`, `network_fees_amount`, `other_fees_amount`, `other_fees_count`, and `transaction_amount` on `Issuing.Settlement`
    * Add support for `reported_by` on `PaymentAttemptRecord`
    * Add support for `stripe_balance` on `PaymentMethod`
    * Add support for `payout_method` on `Payout`
    * Add support for `confirmation_secret`, `parent`, and `total_taxes` on `QuotePreviewInvoice`
    * Add support for new values `forwarding_api_retryable_upstream_error`, `setup_intent_mobile_wallet_unsupported`, `v2_account_disconnection_unsupported`, and `v2_account_missing_configuration` on enum `QuotePreviewInvoice.last_finalization_error.code`
    * Add support for new values `klarna`, `nz_bank_account`, and `stripe_balance` on enum `QuotePreviewInvoice.payment_settings.payment_method_types`

    #### New APIs for Money CardManagement
    * Add support for new resources `V2.FinancialAddressCreditSimulation`, `V2.FinancialAddressGeneratedMicrodeposits`, `V2.MoneyManagement.Adjustment`, `V2.MoneyManagement.FinancialAccount`, `V2.MoneyManagement.FinancialAddress`, `V2.MoneyManagement.InboundTransfer`, `V2.MoneyManagement.OutboundPaymentQuote`, `V2.MoneyManagement.OutboundPayment`, `V2.MoneyManagement.OutboundSetupIntent`, `V2.MoneyManagement.OutboundTransfer`, `V2.MoneyManagement.PayoutMethod`, `V2.MoneyManagement.PayoutMethodsBankAccountSpec`, `V2.MoneyManagement.ReceivedCredit`, `V2.MoneyManagement.ReceivedDebit`, `V2.MoneyManagement.TransactionEntry`, and `V2.MoneyManagement.Transaction`
    * Add support for `create` method on resource `V2.MoneyManagement.OutboundPaymentQuote`
    * Add support for `all` and `retrieve` methods on resources `V2.MoneyManagement.Adjustment`, `V2.MoneyManagement.FinancialAccount`, `V2.MoneyManagement.ReceivedCredit`, `V2.MoneyManagement.ReceivedDebit`, `V2.MoneyManagement.TransactionEntry`, and `V2.MoneyManagement.Transaction`
    * Add support for `all`, `create`, and `retrieve` methods on resources `V2.MoneyManagement.FinancialAddress` and `V2.MoneyManagement.InboundTransfer`
    * Add support for `all`, `cancel`, `create`, and `retrieve` methods on resources `V2.MoneyManagement.OutboundPayment` and `V2.MoneyManagement.OutboundTransfer`
    * Add support for `all`, `archive`, `retrieve`, and `unarchive` methods on resource `V2.MoneyManagement.PayoutMethod`
    * Add support for `all`, `cancel`, `create`, `retrieve`, and `update` methods on resource `V2.MoneyManagement.OutboundSetupIntent`
    * Add support for `retrieve` method on resource `V2.MoneyManagement.PayoutMethodsBankAccountSpec`
    * Add support for new values `account_number`, `fedwire_routing_number`, and `routing_number` on enum `invalid_payment_method.invalid_param`
    * Add support for new thin event `V2MoneyManagementFinancialAccountCreatedEvent` with related object `V2.MoneyManagement.FinancialAccount`
    * Add support for new thin events `V2MoneyManagementFinancialAddressActivatedEvent` and `V2MoneyManagementFinancialAddressFailedEvent` with related object `V2.MoneyManagement.FinancialAddress`
    * Add support for new thin events `V2MoneyManagementInboundTransferAvailableEvent`, `V2MoneyManagementInboundTransferBankDebitFailedEvent`, `V2MoneyManagementInboundTransferBankDebitProcessingEvent`, `V2MoneyManagementInboundTransferBankDebitQueuedEvent`, `V2MoneyManagementInboundTransferBankDebitReturnedEvent`, and `V2MoneyManagementInboundTransferBankDebitSucceededEvent` with related object `V2.MoneyManagement.InboundTransfer`
    * Add support for new thin events `V2MoneyManagementOutboundPaymentCanceledEvent`, `V2MoneyManagementOutboundPaymentCreatedEvent`, `V2MoneyManagementOutboundPaymentFailedEvent`, `V2MoneyManagementOutboundPaymentPostedEvent`, and `V2MoneyManagementOutboundPaymentReturnedEvent` with related object `V2.MoneyManagement.OutboundPayment`
    * Add support for new thin events `V2MoneyManagementOutboundTransferCanceledEvent`, `V2MoneyManagementOutboundTransferCreatedEvent`, `V2MoneyManagementOutboundTransferFailedEvent`, `V2MoneyManagementOutboundTransferPostedEvent`, and `V2MoneyManagementOutboundTransferReturnedEvent` with related object `V2.MoneyManagement.OutboundTransfer`
    * Add support for new thin events `V2MoneyManagementReceivedCreditAvailableEvent`, `V2MoneyManagementReceivedCreditFailedEvent`, `V2MoneyManagementReceivedCreditReturnedEvent`, and `V2MoneyManagementReceivedCreditSucceededEvent` with related object `V2.MoneyManagement.ReceivedCredit`
    * Add support for new thin events `V2MoneyManagementReceivedDebitCanceledEvent`, `V2MoneyManagementReceivedDebitFailedEvent`, `V2MoneyManagementReceivedDebitPendingEvent`, `V2MoneyManagementReceivedDebitSucceededEvent`, and `V2MoneyManagementReceivedDebitUpdatedEvent` with related object `V2.MoneyManagement.ReceivedDebit`
    * Add support for new error types `AlreadyCanceledException`, `BlockedByStripeException`, `ControlledByDashboardException`, `FeatureNotEnabledException`, `FinancialAccountNotOpenException`, `InsufficientFundsException`, `InvalidPayoutMethodException`, `NotCancelableException`, and `RecipientNotNotifiableException`


    #### New APIs for Accounts v2 in private preview
    See [SaaS platform payments with subscription billing using Accounts v2](https://docs.stripe.com/connect/accounts-v2/saas-platform-payments-billing)

    * Add support for new resources `V2.Core.AccountLink`, `V2.Core.Account`, `V2.Core.Person`, `V2.Core.Vault.GbBankAccount`, `V2.Core.Vault.UsBankAccount`
    * Add support for `all`, `close`, `create`, `retrieve`, and `update` methods on resource `V2.Core.Account`
    * Add support for `create` method on resource `V2.Core.AccountLink`
    * Add support for `acknowledge_confirmation_of_payee`, `archive`, `create`, `initiate_confirmation_of_payee`, and `retrieve` methods on resource `V2.Core.Vault.GbBankAccount`
    * Add support for `archive`, `create`, `retrieve`, and `update` methods on resource `V2.Core.Vault.UsBankAccount`
    * Add support for new thin events `V2CoreAccountIncludingConfigurationCustomerCapabilityStatusUpdatedEvent`, `V2CoreAccountIncludingConfigurationCustomerUpdatedEvent`, `V2CoreAccountIncludingConfigurationMerchantCapabilityStatusUpdatedEvent`, `V2CoreAccountIncludingConfigurationMerchantUpdatedEvent`, `V2CoreAccountIncludingConfigurationRecipientCapabilityStatusUpdatedEvent`, `V2CoreAccountIncludingConfigurationRecipientUpdatedEvent`, `V2CoreAccountIncludingIdentityUpdatedEvent`, and `V2CoreAccountIncludingRequirementsUpdatedEvent`
    * Add support for new thin event `V2CoreAccountLinkCompletedEvent` with related object `V2.Core.AccountLink`
    * Add support for new thin events `V2CoreAccountPersonCreatedEvent`, `V2CoreAccountPersonDeletedEvent`, and `V2CoreAccountPersonUpdatedEvent` with related object `V2.Core.Person`

    ### Changes
    * Change type of `InvoicePayment.is_default` from `nullable(boolean)` to `boolean`
    * Change type of `PaymentAttemptRecord.payment_method_details.custom` and `PaymentRecord.payment_method_details.custom` from `nullable(PaymentsPrimitivesPaymentRecordsResourcePaymentMethodCustomDetails)` to `PaymentsPrimitivesPaymentRecordsResourcePaymentMethodCustomDetails`

## 17.1.1 - 2025-04-04
* [#1847](https://github.com/stripe/stripe-php/pull/1847) Remove stdClass from object shapes
  * Remove intersection with `stdClass` in resource properties and fixed `instanceof` checks.

## 17.1.0 - 2025-04-02
* [#1843](https://github.com/stripe/stripe-php/pull/1843) Add null type in resource fields to non required objects
    * Fixes nullable resource properties that were incorrectly set as required in PHPDocs

## 17.0.0 - 2025-04-01
* [#1837](https://github.com/stripe/stripe-php/pull/1837) Better type hints in your editor!!
    * Added type hints for method parameters
        * <img width="417" alt="PHPStorm IDE with array type hints" src="https://github.com/user-attachments/assets/e914dcda-354f-4df2-b82e-217ad931e71d">
    * Improved type hints for resource properties that are not primitive types. Take for example, the invoice settings in Customer resource. Previously, you could not reference inner fields like `custom_fields` on `customer->invoice_settings` without PHPStan complaining. This is now fixed.

* [#1818](https://github.com/stripe/stripe-php/pull/1818) Support for APIs in the new API version 2025-03-31.basil

  This release changes the pinned API version to `2025-03-31.basil`.

  ### ⚠️ Breaking changes due to changes in the Stripe API

  Please review details for the breaking changes and alternatives in the [Stripe API changelog](https://docs.stripe.com/changelog/basil#2025-03-31.basil) before upgrading.

    * Remove support for resources `UsageRecordSummary` and `UsageRecord`
    * Remove support for `create` method on resource `UsageRecord`
    * Remove support for `all` method on resource `UsageRecordSummary`
    * Remove support for `upcomingLines` and `upcoming` methods on resource `Invoice`
    * Remove support for `invoice` on `Charge` and `PaymentIntent`
    * Remove support for `shipping_details` on `Checkout.Session`
    * Remove support for `refund` on `CreditNote`
    * Remove support for `tax_amounts` on `CreditNoteLineItem`, `CreditNote`, and `InvoiceLineItem`
    * Remove support for `amount_excluding_tax` and `unit_amount_excluding_tax` on `CreditNoteLineItem` and `InvoiceLineItem`
    * Remove support for `application_fee_amount`, `charge`, `paid_out_of_band`, `paid`, `payment_intent`, `quote`, `subscription`, `subscription_details`, `subscription_proration_date`, `tax`, `total_tax_amounts`, and `transfer_data` on `Invoice`
    * Remove support for `discount` on `Invoice` and `Subscription`
    * Remove support for `invoice_item`, `proration_details`, `proration`, `tax_rates`, and `type` on `InvoiceLineItem`
    * Remove support for `plan`, `price`, and `subscription_item` on `InvoiceItem` and `InvoiceLineItem`
    * Remove support for `subscription`, `unit_amount_decimal`, and `unit_amount` on `InvoiceItem`
    * Remove support for `aggregate_usage` on `Plan`
    * Remove support for `billing_thresholds` on `SubscriptionItem` and `Subscription`
    * Remove support for `current_period_end` and `current_period_start` on `Subscription`

  ### ⚠️ Other Breaking changes in the SDK
    * [#1826](https://github.com/stripe/stripe-php/pull/1826) configure max_nextwork_retries at the client level
        * Allow setting `maxNetworkRetries` at the `StripeClient` level via a new argument to the `RequestOptions` constructor
            * ⚠️ (potentially breaking) a client's configuration for `maxNetworkRetries` is set during client initialization. Subsequent calls to `Stripe::setMaxNetworkRetries()` after client creation **won't** affect that client.
        * Allow setting `maxNetworkRetries` per-request via the `max_network_retries` config argument. This works for both the service and resource based patterns. In both cases, an explicitly passed value takes precedence over the global (or client) value.
    * [#1835](https://github.com/stripe/stripe-php/pull/1835) Removed the protected method _searchResource as it is no longer used
        * ⚠️ Removed `_searchResource` method and `Search` trait. Use the public `search` method on `Charge`, `Customer`, `Invoice`, `PaymentIntent`, `Price`, `Product`, and `Subscription` resource.
    * [#1832](https://github.com/stripe/stripe-php/pull/1832) Added requestCollection and requestSearchResult to StripeClientInterface
        * ⚠️ Added `requestSearchResult`, `requestCollection` to `StripeClientInterface`. Developers building custom StripeClient will now have to implement these new methods.
            * Refer to our implementation in [BaseStripeClient](https://github.com/stripe/stripe-php/blob/f65c497d0bc175aaa04538602fd49645f44f9384/lib/BaseStripeClient.php#L259-L315) for guidance.


### Additions

* Add support for new resource `InvoicePayment`
* Add support for `all` and `retrieve` methods on resource `InvoicePayment`
* Add support for new values `forwarding_api_retryable_upstream_error` and `setup_intent_mobile_wallet_unsupported` on enums `Invoice.last_finalization_error.code`, `PaymentIntent.last_payment_error.code`, `SetupAttempt.setup_error.code`, `SetupIntent.last_setup_error.code`, and `StripeError.code`
* Add support for new values `stripe_balance_payment_debit_reversal` and `stripe_balance_payment_debit` on enum `BalanceTransaction.type`
* Add support for new value `last` on enum `Billing.Meter.default_aggregation.formula`
* Add support for `presentment_details` on `Charge`, `Checkout.Session`, `PaymentIntent`, and `Refund`
* Add support for `optional_items` on `Checkout.Session` and `PaymentLink`
* Add support for `permissions` on `Checkout.Session`
* Add support for new value `custom` on enum `Checkout.Session.ui_mode`
* Add support for new values `billie`, `nz_bank_account`, and `satispay` on enums `ConfirmationToken.payment_method_preview.type` and `PaymentMethod.type`
* Add support for `refunds` on `CreditNote`
* Add support for `total_taxes` on `CreditNote` and `Invoice`
* Add support for `taxes` on `CreditNoteLineItem` and `InvoiceLineItem`
* Add support for `checkout_session` on `CustomerBalanceTransaction`
* Add support for new values `checkout_session_subscription_payment_canceled` and `checkout_session_subscription_payment` on enum `CustomerBalanceTransaction.type`
* Add support for new value `invoice.overpaid` on enum `Event.type`
* Add support for `amount_overpaid`, `confirmation_secret`, and `payments` on `Invoice`
* Add support for `parent` on `InvoiceItem`, `InvoiceLineItem`, and `Invoice`
* Add support for new values `klarna` and `nz_bank_account` on enums `Invoice.payment_settings.payment_method_types` and `Subscription.payment_settings.payment_method_types`
* Add support for `pricing` on `InvoiceItem` and `InvoiceLineItem`
* Add support for new value `network_fallback` on enum `Issuing.Authorization.request_history[].reason`
* Add support for new value `expired` on enum `Issuing.Authorization.status`
* Add support for new value `expired` on enum `PaymentIntent.cancellation_reason`
* Add support for new values `billie` and `satispay` on enum `PaymentLink.payment_method_types`
* Add support for `billie`, `nz_bank_account`, and `satispay` on `PaymentMethodConfiguration` and `PaymentMethod`
* Add support for new value `canceled` on enum `Review.closed_reason`
* Add support for `current_period_end` and `current_period_start` on `SubscriptionItem`
* Add support for `wifi` on `Terminal.Configuration`

## 16.7.0-beta.1 - 2025-03-18
* [#1820](https://github.com/stripe/stripe-php/pull/1820) Beta SDK updates between Open API versions 1473 and 1505
  Codegen for openapi 1505.

  * Add support for `succeed_input_collection` and `timeout_input_collection` test helper methods on resource `Terminal.Reader`
* [#1825](https://github.com/stripe/stripe-php/pull/1825) Results of running formatter
* [#1823](https://github.com/stripe/stripe-php/pull/1823) Merge from stripe-php master
* [#1821](https://github.com/stripe/stripe-php/pull/1821) Merge from stripe-php master
* [#1808](https://github.com/stripe/stripe-php/pull/1808) Update generated code for beta

* [#1803](https://github.com/stripe/stripe-php/pull/1803) Update generated code for beta
  * V2 Events now are subclass of `\Stripe\V2\Event`.
* [#1796](https://github.com/stripe/stripe-php/pull/1796) Update generated code for beta
  * Add support for `close` method on resource `Treasury.FinancialAccount`
  * Add support for `advice_code` on `StripeError`
  * Add support for `brand_product` on `Card`
  * Add support for `is_default` and `nickname` on `Treasury.FinancialAccount`
* [#1794](https://github.com/stripe/stripe-php/pull/1794) Improved php type hints

  ### Adds Create/Update/Retrieve/Delete/All/Search parameters

  You will now be able to get type hints of the keys that can passed without switching out of your IDE. Eg.
  ```php
  * @param null|array{customer:string, components: array} $params
  ```

  <img width="417" alt="PHPStorm IDE with array type hints" src="https://github.com/user-attachments/assets/e914dcda-354f-4df2-b82e-217ad931e71d">

  ### Updated StripeObject class properties
  We changed the type of class properties from `StripeObject` to something more specific.

  For example: Invoice settings was defined as a StripeObject in Customer resource.

  https://github.com/stripe/stripe-php/blob/bae10cd799404f0f4862ec03810c5ff8ca634b30/lib/Customer.php#L25

  Now you will be able to reference `custom_fields` and `rendering_options` on `customer->invoice_settings` without PHPStan complaining.
  ```php
  * @property object{custom_fields: null|object{name: string, value: string}&\Stripe\StripeObject&\stdClass[], default_payment_method: null|string|\Stripe\PaymentMethod, footer: null|string, rendering_options: null|object{amount_tax_display: null|string, template: null|string}&\Stripe\StripeObject&\stdClass}&\Stripe\StripeObject&\stdClass $invoice_settings
   */
  ```
* [#1792](https://github.com/stripe/stripe-php/pull/1792) Update generated code for beta
  * Add support for `allow_redisplay` on `Card` and `Source`
  * Remove support for `amount_refunded` on `PaymentRecord`
* [#1790](https://github.com/stripe/stripe-php/pull/1790) Update generated code for beta
  * Add support for new values `payout_minimum_balance_hold` and `payout_minimum_balance_release` on enum `BalanceTransaction.type`
* [#1788](https://github.com/stripe/stripe-php/pull/1788) Update generated code for beta
  * Add support for `network_advice_code` and `network_decline_code` on `StripeError`
  * Add support for new value `invoice.overpaid` on enum `Event.type`
  * Add support for `adjustable_quantity`, `display`, and `metadata` on `LineItem`
  * Change type of `LineItem.description` from `string` to `nullable(string)`
* [#1784](https://github.com/stripe/stripe-php/pull/1784) Update generated code for beta

* [#1783](https://github.com/stripe/stripe-php/pull/1783) Update generated code for beta
  * Add support for new resources `Issuing.FraudLiabilityDebit`, `PaymentAttemptRecord`, and `PaymentRecord`
  * Add support for `all` and `retrieve` methods on resources `FraudLiabilityDebit` and `PaymentAttemptRecord`
  * Add support for `report_payment_attempt_canceled`, `report_payment_attempt_failed`, `report_payment_attempt_guaranteed`, `report_payment_attempt`, `report_payment`, and `retrieve` methods on resource `PaymentRecord`
  * Add support for `adaptive_pricing` on `Checkout.Session`
  * Add support for new values `invoice.payment_attempt_required` and `issuing_fraud_liability_debit.created` on enum `Event.type`
  * Add support for `amount_overpaid` on `Invoice`
  * Add support for new value `li_vat` on enum `TaxId.type`
  * Add support for new value `service_tax` on enum `TaxRate.tax_type`
  * Change type of `Treasury.InboundTransfer.origin_payment_method` from `string` to `nullable(string)`
* [#1780](https://github.com/stripe/stripe-php/pull/1780) Update generated code for beta
  * Add support for `trigger_action` method on resource `PaymentIntent`
  * Remove support for value `payout_statement_descriptor_profanity` from enum `StripeError.code`
  * Add support for `id_bank_transfer` on `PaymentMethodConfiguration` and `PaymentMethod`
  * Add support for `gopay`, `qris`, and `shopeepay` on `PaymentMethodConfiguration`
* [#1774](https://github.com/stripe/stripe-php/pull/1774) Update generated code for beta
  * Remove support for value `expired` from enum `Issuing.Authorization.status`
  * Add support for new values `alma`, `gopay`, `qris`, and `shopeepay` on enum `PaymentLink.payment_method_types[]`
  * Add support for `alma` on `PaymentMethodConfiguration` and `PaymentMethod`
  * Add support for `gopay`, `qris`, and `shopeepay` on `PaymentMethod`
  * Add support for new values `alma`, `gopay`, `qris`, and `shopeepay` on enum `PaymentMethod.type`
  * Add support for `amazon_pay` on `PaymentMethodDomain`
  * Add support for `au_serr`, `ca_mrdp`, `eu_dac7`, `gb_mrdp`, and `nz_mrdp` on `Tax.Form`
  * Add support for new values `au_serr`, `ca_mrdp`, `eu_dac7`, `gb_mrdp`, and `nz_mrdp` on enum `Tax.Form.type`
* [#1749](https://github.com/stripe/stripe-php/pull/1749) Update generated code for beta
  * Add support for `submit_card` test helper method on resource `Issuing.Card`
  * Add support for `groups` on `Account`
  * Add support for new value `payout_statement_descriptor_profanity` on enum `StripeError.code`
  * Add support for new value `refund.failed` on enum `Event.type`
  * Add support for `metadata` on `Forwarding.Request`
  * Add support for new value `expired` on enum `Issuing.Authorization.status`
  * Add support for `kakao_pay`, `kr_card`, `naver_pay`, `payco`, and `samsung_pay` on `PaymentMethod`
  * Add support for new values `kakao_pay`, `kr_card`, `naver_pay`, `payco`, and `samsung_pay` on enum `PaymentMethod.type`
  * Add support for new values `by_tin`, `ma_vat`, `md_vat`, `tz_vat`, `uz_tin`, and `uz_vat` on enum `TaxId.type`
  * Add support for `flat_amount` and `rate_type` on `TaxRate`
  * Add support for new value `retail_delivery_fee` on enum `TaxRate.tax_type`
* [#1770](https://github.com/stripe/stripe-php/pull/1770) Merge into beta using the merge script
* [#1766](https://github.com/stripe/stripe-php/pull/1766) Merge updates from stripe-php master to beta

  * The `Preview` class has been removed. Please use [rawRequest](https://github.com/stripe/stripe-php?tab=readme-ov-file#custom-requests) instead which accepts
       * the http method as parameter instead of the dedicated methods in the `Preview` class
       * an `apiMode` of `v1` instead of `standard` and `v2` instead of `preview`.
* [#1748](https://github.com/stripe/stripe-php/pull/1748) Update generated code for beta
  * Remove support for resource `QuotePhase`
  * Remove support for `list_line_items` and `retrieve` methods on resource `QuotePhase`
  * Add support for new value `rechnung` on enum `PaymentLink.payment_method_types[]`
* [#1743](https://github.com/stripe/stripe-php/pull/1743) Update generated code for beta
  * Add support for new resources `Issuing.DisputeSettlementDetail` and `Issuing.Settlement`
  * Add support for `all` and `retrieve` methods on resource `DisputeSettlementDetail`
  * Remove support for `all` method on resource `QuotePhase`
  * Add support for new values `issuing_dispute_settlement_detail.created`, `issuing_dispute_settlement_detail.updated`, `issuing_settlement.created`, and `issuing_settlement.updated` on enum `Event.type`
  * Add support for `settlement` on `Issuing.Transaction`
* [#1738](https://github.com/stripe/stripe-php/pull/1738) Update generated code for beta
  * Add support for new resources `Billing.MeterErrorReport` and `Terminal.ReaderCollectedData`
  * Add support for `retrieve` method on resource `ReaderCollectedData`
  * Add support for new value `terminal_reader_collected_data_invalid` on enum `StripeError.code`
  * Add support for new value `billing.meter_error_report.triggered` on enum `Event.type`
  * Add support for `regulatory_reporting_file` on `Issuing.CreditUnderwritingRecord`
  * Add support for new value `mb_way` on enum `PaymentLink.payment_method_types[]`
  * Add support for `mb_way` on `PaymentMethod`
  * Add support for new value `mb_way` on enum `PaymentMethod.type`
* [#1735](https://github.com/stripe/stripe-php/pull/1735) Update generated code for beta
  * Add support for `collected_information` and `permissions` on `Checkout.Session`
* [#1730](https://github.com/stripe/stripe-php/pull/1730) Update generated code for beta
  * Add support for new value `custom` on enum `Checkout.Session.ui_mode`
  * Add support for new value `payto` on enum `PaymentLink.payment_method_types[]`
* [#1728](https://github.com/stripe/stripe-php/pull/1728) Update generated code for beta
  * Add support for `attach_payment` method on resource `Invoice`
  * Add support for `last_price_migration_error` on `SubscriptionSchedule` and `Subscription`
* [#1723](https://github.com/stripe/stripe-php/pull/1723) Update generated code for beta
  * Add support for new resources `Billing.AlertTriggered`, `Billing.Alert`, and `Tax.Association`
  * Add support for `activate`, `all`, `archive`, `create`, `deactivate`, and `retrieve` methods on resource `Alert`
  * Add support for `find` method on resource `Association`
  * Add support for new values `issuing.account_closed_for_not_providing_business_model_clarification`, `issuing.account_closed_for_not_providing_url_clarification`, and `issuing.account_closed_for_not_providing_use_case_clarification` on enum `AccountNotice.reason`
  * Add support for `async_workflows` on `PaymentIntent`
  * Add support for `payto` on `PaymentMethodConfiguration`
  * Add support for `display_name` on `Treasury.FinancialAccount`
* [#1720](https://github.com/stripe/stripe-php/pull/1720) Update generated code for beta

* [#1719](https://github.com/stripe/stripe-php/pull/1719) Update generated code for beta
  * Add support for new resource `FinancialConnections.Institution`
  * Add support for `all` and `retrieve` methods on resource `Institution`
  * Add support for new value `balance` on enum `FinancialConnections.Account.subscriptions[]`
* [#1712](https://github.com/stripe/stripe-php/pull/1712) Update generated code for beta

## 16.6.0-beta.1 - 2025-02-07
* [#1808](https://github.com/stripe/stripe-php/pull/1808) Update generated code for beta

## 16.6.0 - 2025-02-24
* [#1809](https://github.com/stripe/stripe-php/pull/1809) Update generated code
  * Add support for `priority` on `Billing.CreditGrant`
  * Add support for `collected_information` on `Checkout.Session`
* [#1816](https://github.com/stripe/stripe-php/pull/1816) add codeowners file

## 16.5.1 - 2025-02-07
* [#1811](https://github.com/stripe/stripe-php/pull/1811) Include a useful error message when a null byte is found in the URL path
* [#1810](https://github.com/stripe/stripe-php/pull/1810) Make `httpClient()` a public, static method

## 16.5.0 - 2025-01-27
* [#1804](https://github.com/stripe/stripe-php/pull/1804) Update generated code
  * Add support for `close` method on resource `Treasury.FinancialAccount`
  * Add support for `advice_code` on `StripeError`
  * Add support for `discounts` on `Checkout.Session`
  * Add support for new value `pay_by_bank` on enum `PaymentLink.payment_method_types[]`
  * Add support for `pay_by_bank` on `PaymentMethodConfiguration` and `PaymentMethod`
  * Add support for new value `pay_by_bank` on enum `PaymentMethod.type`
  * Add support for `is_default` and `nickname` on `Treasury.FinancialAccount`
* [#1805](https://github.com/stripe/stripe-php/pull/1805) Restore testCoreEventsGet generated test
* [#1807](https://github.com/stripe/stripe-php/pull/1807) minor justfile fixes
* [#1806](https://github.com/stripe/stripe-php/pull/1806) Added CONTRIBUTING.md file
* [#1802](https://github.com/stripe/stripe-php/pull/1802) ensure dependencies are installed for format and test recipes
* [#1801](https://github.com/stripe/stripe-php/pull/1801) Add justfile, remove coveralls, and fix AUTOLOAD in CI
* [#1797](https://github.com/stripe/stripe-php/pull/1797) Added pull request template

## 16.5.0-beta.3 - 2025-01-23
* [#1803](https://github.com/stripe/stripe-php/pull/1803) Update generated code for beta
  * V2 Events now are subclass of `\Stripe\V2\Event`.

## 16.5.0-beta.2 - 2025-01-09
* [#1796](https://github.com/stripe/stripe-php/pull/1796) Update generated code for beta
  * Add support for `close` method on resource `Treasury.FinancialAccount`
  * Add support for `advice_code` on `StripeError`
  * Add support for `brand_product` on `Card`
  * Add support for `is_default` and `nickname` on `Treasury.FinancialAccount`

## 16.5.0-beta.1 - 2024-12-20
* [#1794](https://github.com/stripe/stripe-php/pull/1794) Improved php type hints

  ### Adds Create/Update/Retrieve/Delete/All/Search parameters

  You will now be able to get type hints of the keys that can passed without switching out of your IDE. Eg.
  ```php
  * @param null|array{customer:string, components: array} $params
  ```

  <img width="417" alt="PHPStorm IDE with array type hints" src="https://github.com/user-attachments/assets/e914dcda-354f-4df2-b82e-217ad931e71d">

  ### Updated StripeObject class properties
  We changed the type of class properties from `StripeObject` to something more specific.

  For example: Invoice settings was defined as a StripeObject in Customer resource.

  https://github.com/stripe/stripe-php/blob/bae10cd799404f0f4862ec03810c5ff8ca634b30/lib/Customer.php#L25

  Now you will be able to reference `custom_fields` and `rendering_options` on `customer->invoice_settings` without PHPStan complaining.
  ```php
  * @property object{custom_fields: null|object{name: string, value: string}&\Stripe\StripeObject&\stdClass[], default_payment_method: null|string|\Stripe\PaymentMethod, footer: null|string, rendering_options: null|object{amount_tax_display: null|string, template: null|string}&\Stripe\StripeObject&\stdClass}&\Stripe\StripeObject&\stdClass $invoice_settings
   */
  ```

## 16.4.0 - 2024-12-18
* [#1793](https://github.com/stripe/stripe-php/pull/1793) This release changes the pinned API version to `2024-12-18.acacia`.
  * Add support for `network_advice_code` and `network_decline_code` on `StripeError`
  * Add support for new values `payout_minimum_balance_hold` and `payout_minimum_balance_release` on enum `BalanceTransaction.type`
  * Add support for `allow_redisplay` on `Card` and `Source`
  * Add support for `regulated_status` on `Card`
  * Add support for new value `request_signature` on enum `Forwarding.Request.replacements[]`
  * Change type of `LineItem.description` from `string` to `nullable(string)`
  * Add support for new values `al_tin`, `am_tin`, `ao_tin`, `ba_tin`, `bb_tin`, `bs_tin`, `cd_nif`, `gn_nif`, `kh_tin`, `me_pib`, `mk_vat`, `mr_nif`, `np_pan`, `sn_ninea`, `sr_fin`, `tj_tin`, `ug_tin`, `zm_tin`, and `zw_tin` on enum `TaxId.type`

## 16.4.0-beta.3 - 2024-12-12
* [#1792](https://github.com/stripe/stripe-php/pull/1792) Update generated code for beta
  * Add support for `allow_redisplay` on `Card` and `Source`
  * Remove support for `amount_refunded` on `PaymentRecord`

## 16.4.0-beta.2 - 2024-12-05
* [#1790](https://github.com/stripe/stripe-php/pull/1790) Update generated code for beta
  * Add support for new values `payout_minimum_balance_hold` and `payout_minimum_balance_release` on enum `BalanceTransaction.type`

## 16.4.0-beta.1 - 2024-11-21
* [#1788](https://github.com/stripe/stripe-php/pull/1788) Update generated code for beta
  * Add support for `network_advice_code` and `network_decline_code` on `StripeError`
  * Add support for new value `invoice.overpaid` on enum `Event.type`
  * Add support for `adjustable_quantity`, `display`, and `metadata` on `LineItem`
  * Change type of `LineItem.description` from `string` to `nullable(string)`

## 16.3.0 - 2024-11-20
* [#1786](https://github.com/stripe/stripe-php/pull/1786) This release changes the pinned API version to `2024-11-20.acacia`.
  * Add support for `respond` test helper method on resource `Issuing.Authorization`
  * Add support for `adaptive_pricing` on `Checkout.Session`
  * Add support for new value `subscribe` on enums `Checkout.Session.submit_type` and `PaymentLink.submit_type`
  * Add support for new value `financial_account_statement` on enum `File.purpose`
  * Add support for `fraud_challenges` and `verified_by_fraud_challenge` on `Issuing.Authorization`
  * Add support for `trace_id` on `Payout`
  * Add support for new value `li_vat` on enum `TaxId.type`
  * Add support for new value `service_tax` on enum `TaxRate.tax_type`
  * Change type of `Treasury.InboundTransfer.origin_payment_method` from `string` to `nullable(string)`

## 16.3.0-beta.3 - 2024-11-14
* [#1784](https://github.com/stripe/stripe-php/pull/1784) Update generated code for beta

## 16.3.0-beta.2 - 2024-11-07
* [#1783](https://github.com/stripe/stripe-php/pull/1783) Update generated code for beta
  * Add support for new resources `Issuing.FraudLiabilityDebit`, `PaymentAttemptRecord`, and `PaymentRecord`
  * Add support for `all` and `retrieve` methods on resources `FraudLiabilityDebit` and `PaymentAttemptRecord`
  * Add support for `report_payment_attempt_canceled`, `report_payment_attempt_failed`, `report_payment_attempt_guaranteed`, `report_payment_attempt`, `report_payment`, and `retrieve` methods on resource `PaymentRecord`
  * Add support for `adaptive_pricing` on `Checkout.Session`
  * Add support for new values `invoice.payment_attempt_required` and `issuing_fraud_liability_debit.created` on enum `Event.type`
  * Add support for `amount_overpaid` on `Invoice`
  * Add support for new value `li_vat` on enum `TaxId.type`
  * Add support for new value `service_tax` on enum `TaxRate.tax_type`
  * Change type of `Treasury.InboundTransfer.origin_payment_method` from `string` to `nullable(string)`

## 16.3.0-beta.1 - 2024-10-29
* [#1780](https://github.com/stripe/stripe-php/pull/1780) Update generated code for beta
  * Add support for `trigger_action` method on resource `PaymentIntent`
  * Remove support for value `payout_statement_descriptor_profanity` from enum `StripeError.code`
  * Add support for `id_bank_transfer` on `PaymentMethodConfiguration` and `PaymentMethod`
  * Add support for `gopay`, `qris`, and `shopeepay` on `PaymentMethodConfiguration`

## 16.2.0 - 2024-10-29
* [#1772](https://github.com/stripe/stripe-php/pull/1772) This release changes the pinned API version to `2024-10-28.acacia`.
  * Add support for new resource `V2.EventDestinations`
  * Add support for `create`, `retrieve`, `update`, `list`, `delete`, `disable`, `enable` and `ping` methods on resource `V2.EventDestinations`
  * Add support for `submit_card` test helper method on resource `Issuing.Card`
  * Add support for `groups` on `Account`
  * Add support for `enhanced_eligibility_types` on `Dispute`
  * Add support for new values `issuing_transaction.purchase_details_receipt_updated` and `refund.failed` on enum `Event.type`
  * Add support for `metadata` on `Forwarding.Request`
  * Add support for new value `alma` on enum `PaymentLink.payment_method_types[]`
  * Add support for `alma` on `PaymentMethodConfiguration` and `PaymentMethod`
  * Add support for `kakao_pay`, `kr_card`, `naver_pay`, `payco`, and `samsung_pay` on `PaymentMethod`
  * Add support for new values `alma`, `kakao_pay`, `kr_card`, `naver_pay`, `payco`, and `samsung_pay` on enum `PaymentMethod.type`
  * Add support for `amazon_pay` on `PaymentMethodDomain`
  * Add support for new values `by_tin`, `ma_vat`, `md_vat`, `tz_vat`, `uz_tin`, and `uz_vat` on enum `TaxId.type`
  * Add support for `flat_amount` and `rate_type` on `TaxRate`
  * Add support for new value `retail_delivery_fee` on enum `TaxRate.tax_type`

## 16.2.0-beta.3 - 2024-10-18
* [#1774](https://github.com/stripe/stripe-php/pull/1774) Update generated code for beta
  * Remove support for value `expired` from enum `Issuing.Authorization.status`
  * Add support for new values `alma`, `gopay`, `qris`, and `shopeepay` on enum `PaymentLink.payment_method_types[]`
  * Add support for `alma` on `PaymentMethodConfiguration` and `PaymentMethod`
  * Add support for `gopay`, `qris`, and `shopeepay` on `PaymentMethod`
  * Add support for new values `alma`, `gopay`, `qris`, and `shopeepay` on enum `PaymentMethod.type`
  * Add support for `amazon_pay` on `PaymentMethodDomain`
  * Add support for `au_serr`, `ca_mrdp`, `eu_dac7`, `gb_mrdp`, and `nz_mrdp` on `Tax.Form`
  * Add support for new values `au_serr`, `ca_mrdp`, `eu_dac7`, `gb_mrdp`, and `nz_mrdp` on enum `Tax.Form.type`

## 16.2.0-beta.2 - 2024-10-08
* [#1749](https://github.com/stripe/stripe-php/pull/1749) Update generated code for beta
  * Add support for `submit_card` test helper method on resource `Issuing.Card`
  * Add support for `groups` on `Account`
  * Add support for new value `payout_statement_descriptor_profanity` on enum `StripeError.code`
  * Add support for new value `refund.failed` on enum `Event.type`
  * Add support for `metadata` on `Forwarding.Request`
  * Add support for new value `expired` on enum `Issuing.Authorization.status`
  * Add support for `kakao_pay`, `kr_card`, `naver_pay`, `payco`, and `samsung_pay` on `PaymentMethod`
  * Add support for new values `kakao_pay`, `kr_card`, `naver_pay`, `payco`, and `samsung_pay` on enum `PaymentMethod.type`
  * Add support for new values `by_tin`, `ma_vat`, `md_vat`, `tz_vat`, `uz_tin`, and `uz_vat` on enum `TaxId.type`
  * Add support for `flat_amount` and `rate_type` on `TaxRate`
  * Add support for new value `retail_delivery_fee` on enum `TaxRate.tax_type`

## 16.2.0-beta.1 - 2024-10-03
* [#1766](https://github.com/stripe/stripe-php/pull/1766) The `Preview` class has been removed. Please use [rawRequest](https://github.com/stripe/stripe-php?tab=readme-ov-file#custom-requests) instead which accepts
       * the http method as parameter instead of the dedicated methods in the `Preview` class
       * an `apiMode` of `v1` instead of `standard` and `v2` instead of `preview`.

## 16.1.1 - 2024-10-18
* [#1775](https://github.com/stripe/stripe-php/pull/1775) Deserialize into correct v2 EventData types
  * Fixes a bug where v2 EventData was not being deserialized into the appropriate type for `V1BillingMeterErrorReportTriggeredEvent` and `V1BillingMeterNoMeterFoundEvent`
* [#1776](https://github.com/stripe/stripe-php/pull/1776) update object tags for meter-related classes

  - fixes a bug where the `object` property of the `MeterEvent`, `MeterEventAdjustment`, and `MeterEventSession` didn't match the server.
* [#1773](https://github.com/stripe/stripe-php/pull/1773) Clean up examples
* [#1771](https://github.com/stripe/stripe-php/pull/1771) Renamed example file names

## 16.1.0 - 2024-10-03
* [#1765](https://github.com/stripe/stripe-php/pull/1765) Update generated code
  * Remove the support for resource `Margin` that was accidentally made public in the last release

## 16.0.0 - 2024-10-01
* [#1756](https://github.com/stripe/stripe-php/pull/1756) Support for APIs in the new API version 2024-09-30.acacia

  This release changes the pinned API version to `2024-09-30.acacia`. Please read the [API Changelog](https://docs.stripe.com/changelog/acacia#2024-09-30.acacia) and carefully review the API changes before upgrading.

  ### ⚠️ Breaking changes

  * Rename `usage_threshold_config` to `usage_threshold` on `Billing.Alert`
  * Remove support for `filter` on `Billing.Alert`. Use the filters on the `usage_threshold` instead


  ### Additions

  * Add support for new value `international_transaction` on enum `Treasury.ReceivedCredit.failure_code`
  * Add support for new Usage Billing APIs `Billing.MeterEvent`, `Billing.MeterEventAdjustments`, `Billing.MeterEventSession`, `Billing.MeterEventStream` and the new Events API `Core.Events` under the [v2 namespace ](https://docs.corp.stripe.com/api-v2-overview)
  * Add new method `parseThinEvent()` on the `StripeClient` class to parse [thin events](https://docs.corp.stripe.com/event-destinations#events-overview).
  * Add a new method [rawRequest()](https://github.com/stripe/stripe-node/tree/master?tab=readme-ov-file#custom-requests) on the `StripeClient` class that takes a HTTP method type, url and relevant parameters to make requests to the Stripe API that are not yet supported in the SDK.

## 15.11.0-beta.1 - 2024-09-18
* [#1748](https://github.com/stripe/stripe-php/pull/1748) Update generated code for beta
  * Remove support for resource `QuotePhase`
  * Remove support for `list_line_items` and `retrieve` methods on resource `QuotePhase`
  * Add support for new value `rechnung` on enum `PaymentLink.payment_method_types[]`

## 15.10.0 - 2024-09-18
* [#1747](https://github.com/stripe/stripe-php/pull/1747) Update generated code
  * Add support for new value `international_transaction` on enum `Treasury.ReceivedDebit.failure_code`
* [#1745](https://github.com/stripe/stripe-php/pull/1745) Update generated code
  * Add support for new value `terminal_reader_invalid_location_for_activation` on enum `StripeError.code`
  * Add support for `automatically_finalizes_at` on `Invoice`

## 15.10.0-beta.1 - 2024-09-13
* [#1743](https://github.com/stripe/stripe-php/pull/1743) Update generated code for beta
  * Add support for new resources `Issuing.DisputeSettlementDetail` and `Issuing.Settlement`
  * Add support for `all` and `retrieve` methods on resource `DisputeSettlementDetail`
  * Remove support for `all` method on resource `QuotePhase`
  * Add support for new values `issuing_dispute_settlement_detail.created`, `issuing_dispute_settlement_detail.updated`, `issuing_settlement.created`, and `issuing_settlement.updated` on enum `Event.type`
  * Add support for `settlement` on `Issuing.Transaction`

## 15.9.0 - 2024-09-12
* [#1737](https://github.com/stripe/stripe-php/pull/1737) Update generated code
  * Add support for new resource `InvoiceRenderingTemplate`
  * Add support for `all`, `archive`, `retrieve`, and `unarchive` methods on resource `InvoiceRenderingTemplate`

## 15.9.0-beta.1 - 2024-09-05
* [#1738](https://github.com/stripe/stripe-php/pull/1738) Update generated code for beta
  * Add support for new resources `Billing.MeterErrorReport` and `Terminal.ReaderCollectedData`
  * Add support for `retrieve` method on resource `ReaderCollectedData`
  * Add support for new value `terminal_reader_collected_data_invalid` on enum `StripeError.code`
  * Add support for new value `billing.meter_error_report.triggered` on enum `Event.type`
  * Add support for `regulatory_reporting_file` on `Issuing.CreditUnderwritingRecord`
  * Add support for new value `mb_way` on enum `PaymentLink.payment_method_types[]`
  * Add support for `mb_way` on `PaymentMethod`
  * Add support for new value `mb_way` on enum `PaymentMethod.type`

## 15.8.0 - 2024-08-29
* [#1742](https://github.com/stripe/stripe-php/pull/1742) Generate SDK for OpenAPI spec version 1230
  * Add support for new value `issuing_regulatory_reporting` on enum `File.purpose`
  * Add support for new value `hr_oib` on enum `TaxId.type`
  * Add support for `status_details` on `TestHelpers.TestClock`

## 15.8.0-beta.1 - 2024-08-15
* [#1735](https://github.com/stripe/stripe-php/pull/1735) Update generated code for beta
  * Add support for `collected_information` and `permissions` on `Checkout.Session`

## 15.7.0 - 2024-08-15
* [#1736](https://github.com/stripe/stripe-php/pull/1736) Update generated code

## 15.7.0-beta.1 - 2024-08-12
* [#1730](https://github.com/stripe/stripe-php/pull/1730) Update generated code for beta
  * Add support for new value `custom` on enum `Checkout.Session.ui_mode`
  * Add support for new value `payto` on enum `PaymentLink.payment_method_types[]`

## 15.6.0 - 2024-08-08
* [#1729](https://github.com/stripe/stripe-php/pull/1729) Update generated code
  * Add support for `activate`, `all`, `archive`, `create`, `deactivate`, and `retrieve` methods on resource `Billing.Alert`
  * Add support for `retrieve` method on resource `Tax.Calculation`
  * Add support for new value `invalid_mandate_reference_prefix_format` on enum `StripeError.code`
  * Add support for `related_customer` on `Identity.VerificationSession`
  * Add support for new value `financial_addresses.aba.forwarding` on enums `Treasury.FinancialAccount.active_features[]`, `Treasury.FinancialAccount.pending_features[]`, and `Treasury.FinancialAccount.restricted_features[]`

## 15.6.0-beta.1 - 2024-08-01
* [#1728](https://github.com/stripe/stripe-php/pull/1728) Update generated code for beta
  * Add support for `attach_payment` method on resource `Invoice`
  * Add support for `last_price_migration_error` on `SubscriptionSchedule` and `Subscription`

## 15.5.0 - 2024-08-01
* [#1727](https://github.com/stripe/stripe-php/pull/1727) Update generated code
  * Add support for new resources `Billing.AlertTriggered` and `Billing.Alert`
  * Add support for new value `charge_exceeds_transaction_limit` on enum `StripeError.code`
  * Add support for new value `billing.alert.triggered` on enum `Event.type`

## 15.5.0-beta.1 - 2024-07-25
* [#1723](https://github.com/stripe/stripe-php/pull/1723) Update generated code for beta
  * Add support for new resources `Billing.AlertTriggered`, `Billing.Alert`, and `Tax.Association`
  * Add support for `activate`, `all`, `archive`, `create`, `deactivate`, and `retrieve` methods on resource `Alert`
  * Add support for `find` method on resource `Association`
  * Add support for new values `issuing.account_closed_for_not_providing_business_model_clarification`, `issuing.account_closed_for_not_providing_url_clarification`, and `issuing.account_closed_for_not_providing_use_case_clarification` on enum `AccountNotice.reason`
  * Add support for `async_workflows` on `PaymentIntent`
  * Add support for `payto` on `PaymentMethodConfiguration`
  * Add support for `display_name` on `Treasury.FinancialAccount`

## 15.4.0 - 2024-07-25
* [#1726](https://github.com/stripe/stripe-php/pull/1726) Update generated code
  * Add support for `update` method on resource `Checkout.Session`
  * Add support for new values `invoice.overdue` and `invoice.will_be_due` on enum `Event.type`
  * Add support for `twint` on `PaymentMethodConfiguration`

## 15.3.0 - 2024-07-18
* [#1724](https://github.com/stripe/stripe-php/pull/1724) Update generated code
  * Add support for new value `issuing_dispute.funds_rescinded` on enum `Event.type`
  * Add support for new value `stripe_s700` on enum `Terminal.Reader.device_type`
* [#1722](https://github.com/stripe/stripe-php/pull/1722) Update changelog

## 15.3.0-beta.1 - 2024-07-11
* [#1720](https://github.com/stripe/stripe-php/pull/1720) Update generated code for beta

## 15.2.0 - 2024-07-11
* [#1721](https://github.com/stripe/stripe-php/pull/1721) Update generated code
    * ⚠️ Remove support for values `billing_policy_remote_function_response_invalid`, `billing_policy_remote_function_timeout`, `billing_policy_remote_function_unexpected_status_code`, and `billing_policy_remote_function_unreachable` from enum `StripeError.code`.
    * ⚠️ Remove support for value `payment_intent_fx_quote_invalid` from enum `StripeError.code`. The was mistakenly released last week.
    * Add support for `payment_method_options` on `ConfirmationToken`

## 15.2.0-beta.1 - 2024-07-05
* [#1719](https://github.com/stripe/stripe-php/pull/1719) Update generated code for beta
  * Add support for new resource `FinancialConnections.Institution`
  * Add support for `all` and `retrieve` methods on resource `Institution`
  * Add support for new value `balance` on enum `FinancialConnections.Account.subscriptions[]`
* [#1712](https://github.com/stripe/stripe-php/pull/1712) Update generated code for beta

## 15.1.0 - 2024-07-05
* [#1718](https://github.com/stripe/stripe-php/pull/1718) Update generated code
  * Add support for `add_lines`, `remove_lines`, and `update_lines` methods on resource `Invoice`
  * Add support for new value `payment_intent_fx_quote_invalid` on enum `StripeError.code`
  * Add support for new values `multibanco`, `twint`, and `zip` on enum `PaymentLink.payment_method_types[]`
  * Add support for `posted_at` on `Tax.Transaction`
  * Add support for `reboot_window` on `Terminal.Configuration`

## 15.0.0 - 2024-06-24
* [#1714](https://github.com/stripe/stripe-php/pull/1714)

  This release changes the pinned API version to 2024-06-20. Please read the [API Changelog](https://docs.stripe.com/changelog/2024-06-20) and carefully review the API changes before upgrading.

  ### ⚠️ Breaking changes

    * Remove the unused resource `PlatformTaxFee`
    * Remove the protected method `_searchResource` on resources Charge, Customer, Invoice, PaymentIntent, Price, Product, and Subscription as it is no longer used.

  ### Additions

  * Add support for `finalize_amount` test helper method on resource `Issuing.Authorization`
  * Add support for `fleet` and `fuel` on `Issuing.Authorization`
  * Add support for new value `ch_uid` on enum `TaxId.type`

## 14.11.0-beta.1 - 2024-06-13
* [#1705](https://github.com/stripe/stripe-php/pull/1705) Syncing changes from 14.10.0 release

## 14.10.0 - 2024-06-13
* [#1706](https://github.com/stripe/stripe-php/pull/1706) Update generated code
  * Add support for `multibanco` on `PaymentMethodConfiguration` and `PaymentMethod`
  * Add support for `twint` on `PaymentMethod`
  * Add support for new values `multibanco` and `twint` on enum `PaymentMethod.type`
  * Add support for `invoice_settings` on `Subscription`
  * Add support for new value `de_stn` on enum `TaxId.type`

## 14.10.0-beta.1 - 2024-05-30
* [#1699](https://github.com/stripe/stripe-php/pull/1699) Update generated code for beta
  * Keeping up with the changes from version 14.9.0

## 14.9.0 - 2024-05-30
* [#1702](https://github.com/stripe/stripe-php/pull/1702) Update generated code
  * Add support for new values `issuing_personalization_design.activated`, `issuing_personalization_design.deactivated`, `issuing_personalization_design.rejected`, and `issuing_personalization_design.updated` on enum `Event.type`
* [#1701](https://github.com/stripe/stripe-php/pull/1701) Added PHPDocs for `create`, `update`, `delete`, `all`, `retrieve` methods after moving them out of traits.
* [#1700](https://github.com/stripe/stripe-php/pull/1700) Add optional appInfo to StripeClient config
  * `StripeClient` can now accept `$appInfo` as a `$config` option, so AppInfo can be set per-client. If not passed in, will fall back on the global AppInfo set by `Stripe::setAppInfo()`.
    * The config expects `$appInfo` to be of type `array{name: string, version?: string, url?: string, partner_id?: string}`

## 14.9.0-beta.1 - 2024-05-23
* [#1696](https://github.com/stripe/stripe-php/pull/1696) Update generated code for beta

## 14.8.0 - 2024-05-23
* [#1698](https://github.com/stripe/stripe-php/pull/1698) Update generated code
  * Add support for new value `terminal_reader_invalid_location_for_payment` on enum `StripeError.code`
* [#1697](https://github.com/stripe/stripe-php/pull/1697) Rename section for object type generation

## 14.8.0-beta.1 - 2024-05-16
* [#1693](https://github.com/stripe/stripe-php/pull/1693) Update generated code for beta

## 14.7.0 - 2024-05-16
* [#1694](https://github.com/stripe/stripe-php/pull/1694) Update generated code
  * Add support for `fee_source` on `ApplicationFee`
  * Add support for `loss_reason` on `Issuing.Dispute`
  * Add support for `application_fee_amount` and `application_fee` on `Payout`
  * Add support for `stripe_s700` on `Terminal.Configuration`

## 14.7.0-beta.1 - 2024-05-09
* [#1691](https://github.com/stripe/stripe-php/pull/1691) Update generated code for beta
  * No new beta features. Merging changes from the main branch.

## 14.6.0 - 2024-05-09
* [#1692](https://github.com/stripe/stripe-php/pull/1692) Update generated code
  * Add support for `update` test helper method on resources `Treasury.OutboundPayment` and `Treasury.OutboundTransfer`
  * Add support for new values `treasury.outbound_payment.tracking_details_updated` and `treasury.outbound_transfer.tracking_details_updated` on enum `Event.type`
  * Add support for `allow_redisplay` on `PaymentMethod`
  * Add support for `tracking_details` on `Treasury.OutboundPayment` and `Treasury.OutboundTransfer`

## 14.6.0-beta.1 - 2024-05-02
* [#1689](https://github.com/stripe/stripe-php/pull/1689) Update generated code for beta
  * Add support for `rechnung` on `PaymentMethod`
  * Add support for new value `rechnung` on enum `PaymentMethod.type`

## 14.5.0 - 2024-05-02
* [#1688](https://github.com/stripe/stripe-php/pull/1688) Update generated code
  * Add support for new value `shipping_address_invalid` on enum `StripeError.code`
  * Add support for `ship_from_details` on `Tax.Calculation` and `Tax.Transaction`

## 14.5.0-beta.1 - 2024-04-25
* [#1683](https://github.com/stripe/stripe-php/pull/1683) Update generated code for beta
  * Add support for `cancel_subscription_schedule` on `QuoteLine`

## 14.4.0 - 2024-04-25
* [#1684](https://github.com/stripe/stripe-php/pull/1684) Update generated code
  * Change type of `Entitlements.ActiveEntitlement.feature` from `string` to `expandable($Entitlements.Feature)`
  * Add support for `mobilepay` on `PaymentMethodConfiguration`

## 14.4.0-beta.1 - 2024-04-18
* [#1679](https://github.com/stripe/stripe-php/pull/1679) Update generated code for beta

## 14.3.0 - 2024-04-18
* [#1681](https://github.com/stripe/stripe-php/pull/1681) Update generated code
  * Add support for `create_preview` method on resource `Invoice`
  * Add support for `saved_payment_method_options` on `Checkout.Session`
* [#1682](https://github.com/stripe/stripe-php/pull/1682) Added @throws to autoPagingIterator. Fixes [#1678](https://github.com/stripe/stripe-php/issues/1678)

## 14.2.0 - 2024-04-16
* [#1680](https://github.com/stripe/stripe-php/pull/1680) Update generated code
  * Add support for new resource `Entitlements.ActiveEntitlementSummary`
  * Add support for new value `entitlements.active_entitlement_summary.updated` on enum `Event.type`
  * Remove support for `config` on `Forwarding.Request`. This field is no longer used by the Forwarding Request API.
  * Add support for `swish` on `PaymentMethodConfiguration`

## 14.2.0-beta.1 - 2024-04-11
* [#1674](https://github.com/stripe/stripe-php/pull/1674) Merged from master

## 14.1.0 - 2024-04-11
* [#1677](https://github.com/stripe/stripe-php/pull/1677) Update generated code
  * Add support for new values `billing_policy_remote_function_response_invalid`, `billing_policy_remote_function_timeout`, `billing_policy_remote_function_unexpected_status_code`, and `billing_policy_remote_function_unreachable` on enum `StripeError.code`
  * Change type of `Billing.MeterEventAdjustment.cancel` from `BillingMeterResourceBillingMeterEventAdjustmentCancel` to `nullable(BillingMeterResourceBillingMeterEventAdjustmentCancel)`
  * Add support for `amazon_pay` on `PaymentMethodConfiguration` and `PaymentMethod`
  * Add support for new value `amazon_pay` on enum `PaymentMethod.type`
  * Add support for new values `bh_vat`, `kz_bin`, `ng_tin`, and `om_vat` on enum `TaxId.type`

## 14.0.0 - 2024-04-10
* [#1673](https://github.com/stripe/stripe-php/pull/1673)

  * This release changes the pinned API version to `2024-04-10`. Please read the [API Changelog](https://docs.stripe.com/changelog/2024-04-10) and carefully review the API changes before upgrading.

  ### ⚠️ Breaking changes

   * Rename `features` to `marketing_features` on `Product`
   * Do not force resolution to IPv4 - Forcing IPv4 was causing hard-to-understand failures for users in IPv6-only environments. If you want to force IPv4 yourself, you can do so by telling the API client to use a CurlClient other than the default
  ```php
  $curl = new \Stripe\HttpClient\CurlClient([
    CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4
  ]);
  \Stripe\ApiRequestor::setHttpClient($curl);
  ```

  #### ⚠️ Removal of enum values, properties and events that are no longer part of the publicly documented Stripe API

  * Remove the below deprecated values on the enum `BalanceTransaction.Type`
      * `obligation_inbound`
      * `obligation_payout`
      * `obligation_payout_failure`
      * `obligation_reversal_outbound`
   * Remove the deprecated value `various` on the enum `Climate.Supplier.RemovalPathway`
   * Remove deprecated events
     * `invoiceitem.updated`
     * `order.created`
     * `recipient.created`
     * `recipient.deleted`
     * `recipient.updated`
     * `sku.created`
     * `sku.deleted`
     * `sku.updated`
   * Remove the deprecated value `service_tax` on the enum `TaxRate.TaxType`
   * Remove support for `id_bank_transfer`, `multibanco`, `netbanking`, `pay_by_bank`, and `upi` on `PaymentMethodConfiguration`
  * Remove the legacy field `rendering_options` in `Invoice`. Use `rendering` instead.

## 13.18.0 - 2024-04-09
* [#1675](https://github.com/stripe/stripe-php/pull/1675) Update generated code
  * Add support for new resources `Entitlements.ActiveEntitlement` and `Entitlements.Feature`
  * Add support for `all` and `retrieve` methods on resource `ActiveEntitlement`
  * Add support for `all`, `create`, `retrieve`, and `update` methods on resource `Feature`
  * Add support for new value `none` on enum `Account.type`
  * Add support for `cancel`, `event_name`, and `type` on `Billing.MeterEventAdjustment`

## 13.18.0-beta.1 - 2024-04-04
* [#1671](https://github.com/stripe/stripe-php/pull/1671) Update generated code for beta
  * Add support for `update` method on resource `Entitlements.Feature`
  * Add support for `risk_controls` on `Account`
  * Change type of `Subscription.discounts` and `SubscriptionItem.discounts` from `nullable(array(expandable($Discount)))` to `array(expandable($Discount))`
* [#1665](https://github.com/stripe/stripe-php/pull/1665) Update generated code for beta

## 13.17.0 - 2024-04-04
* [#1670](https://github.com/stripe/stripe-php/pull/1670) Update generated code
  * Add support for `subscription_item` on `Discount`
  * Add support for `email` and `phone` on `Identity.VerificationReport`
  * Add support for `verification_flow` on `Identity.VerificationReport` and `Identity.VerificationSession`
  * Add support for new value `verification_flow` on enums `Identity.VerificationReport.type` and `Identity.VerificationSession.type`
  * Add support for `provided_details` on `Identity.VerificationSession`
  * Change type of `Invoice.discounts` from `nullable(array(expandable(deletable($Discount))))` to `array(expandable(deletable($Discount)))`
  * Add support for `zip` on `PaymentMethodConfiguration`
  * Add support for `discounts` on `SubscriptionItem` and `Subscription`
  * Add support for new value `mobile_phone_reader` on enum `Terminal.Reader.device_type`

## 13.16.0 - 2024-03-28
* [#1666](https://github.com/stripe/stripe-php/pull/1666) Update generated code
  * Add support for new resources `Billing.MeterEventAdjustment`, `Billing.MeterEvent`, and `Billing.Meter`
  * Add support for `all`, `create`, `deactivate`, `reactivate`, `retrieve`, and `update` methods on resource `Meter`
  * Add support for `create` method on resources `MeterEventAdjustment` and `MeterEvent`
  * Add support for `meter` on `Plan`

## 13.16.0-beta.1 - 2024-03-21
* [#1661](https://github.com/stripe/stripe-php/pull/1661) Update generated code for beta
  * Add support for new resources `Entitlements.ActiveEntitlementSummary` and `Entitlements.ActiveEntitlement`
  * Add support for `all` method on resource `ActiveEntitlement`
  * Add support for `use_stripe_sdk` on `ConfirmationToken`
  * Remove support for `payment_method` on `ConfirmationToken`
  * Change type of `ConfirmationToken.mandate_data` from `ConfirmationTokensResourceMandateData` to `nullable(ConfirmationTokensResourceMandateData)`
  * Add support for `active` and `metadata` on `Entitlements.Feature`
  * Add support for new value `entitlements.active_entitlement_summary.updated` on enum `Event.type`
  * Remove support for value `customer.entitlement_summary.updated` from enum `Event.type`

## 13.15.0 - 2024-03-21
* [#1664](https://github.com/stripe/stripe-php/pull/1664) Update generated code
  * Add support for new resources `ConfirmationToken` and `Forwarding.Request`
  * Add support for `retrieve` method on resource `ConfirmationToken`
  * Add support for `all`, `create`, and `retrieve` methods on resource `Request`
  * Add support for new values `forwarding_api_inactive`, `forwarding_api_invalid_parameter`, `forwarding_api_upstream_connection_error`, and `forwarding_api_upstream_connection_timeout` on enum `StripeError.code`
  * Add support for `mobilepay` on `PaymentMethod`
  * Add support for new value `mobilepay` on enum `PaymentMethod.type`
  * Add support for `name` on `Terminal.Configuration`

## 13.15.0-beta.1 - 2024-03-14
* [#1659](https://github.com/stripe/stripe-php/pull/1659) Update generated code for beta
  * Add support for new resources `Billing.MeterEventAdjustment`, `Billing.MeterEvent`, and `Billing.Meter`
  * Add support for `all`, `create`, `deactivate`, `reactivate`, `retrieve`, and `update` methods on resource `Meter`
  * Add support for `create` method on resources `MeterEventAdjustment` and `MeterEvent`
  * Add support for `create` test helper method on resource `ConfirmationToken`
  * Add support for `add_lines`, `remove_lines`, and `update_lines` methods on resource `Invoice`
  * Add support for `multibanco` on `PaymentMethodConfiguration` and `PaymentMethod`
  * Add support for new value `multibanco` on enum `PaymentMethod.type`
  * Add support for `meter` on `Plan`

## 13.14.0 - 2024-03-14
* [#1660](https://github.com/stripe/stripe-php/pull/1660) Update generated code
  * Add support for new resources `Issuing.PersonalizationDesign` and `Issuing.PhysicalBundle`
  * Add support for `all`, `create`, `retrieve`, and `update` methods on resource `PersonalizationDesign`
  * Add support for `all` and `retrieve` methods on resource `PhysicalBundle`
  * Add support for `personalization_design` on `Issuing.Card`

## 13.14.0-beta.1 - 2024-02-29
* [#1655](https://github.com/stripe/stripe-php/pull/1655) Update generated code for beta
  * Remove support for resource `Entitlements.Event`
  * Change type of `ConfirmationToken.mandate_data` from `nullable(ConfirmationTokensResourceMandateData)` to `ConfirmationTokensResourceMandateData`
  * Remove support for `quantity` and `type` on `Entitlements.Feature`
  * Add support for `livemode` on `Issuing.PersonalizationDesign`
* [#1656](https://github.com/stripe/stripe-php/pull/1656)  Add helper to set beta version

## 13.13.0 - 2024-02-29
* [#1654](https://github.com/stripe/stripe-php/pull/1654) Update generated code
  * Change type of `Identity.VerificationSession.type` from `nullable(enum('document'|'id_number'))` to `enum('document'|'id_number')`
  * Add resources `Application`, `ConnectCollectionTransfer`, `PlatformTaxFee`, `ReserveTransaction`, `SourceMandateNotification`, and `TaxDeductedAtSource`. These classes have no methods on them, and are used to provide more complete types for PHPDocs.
* [#1657](https://github.com/stripe/stripe-php/pull/1657) Update readme to use addBetaVersion

## 13.13.0-beta.1 - 2024-02-23
* [#1652](https://github.com/stripe/stripe-php/pull/1652) Update generated code for beta

## 13.12.0 - 2024-02-22
* [#1651](https://github.com/stripe/stripe-php/pull/1651) Update generated code
  * Add support for `client_reference_id` on `Identity.VerificationReport` and `Identity.VerificationSession`
  * Remove support for value `service_tax` from enum `TaxRate.tax_type`
* [#1650](https://github.com/stripe/stripe-php/pull/1650) Add TaxIds API
  * Add support for `all`, `create`, `delete`, and `retrieve` methods on resource `TaxId`
  * The `instanceUrl` function on `TaxId` now returns the top-level `/v1/tax_ids/{id}` path instead of the `/v1/customers/{customer}/tax_ids/{id}` path.

## 13.12.0-beta.1 - 2024-02-16
* [#1643](https://github.com/stripe/stripe-php/pull/1643) Update generated code for beta
  * Add support for `decrement_authorization` method on resource `PaymentIntent`
  * Add support for `payment_method_options` on `ConfirmationToken`
  * Add support for `payto` and `twint` on `PaymentMethod`
  * Add support for new values `payto` and `twint` on enum `PaymentMethod.type`

## 13.11.0 - 2024-02-15
* [#1639](https://github.com/stripe/stripe-php/pull/1639) Update generated code
  * Add support for `networks` on `Card`
  * Add support for new value `financial_connections.account.refreshed_ownership` on enum `Event.type`
* [#1648](https://github.com/stripe/stripe-php/pull/1648) Remove broken methods on CustomerCashBalanceTransaction
  * Bugfix: remove support for `CustomerCashBalanceTransaction::all` and `CustomerCashBalanceTransaction::retrieve`. These methods were included in the library unintentionally and never functioned.
* [#1647](https://github.com/stripe/stripe-php/pull/1647) Fix \Stripe\Tax\Settings::update
* [#1646](https://github.com/stripe/stripe-php/pull/1646) Add more specific PHPDoc and Psalm type for RequestOptions arrays on services

## 13.11.0-beta.1 - 2024-02-01
* [#1637](https://github.com/stripe/stripe-php/pull/1637) Update generated code for beta
  * Add support for new resources `Entitlements.Event` and `Entitlements.Feature`
  * Add support for `create` method on resource `Event`
  * Add support for `all` and `create` methods on resource `Feature`
  * Add support for new value `customer.entitlement_summary.updated` on enum `Event.type`

## 13.10.0 - 2024-02-01
* [#1636](https://github.com/stripe/stripe-php/pull/1636) Update generated code
  * Add support for new value `swish` on enum `PaymentLink.payment_method_types[]`
  * Add support for `swish` on `PaymentMethod`
  * Add support for new value `swish` on enum `PaymentMethod.type`
  * Add support for `jurisdiction_level` on `TaxRate`
  * Change type of `Terminal.Reader.status` from `string` to `enum('offline'|'online')`
* [#1633](https://github.com/stripe/stripe-php/pull/1633) Update generated code
  * Add support for `issuer` on `Invoice`
  * Add support for `customer_balance` on `PaymentMethodConfiguration`
* [#1630](https://github.com/stripe/stripe-php/pull/1630) Add paginated requests helper function and use in Search and All

## 13.10.0-beta.3 - 2024-01-25
* [#1634](https://github.com/stripe/stripe-php/pull/1634) Update generated code for beta
  * Add support for `create_preview` method on resource `Invoice`
  * Add support for `charged_off_at` on `Capital.FinancingOffer`
  * Add support for `enhanced_eligibility_types` on `Dispute`

## 13.10.0-beta.2 - 2024-01-19
* [#1632](https://github.com/stripe/stripe-php/pull/1632) Beta: report usage of `rawRequest`

## 13.10.0-beta.1 - 2024-01-12
* [#1628](https://github.com/stripe/stripe-php/pull/1628) Update generated code for beta
* [#1626](https://github.com/stripe/stripe-php/pull/1626) Update generated code for beta

## 13.9.0 - 2024-01-12
* [#1629](https://github.com/stripe/stripe-php/pull/1629) Update generated code
  * Add support for new resource `CustomerSession`
  * Add support for `create` method on resource `CustomerSession`
  * Remove support for values `obligation_inbound`, `obligation_payout_failure`, `obligation_payout`, and `obligation_reversal_outbound` from enum `BalanceTransaction.type`
  * Add support for `billing_cycle_anchor_config` on `Subscription`

## 13.9.0-beta.1 - 2024-01-04
* [#1626](https://github.com/stripe/stripe-php/pull/1626) Update generated code for beta
  * Updated stable APIs to the latest version

## 13.8.0 - 2024-01-04
* [#1627](https://github.com/stripe/stripe-php/pull/1627) Update generated code
  * Add support for `retrieve` method on resource `Tax.Registration`

## 13.8.0-beta.1 - 2023-12-22
* [#1622](https://github.com/stripe/stripe-php/pull/1622) Update generated code for beta
  * Add support for new value `shipping_address_invalid` on enum `StripeError.code`
  * Change type of `Invoice.issuer` from `nullable(ConnectAccountReference)` to `ConnectAccountReference`
  * Add support for `ship_from_details` on `Tax.Calculation` and `Tax.Transaction`
* [#1618](https://github.com/stripe/stripe-php/pull/1618) Update generated code for beta

## 13.7.0 - 2023-12-22
* [#1621](https://github.com/stripe/stripe-php/pull/1621) Update generated code
  * Add support for new resource `FinancialConnections.Transaction`
  * Add support for `all` and `retrieve` methods on resource `Transaction`
  * Add support for `subscribe` and `unsubscribe` methods on resource `FinancialConnections.Account`
  * Add support for new value `financial_connections.account.refreshed_transactions` on enum `Event.type`
  * Add support for `subscriptions` and `transaction_refresh` on `FinancialConnections.Account`
  * Add support for new value `transactions` on enum `FinancialConnections.Session.prefetch[]`
  * Add support for `revolut_pay` on `PaymentMethodConfiguration`
  * Remove support for `id_bank_transfer`, `multibanco`, `netbanking`, `pay_by_bank`, and `upi` on `PaymentMethodConfiguration`
  * Change type of `Quote.invoice_settings` from `nullable(InvoiceSettingQuoteSetting)` to `InvoiceSettingQuoteSetting`
  * Add support for `destination_details` on `Refund`

## 13.7.0-beta.1 - 2023-12-08
* [#1617](https://github.com/stripe/stripe-php/pull/1617) Update generated code for beta
  * Add support for `retrieve` method on resource `FinancialConnections.Transaction`
* [#1616](https://github.com/stripe/stripe-php/pull/1616) Merge master into beta

## 13.6.0 - 2023-12-07
* [#1613](https://github.com/stripe/stripe-php/pull/1613) Update generated code
  * Add support for new values `customer_tax_location_invalid` and `financial_connections_no_successful_transaction_refresh` on enum `StripeError.code`
  * Add support for new values `payment_network_reserve_hold` and `payment_network_reserve_release` on enum `BalanceTransaction.type`
  * Remove support for value `various` from enum `Climate.Supplier.removal_pathway`
  * Add support for `inactive_message` and `restrictions` on `PaymentLink`
* [#1612](https://github.com/stripe/stripe-php/pull/1612) Report usage of .save and StripeClient
  * Reports uses of the deprecated `.save` and of `StripeClient` in `X-Stripe-Client-Telemetry`. (You can disable telemetry via `\Stripe\Stripe::setEnableTelemetry(false);`, see the [README](https://github.com/stripe/stripe-php/blob/master/README.md#telemetry).)

## 13.6.0-beta.1 - 2023-11-30
* [#1610](https://github.com/stripe/stripe-php/pull/1610) Update generated code for beta

## 13.5.0 - 2023-11-30
* [#1611](https://github.com/stripe/stripe-php/pull/1611) Update generated code
  * Add support for new resources `Climate.Order`, `Climate.Product`, and `Climate.Supplier`
  * Add support for `all`, `cancel`, `create`, `retrieve`, and `update` methods on resource `Order`
  * Add support for `all` and `retrieve` methods on resources `Product` and `Supplier`
  * Add support for new value `financial_connections_account_inactive` on enum `StripeError.code`
  * Add support for new values `climate_order_purchase` and `climate_order_refund` on enum `BalanceTransaction.type`
  * Add support for new values `climate.order.canceled`, `climate.order.created`, `climate.order.delayed`, `climate.order.delivered`, `climate.order.product_substituted`, `climate.product.created`, and `climate.product.pricing_updated` on enum `Event.type`

## 13.5.0-beta.1 - 2023-11-21
* [#1606](https://github.com/stripe/stripe-php/pull/1606) Update generated code for beta
  * Add support for `components` and `created` on `CustomerSession`
* [#1600](https://github.com/stripe/stripe-php/pull/1600) Update generated code for beta
  * Add support for new value `quote.reestimate_failed` on enum `Event.type`
  * Add support for `metadata` on `QuotePhase`

## 13.4.0 - 2023-11-21
* [#1608](https://github.com/stripe/stripe-php/pull/1608) Update generated code
  Add support for `transferred_to_balance` to `CustomerCashBalanceTransaction`
* [#1605](https://github.com/stripe/stripe-php/pull/1605) Update generated code
  * Add support for `network_data` on `Issuing.Transaction`

## 13.4.0-beta.1 - 2023-11-10
* [#1600](https://github.com/stripe/stripe-php/pull/1600) Update generated code for beta
  * Add support for new value `quote.reestimate_failed` on enum `Event.type`
  * Add support for `metadata` on `QuotePhase`

## 13.3.0 - 2023-11-09
* [#1603](https://github.com/stripe/stripe-php/pull/1603) Update generated code
  * Add support for new value `terminal_reader_hardware_fault` on enum `StripeError.code`

## 13.3.0-beta.1 - 2023-11-02
* [#1598](https://github.com/stripe/stripe-php/pull/1598) Update generated code for beta
  * Add support for `attach_payment_intent` method on resource `Invoice`
  * Add support for `post_payment_amount`, `pre_payment_amount`, and `refunds` on `CreditNote`
  * Add support for new value `invoice.payment.overpaid` on enum `Event.type`
  * Add support for `amounts_due` and `payments` on `Invoice`
  * Add support for `created` on `Issuing.PersonalizationDesign`

## 13.2.1 - 2023-11-06
* [#1602](https://github.com/stripe/stripe-php/pull/1602) Fix error when "id" is not a string.

## 13.2.0 - 2023-11-02
* [#1599](https://github.com/stripe/stripe-php/pull/1599) Update generated code
  * Add support for new resource `Tax.Registration`
  * Add support for `all`, `create`, and `update` methods on resource `Registration`
  * Add support for new value `token_card_network_invalid` on enum `StripeError.code`
  * Add support for new value `payment_unreconciled` on enum `BalanceTransaction.type`
  * Add support for `revolut_pay` on `PaymentMethod`
  * Add support for new value `revolut_pay` on enum `PaymentMethod.type`

## 13.2.0-beta.1 - 2023-10-26
* [#1596](https://github.com/stripe/stripe-php/pull/1596) Update generated code for beta
  * Add support for new resource `Margin`
  * Add support for `all`, `create`, `retrieve`, and `update` methods on resource `Margin`
  * Add support for `default_margins` and `total_margin_amounts` on `Invoice`
  * Add support for `margins` on `InvoiceItem`

## 13.1.0 - 2023-10-26
* [#1595](https://github.com/stripe/stripe-php/pull/1595) Update generated code
  * Add support for new value `balance_invalid_parameter` on enum `StripeError.code`

## 13.1.0-beta.1 - 2023-10-17
* [#1594](https://github.com/stripe/stripe-php/pull/1594) Update generated code for beta
  - Update pinned API version to `2023-10-16`

## 13.0.0 - 2023-10-16
* This release changes the pinned API version to `2023-10-16`. Please read the [API Changelog](https://docs.stripe.com/changelog/2023-10-16) and carefully review the API changes before upgrading `stripe-php` package.
* [#1593](https://github.com/stripe/stripe-php/pull/1593) Update generated code
  - Added `additional_tos_acceptances` field on `Person`

## 12.9.0-beta.1 - 2023-10-16
* [#1591](https://github.com/stripe/stripe-php/pull/1591) Update generated code for beta

## 12.8.0 - 2023-10-16
* [#1590](https://github.com/stripe/stripe-php/pull/1590) Update generated code
  * Add support for new values `issuing_token.created` and `issuing_token.updated` on enum `Event.type`

## 12.8.0-beta.1 - 2023-10-11
* [#1588](https://github.com/stripe/stripe-php/pull/1588) Update generated code for beta
  * Add support for new resources `AccountNotice` and `Issuing.CreditUnderwritingRecord`
  * Add support for `all`, `retrieve`, and `update` methods on resource `AccountNotice`
  * Add support for `all`, `correct`, `create_from_application`, `create_from_proactive_review`, `report_decision`, and `retrieve` methods on resource `CreditUnderwritingRecord`
  * Add support for new values `account_notice.created` and `account_notice.updated` on enum `Event.type`

## 12.7.0 - 2023-10-11
* [#1589](https://github.com/stripe/stripe-php/pull/1589) Update generated code
  * Add support for `client_secret`, `redirect_on_completion`, `return_url`, and `ui_mode` on `Checkout.Session`
  * Add support for `offline` on `Terminal.Configuration`

## 12.7.0-beta.1 - 2023-10-05
* [#1587](https://github.com/stripe/stripe-php/pull/1587) Update generated code for beta
  * Add support for `mark_draft` and `mark_stale` methods on resource `Quote`
  * Remove support for `draft_quote` and `mark_stale_quote` methods on resource `Quote`
  * Add support for `allow_backdated_lines` on `Quote`
  * Rename `previewInvoiceLines` to `allPreviewInvoiceLines` on resource `Quote`

## 12.6.0 - 2023-10-05
* [#1586](https://github.com/stripe/stripe-php/pull/1586) Update generated code
  * Add support for new resource `Issuing.Token`
  * Add support for `all`, `retrieve`, and `update` methods on resource `Token`
  * Add support for `token` on `Issuing.Authorization` and `Issuing.Transaction`
* [#1569](https://github.com/stripe/stripe-php/pull/1569) Fix: Do not bother removing `friendsofphp/php-cs-fixer`

## 12.6.0-beta.1 - 2023-09-28
* [#1585](https://github.com/stripe/stripe-php/pull/1585) Update generated code for beta
  * Rename resources `Issuing.CardDesign` and `Issuing.CardBundle` to `Issuing.PersonalizationDesign` and `Issuing.PhysicalBundle`
  * Add support for `reason` on `Event`

## 12.5.0 - 2023-09-28
* [#1582](https://github.com/stripe/stripe-php/pull/1582) Generate Discount, SourceTransaction and use sections in more places
* [#1584](https://github.com/stripe/stripe-php/pull/1584) Update generated code
  * Add support for `rendering` on `Invoice`

## 12.5.0-beta.1 - 2023-09-21
* [#1578](https://github.com/stripe/stripe-php/pull/1578) Update generated code for beta
  * Remove support for `customer` on `ConfirmationToken`
  * Add support for `issuer` on `Invoice`

## 12.4.0 - 2023-09-21
* [#1579](https://github.com/stripe/stripe-php/pull/1579) Update generated code
  * Add back constant for `invoiceitem.updated` webhook event.  This was mistakenly removed in v12.2.0.
* [#1566](https://github.com/stripe/stripe-php/pull/1566) Fix: Remove `squizlabs/php_codesniffer`
* [#1568](https://github.com/stripe/stripe-php/pull/1568) Enhancement: Reference `phpunit.xsd` as installed with `composer`
* [#1565](https://github.com/stripe/stripe-php/pull/1565) Enhancement: Use PHP 8.2 as leading PHP version

## 12.4.0-beta.1 - 2023-09-14
* [#1575](https://github.com/stripe/stripe-php/pull/1575) Update generated code for beta
  * Add support for new resource `ConfirmationToken`
  * Add support for `retrieve` method on resource `ConfirmationToken`
  * Add support for `create` method on resource `Issuing.CardDesign`
  * Add support for `reject_testmode` test helper method on resource `Issuing.CardDesign`
  * Add support for new value `issuing_card_design.rejected` on enum `Event.type`
  * Add support for `features` on `Issuing.CardBundle`
  * Add support for `card_logo`, `carrier_text`, `preferences`, and `rejection_reasons` on `Issuing.CardDesign`
  * Remove support for `preference` on `Issuing.CardDesign`

## 12.3.0 - 2023-09-14
* [#1577](https://github.com/stripe/stripe-php/pull/1577) Update generated code
  * Add support for new resource `PaymentMethodConfiguration`
  * Add support for `all`, `create`, `retrieve`, and `update` methods on resource `PaymentMethodConfiguration`
  * Add support for `payment_method_configuration_details` on `Checkout.Session`, `PaymentIntent`, and `SetupIntent`
* [#1573](https://github.com/stripe/stripe-php/pull/1573) Update generated code
  * Add support for `capture`, `create`, `expire`, `increment`, and `reverse` test helper methods on resource `Issuing.Authorization`
  * Add support for `create_force_capture`, `create_unlinked_refund`, and `refund` test helper methods on resource `Issuing.Transaction`
  * Add support for new value `stripe_tax_inactive` on enum `StripeError.code`

## 12.3.0-beta.1 - 2023-09-07
* [#1574](https://github.com/stripe/stripe-php/pull/1574) Update generated code for beta
  * Release specs are identical.
* [#1572](https://github.com/stripe/stripe-php/pull/1572) Update generated code for beta
  * Remove support for `submit_card` test helper method on resource `Issuing.Card`
  * Add support for new value `platform_default` on enum `Issuing.CardDesign.preference`

## 12.2.0 - 2023-09-07
* [#1571](https://github.com/stripe/stripe-php/pull/1571) Update generated code
  * Add support for new resource `PaymentMethodDomain`
  * Add support for `all`, `create`, `retrieve`, `update`, and `validate` methods on resource `PaymentMethodDomain`
  * Add support for new values `treasury.credit_reversal.created`, `treasury.credit_reversal.posted`, `treasury.debit_reversal.completed`, `treasury.debit_reversal.created`, `treasury.debit_reversal.initial_credit_granted`, `treasury.financial_account.closed`, `treasury.financial_account.created`, `treasury.financial_account.features_status_updated`, `treasury.inbound_transfer.canceled`, `treasury.inbound_transfer.created`, `treasury.inbound_transfer.failed`, `treasury.inbound_transfer.succeeded`, `treasury.outbound_payment.canceled`, `treasury.outbound_payment.created`, `treasury.outbound_payment.expected_arrival_date_updated`, `treasury.outbound_payment.failed`, `treasury.outbound_payment.posted`, `treasury.outbound_payment.returned`, `treasury.outbound_transfer.canceled`, `treasury.outbound_transfer.created`, `treasury.outbound_transfer.expected_arrival_date_updated`, `treasury.outbound_transfer.failed`, `treasury.outbound_transfer.posted`, `treasury.outbound_transfer.returned`, `treasury.received_credit.created`, `treasury.received_credit.failed`, `treasury.received_credit.succeeded`, and `treasury.received_debit.created` on enum `Event.type`
  * Remove support for value `invoiceitem.updated` from enum `Event.type`
  * Add support for `features` on `Product`

## 12.2.0-beta.1 - 2023-08-31
* [#1559](https://github.com/stripe/stripe-php/pull/1559) Update generated code for beta
  * Rename `Quote.previewInvoices` to `Quote.allPreviewInvoices` and `Quote.previewSubscriptionSchedules` to `Quote.allSubscriptionSchedules`

## 12.1.0 - 2023-08-31
* [#1560](https://github.com/stripe/stripe-php/pull/1560) Update generated code
  * Add support for new resource `AccountSession`
  * Add support for `create` method on resource `AccountSession`
  * Add support for new values `obligation_inbound`, `obligation_outbound`, `obligation_payout_failure`, `obligation_payout`, `obligation_reversal_inbound`, and `obligation_reversal_outbound` on enum `BalanceTransaction.type`
  * Change type of `Event.type` from `string` to `enum`
  * Add support for `application` on `PaymentLink`
* [#1562](https://github.com/stripe/stripe-php/pull/1562) Nicer ApiErrorException::__toString()
* [#1558](https://github.com/stripe/stripe-php/pull/1558) Update generated code
  * Add support for `payment_method_details` on `Dispute`
  * Add support for `prefetch` on `FinancialConnections.Session`

## 12.0.0 - 2023-08-18
**⚠️ ACTION REQUIRED: the breaking change in this release likely affects you ⚠️**

## 12.0.0-beta.1 - 2023-08-24
* [#1549](https://github.com/stripe/stripe-php/pull/1549) Update generated code for beta
  * Add support for new resources `QuotePreviewInvoice` and `QuotePreviewSchedule`
  * Remove support for `applies_to` on `Invoice` and `SubscriptionSchedule`
* [#1556](https://github.com/stripe/stripe-php/pull/1556) Merge master into beta

## 11.0.0 - 2023-08-16
Please do not use stripe-php v11. It did not correctly apply the [pinning behavior](https://github.com/stripe/stripe-php/blob/master/CHANGELOG.md#version-pinning) and was removed from packagist

## 10.22.0-beta.1 - 2023-08-10
* [#1545](https://github.com/stripe/stripe-php/pull/1545) Update generated code for beta
  * Add support for `paypal` on `PaymentMethodConfiguration`

## 10.21.0 - 2023-08-10
* [#1546](https://github.com/stripe/stripe-php/pull/1546) Update generated code
  * Add support for new value `payment_reversal` on enum `BalanceTransaction.type`
  * Add support for new value `adjusted_for_overdraft` on enum `CustomerBalanceTransaction.type`

## 10.21.0-beta.1 - 2023-08-03
* [#1541](https://github.com/stripe/stripe-php/pull/1541) Update generated code for beta
  * Add support for `submit_card` test helper method on resource `Issuing.Card`

## 10.20.0 - 2023-08-03
* [#1539](https://github.com/stripe/stripe-php/pull/1539) Update generated code
  * Add support for `subscription_details` on `Invoice`
  * Add support for new values `sepa_debit_fingerprint` and `us_bank_account_fingerprint` on enum `Radar.ValueList.item_type`

## 10.20.0-beta.2 - 2023-07-28
* [#1537](https://github.com/stripe/stripe-php/pull/1537) Update generated code for beta
  * Release specs are identical.
* [#1535](https://github.com/stripe/stripe-php/pull/1535) Update generated code for beta
  * Add support for new resource `Tax.Form`
  * Add support for `all`, `pdf`, and `retrieve` methods on resource `Form`
  * Add support for `payment_method_configuration_details` on `Checkout.Session` and `SetupIntent`
* [#1532](https://github.com/stripe/stripe-php/pull/1532) Update generated code for beta
* [#1531](https://github.com/stripe/stripe-php/pull/1531) Merge master into beta

## 10.20.0-beta.1 - 2023-07-27
  * Updated stable APIs to the latest version

## 10.19.0 - 2023-07-27
* [#1534](https://github.com/stripe/stripe-php/pull/1534) Update generated code
  * Improve PHPDoc type for `ApplicationFee.refunds`
  * Add support for `deleted` on `Apps.Secret`
* [#1526](https://github.com/stripe/stripe-php/pull/1526) Add constants for payment intent cancellation reasons
* [#1533](https://github.com/stripe/stripe-php/pull/1533) Update generated code
  * Add support for new value `service_tax` on enum `TaxRate.tax_type`
* [#1487](https://github.com/stripe/stripe-php/pull/1487) PHPDoc: use union of literals for $method parameter throughout

## 10.18.0 - 2023-07-20
* [#1533](https://github.com/stripe/stripe-php/pull/1533) Update generated code
  * Add support for new value `service_tax` on enum `TaxRate.tax_type`
* [#1526](https://github.com/stripe/stripe-php/pull/1526) Add constants for payment intent cancellation reasons
* [#1487](https://github.com/stripe/stripe-php/pull/1487) PHPDoc: use union of literals for $method parameter throughout

## 10.18.0-beta.1 - 2023-07-13
* [#1527](https://github.com/stripe/stripe-php/pull/1527) Update generated code for beta
  Release specs are identical.
* [#1524](https://github.com/stripe/stripe-php/pull/1524) Update generated code for beta
  * Add support for new resource `PaymentMethodConfiguration`
  * Add support for `all`, `create`, `retrieve`, and `update` methods on resource `PaymentMethodConfiguration`
  * Add support for `payment_method_configuration_details` on `PaymentIntent`
  * Rename `Tax.SettingService` -> `Tax.SettingsService` (parity with main release)
* [#1519](https://github.com/stripe/stripe-php/pull/1519) Update generated code for beta
  * Rename `Tax.SettingsService` -> `Tax.SettingService`

## 10.17.0 - 2023-07-13
* [#1525](https://github.com/stripe/stripe-php/pull/1525) Update generated code
  * Add support for new resource `Tax.Settings`
  * Add support for `retrieve` and `update` methods on resource `Settings`
  * Add support for new value `invalid_tax_location` on enum `StripeError.code`
  * Add support for `product` on `Tax.TransactionLineItem`
  * Add constant for `tax.settings.updated` webhook event
* [#1520](https://github.com/stripe/stripe-php/pull/1520) Update generated code
  * Release specs are identical.

## 10.16.0 - 2023-06-29
* [#1517](https://github.com/stripe/stripe-php/pull/1517) Update generated code
  * Add support for new value `application_fees_not_allowed` on enum `StripeError.code`
  * Add support for `effective_at` on `CreditNote` and `Invoice`
  * Add support for `on_behalf_of` on `Mandate`
* [#1514](https://github.com/stripe/stripe-php/pull/1514) Update generated code
  * Release specs are identical.
* [#1512](https://github.com/stripe/stripe-php/pull/1512) Update generated code
  * Change type of `Checkout.Session.success_url` from `string` to `nullable(string)`

## 10.16.0-beta.1 - 2023-06-22
* [#1515](https://github.com/stripe/stripe-php/pull/1515) Update generated code for beta
  * Add support for new resource `CustomerSession`
  * Add support for `create` method on resource `CustomerSession`
* [#1513](https://github.com/stripe/stripe-php/pull/1513) Update generated code for beta
  * Add support for `payment_details` on `PaymentIntent`
* [#1510](https://github.com/stripe/stripe-php/pull/1510) Update generated code for beta

## 10.15.0 - 2023-06-08
* [#1506](https://github.com/stripe/stripe-php/pull/1506) Update generated code
  * Add support for `preferred_locales` on `Issuing.Cardholder`

## 10.15.0-beta.2 - 2023-06-01
* [#1507](https://github.com/stripe/stripe-php/pull/1507) Update generated code for beta
  * Add support for `subscription_details` on `Invoice`
  * Add support for `set_pause_collection` on `QuoteLine`
  * Remove support for `locations` on `Tax.Settings`

## 10.15.0-beta.1 - 2023-05-25
* [#1500](https://github.com/stripe/stripe-php/pull/1500) Update generated code for beta
* [#1505](https://github.com/stripe/stripe-php/pull/1505) Handle developer message in preview error responses
* [#1504](https://github.com/stripe/stripe-php/pull/1504) Add default values for preview and raw_request parameters

## 10.14.0 - 2023-05-25
* [#1503](https://github.com/stripe/stripe-php/pull/1503) Update generated code
  * Add support for `zip` on `PaymentMethod`
  * Add support for new value `zip` on enum `PaymentMethod.type`
* [#1502](https://github.com/stripe/stripe-php/pull/1502) Generate error codes
* [#1501](https://github.com/stripe/stripe-php/pull/1501) Update generated code

* [#1499](https://github.com/stripe/stripe-php/pull/1499) Update generated code
  * Add support for new values `amusement_tax` and `communications_tax` on enum `TaxRate.tax_type`

## 10.14.0-beta.2 - 2023-05-19
* [#1498](https://github.com/stripe/stripe-php/pull/1498) Update generated code for beta
  * Add support for `subscribe` and `unsubscribe` methods on resource `FinancialConnections.Account`
  * Add support for `status_details` and `status` on `Tax.Settings`
* [#1486](https://github.com/stripe/stripe-php/pull/1486) Add $stripe->rawRequest

## 10.14.0-beta.1 - 2023-05-11
* [#1489](https://github.com/stripe/stripe-php/pull/1489) Update generated code for beta
  * Add support for `head_office` on `Tax.Settings`
* [#1497](https://github.com/stripe/stripe-php/pull/1497) Fix phpstan errors
* [#1484](https://github.com/stripe/stripe-php/pull/1484) Update generated code for beta

## 10.13.0 - 2023-05-11
* [#1490](https://github.com/stripe/stripe-php/pull/1490) Update generated code
  * Add support for `paypal` on `PaymentMethod`
  * Add support for `effective_percentage` on `TaxRate`
* [#1488](https://github.com/stripe/stripe-php/pull/1488) Increment PHPStan to strictness level 2
* [#1483](https://github.com/stripe/stripe-php/pull/1483) Update generated code

* [#1480](https://github.com/stripe/stripe-php/pull/1480) Update generated code
  * Change type of `Identity.VerificationSession.options` from `VerificationSessionOptions` to `nullable(VerificationSessionOptions)`
  * Change type of `Identity.VerificationSession.type` from `enum('document'|'id_number')` to `nullable(enum('document'|'id_number'))`
* [#1478](https://github.com/stripe/stripe-php/pull/1478) Update generated code
  * Release specs are identical.
* [#1475](https://github.com/stripe/stripe-php/pull/1475) Update generated code

## 10.13.0-beta.4 - 2023-04-20
* [#1481](https://github.com/stripe/stripe-php/pull/1481) Update generated code for beta
  * Add support for `country_options` on `Tax.Registration`
  * Remove support for `state` and `type` on `Tax.Registration`

## 10.13.0-beta.3 - 2023-04-13
* [#1477](https://github.com/stripe/stripe-php/pull/1477) Update generated code for beta
  * Add support for `collect_payment_method` and `confirm_payment_intent` methods on resource `Terminal.Reader`

## 10.13.0-beta.2 - 2023-04-06
* [#1472](https://github.com/stripe/stripe-php/pull/1472) Update generated code for beta
  * Updated stable APIs to the latest version

## 10.13.0-beta.1 - 2023-03-30
* [#1469](https://github.com/stripe/stripe-php/pull/1469) Update generated code
  * Add support for new value `ioss` on enum `Tax.Registration.type`

## 10.12.1 - 2023-04-04
* [#1473](https://github.com/stripe/stripe-php/pull/1473) Update generated code
  * Add back `deleted` from `Invoice.status`.

## 10.12.0 - 2023-03-30
* [#1470](https://github.com/stripe/stripe-php/pull/1470) Update generated code
  * Remove support for `create` method on resource `Tax.Transaction`
    * This is not a breaking change, as this method was deprecated before the Tax Transactions API was released in favor of the `createFromCalculation` method.
  * Remove support for value `deleted` from enum `Invoice.status`
    * This is not a breaking change, as the value was never returned or accepted as input.
* [#1468](https://github.com/stripe/stripe-php/pull/1468) Trigger workflow for tags
* [#1467](https://github.com/stripe/stripe-php/pull/1467) Update generated code (new)
  * Release specs are identical.

## 10.12.0-beta.1 - 2023-03-23
* [#1459](https://github.com/stripe/stripe-php/pull/1459) Update generated code for beta (new)
  * Add support for new resources `Tax.CalculationLineItem` and `Tax.TransactionLineItem`
  * Add support for `collect_inputs` method on resource `Terminal.Reader`
  * Add support for `financing_offer` on `Capital.FinancingSummary`
  * Add support for new value `link` on enum `PaymentLink.payment_method_types[]`
  * Add support for `automatic_payment_methods` on `SetupIntent`

## 10.11.0 - 2023-03-23
* [#1458](https://github.com/stripe/stripe-php/pull/1458) Update generated code
  * Add support for new resources `Tax.CalculationLineItem`, `Tax.Calculation`, `Tax.TransactionLineItem`, and `Tax.Transaction`
  * Add support for `create` and `list_line_items` methods on resource `Calculation`
  * Add support for `create_from_calculation`, `create_reversal`, `create`, `list_line_items`, and `retrieve` methods on resource `Transaction`
  * Add support for `currency_conversion` on `Checkout.Session`
  * Add support for new value `automatic_async` on enum `PaymentIntent.capture_method`
  * Add support for new value `link` on enum `PaymentLink.payment_method_types[]`
  * Add support for `automatic_payment_methods` on `SetupIntent`

## 10.11.0-beta.1 - 2023-03-16
* [#1456](https://github.com/stripe/stripe-php/pull/1456) API Updates
  * Add support for `create_from_calculation` method on resource `Tax.Transaction`
  * Change type of `Invoice.applies_to` from `nullable(QuotesResourceQuoteLinesAppliesTo)` to `QuotesResourceQuoteLinesAppliesTo`
  * Add support for `shipping_cost` on `Tax.Calculation` and `Tax.Transaction`
  * Add support for `tax_breakdown` on `Tax.Calculation`
  * Remove support for `tax_summary` on `Tax.Calculation`

## 10.10.0 - 2023-03-16
* [#1457](https://github.com/stripe/stripe-php/pull/1457) API Updates
  * Add support for `future_requirements` and `requirements` on `BankAccount`
  * Add support for new value `automatic_async` on enum `PaymentIntent.capture_method`
  * Add support for new value `cashapp` on enum `PaymentLink.payment_method_types[]`
  * Add support for `cashapp` on `PaymentMethod`
  * Add support for new value `cashapp` on enum `PaymentMethod.type`
* [#1454](https://github.com/stripe/stripe-php/pull/1454) Update generated code (new)
  * Add support for new value `cashapp` on enum `PaymentLink.payment_method_types[]`
  * Add support for `cashapp` on `PaymentMethod`
  * Add support for new value `cashapp` on enum `PaymentMethod.type`

## 10.10.0-beta.1 - 2023-03-09
* [#1451](https://github.com/stripe/stripe-php/pull/1451) API Updates for beta branch
  * Updated stable APIs to the latest version
  * Remove support for `list_transactions` method on resource `Tax.Transaction`
  * Change type of `SubscriptionSchedule.applies_to` from `nullable(QuotesResourceQuoteLinesAppliesTo)` to `QuotesResourceQuoteLinesAppliesTo`
  * Add support for `tax_summary` on `Tax.Calculation`
  * Remove support for `tax_breakdown` on `Tax.Calculation`

## 10.9.1 - 2023-03-14
* [#1453](https://github.com/stripe/stripe-php/pull/1453) Restore StripeClient.getService

## 10.9.0 - 2023-03-09
* [#1450](https://github.com/stripe/stripe-php/pull/1450) API Updates
  * Add support for `cancellation_details` on `Subscription`
  * Fix return types on custom methods (extends https://github.com/stripe/stripe-php/pull/1446)

* [#1446](https://github.com/stripe/stripe-php/pull/1446) stripe->customers->retrievePaymentMethod returns the wrong class (type hint)

## 10.9.0-beta.1 - 2023-03-02
* [#1448](https://github.com/stripe/stripe-php/pull/1448) API Updates for beta branch
  * Updated stable APIs to the latest version
  * Add support for new resources `Issuing.CardBundle` and `Issuing.CardDesign`
  * Add support for `all` and `retrieve` methods on resource `CardBundle`
  * Add support for `all`, `retrieve`, and `update` methods on resource `CardDesign`
  * Add support for `card_design` on `Issuing.Card`

## 10.8.0 - 2023-03-02
* [#1447](https://github.com/stripe/stripe-php/pull/1447) API Updates
  * Add support for `reconciliation_status` on `Payout`
  * Add support for new value `lease_tax` on enum `TaxRate.tax_type`

## 10.8.0-beta.1 - 2023-02-23
* [#1445](https://github.com/stripe/stripe-php/pull/1445) API Updates for beta branch
  * Updated stable APIs to the latest version

## 10.7.0 - 2023-02-23
* [#1444](https://github.com/stripe/stripe-php/pull/1444) API Updates
  * Add support for new value `igst` on enum `TaxRate.tax_type`

## 10.7.0-beta.1 - 2023-02-16
* [#1442](https://github.com/stripe/stripe-php/pull/1442) API Updates for beta branch
  * Updated stable APIs to the latest version
  * Add support for `currency_conversion` on `Checkout.Session`
  * Add support for `limits` on `FinancialConnections.Session`
  * Remove support for `reference` on `Tax.Calculation`

## 10.6.1 - 2023-02-21
* [#1443](https://github.com/stripe/stripe-php/pull/1443) Remove init.php from the list of ignored files

## 10.6.0 - 2023-02-16
* [#1441](https://github.com/stripe/stripe-php/pull/1441) API Updates
  * Add support for `refund_payment` method on resource `Terminal.Reader`
  * Add support for `custom_fields` on `Checkout.Session` and `PaymentLink`
* [#1236](https://github.com/stripe/stripe-php/pull/1236) subscription_proration_date not always presented in Invoice
* [#1431](https://github.com/stripe/stripe-php/pull/1431) Fix: Do not use unbounded version constraint for `actions/checkout`
* [#1436](https://github.com/stripe/stripe-php/pull/1436) Enhancement: Enable and configure `visibility_required` fixer
* [#1432](https://github.com/stripe/stripe-php/pull/1432) Enhancement: Update `actions/cache`
* [#1434](https://github.com/stripe/stripe-php/pull/1434) Fix: Remove parentheses
* [#1433](https://github.com/stripe/stripe-php/pull/1433) Enhancement: Run tests on PHP 8.2
* [#1438](https://github.com/stripe/stripe-php/pull/1438) Update .gitattributes

## 10.6.0-beta.1 - 2023-02-02
* [#1440](https://github.com/stripe/stripe-php/pull/1440) API Updates for beta branch
  * Updated stable APIs to the latest version
  * Add support for `all` method on resource `Transaction`
  * Add support for `inferred_balances_refresh`, `subscriptions`, and `transaction_refresh` on `FinancialConnections.Account`
  * Add support for `manual_entry`, `prefetch`, `status_details`, and `status` on `FinancialConnections.Session`
  * Add support for new resource `FinancialConnections.Transaction`

## 10.5.0 - 2023-02-02
* [#1439](https://github.com/stripe/stripe-php/pull/1439) API Updates
  * Add support for `resume` method on resource `Subscription`
  * Add support for `amount_shipping` and `shipping_cost` on `CreditNote` and `Invoice`
  * Add support for `shipping_details` on `Invoice`
  * Add support for `invoice_creation` on `PaymentLink`
  * Add support for `trial_settings` on `Subscription`
  * Add support for new value `paused` on enum `Subscription.status`

## 10.5.0-beta.2 - 2023-01-26
* [#1429](https://github.com/stripe/stripe-php/pull/1429) API Updates for beta branch
  * Updated stable APIs to the latest version
  * Add support for `list_transactions` method on resource `Tax.Transaction`

## 10.5.0-beta.1 - 2023-01-19
* [#1427](https://github.com/stripe/stripe-php/pull/1427) API Updates for beta branch
  * Updated stable APIs to the latest version
  * Add support for `Tax.Settings` resource.

## 10.4.0 - 2023-01-19
* [#1381](https://github.com/stripe/stripe-php/pull/1381) Add getService methods to StripeClient and AbstractServiceFactory to allow mocking
* [#1424](https://github.com/stripe/stripe-php/pull/1424) API Updates

  * Added `REFUND_CREATED`, `REFUND_UPDATED` event definitions.
* [#1426](https://github.com/stripe/stripe-php/pull/1426) Ignore PHP version for formatting
* [#1425](https://github.com/stripe/stripe-php/pull/1425) Fix Stripe::setAccountId parameter type
* [#1418](https://github.com/stripe/stripe-php/pull/1418) Switch to mb_convert_encoding to fix utf8_encode deprecation warning

## 10.4.0-beta.3 - 2023-01-12
* [#1423](https://github.com/stripe/stripe-php/pull/1423) API Updates for beta branch
  * Updated stable APIs to the latest version
  * Add support for `Tax.Registration` resource.
  * Change `draft_quote` method implementation from hitting `/v1/quotes/{quotes}/draft` to `/v1/quotes/{quotes}/mark_draft`

## 10.4.0-beta.2 - 2023-01-05
* [#1420](https://github.com/stripe/stripe-php/pull/1420) API Updates for beta branch
  * Updated stable APIs to the latest version
  * Add support for `mark_stale_quote` method on resource `Quote`

## 10.4.0-beta.1 - 2022-12-22
* [#1414](https://github.com/stripe/stripe-php/pull/1414) API Updates for beta branch
  * Updated stable APIs to the latest version
  * Move `$stripe->taxCalculations` to `$stripe->tax->calculations` and `$stripe->taxTransactions` to `$stripe->tax->transactions`

## 10.3.0 - 2022-12-22
* [#1413](https://github.com/stripe/stripe-php/pull/1413) API Updates
  Change `CheckoutSession.cancel_url` to be nullable.

## 10.3.0-beta.1 - 2022-12-15
* [#1412](https://github.com/stripe/stripe-php/pull/1412) API Updates for beta branch
  * Updated stable APIs to the latest version
  * Add support for new resources `QuoteLine`, `TaxCalculation`, and `TaxTransaction`
  * Add support for `create` and `list_line_items` methods on resource `TaxCalculation`
  * Add support for `create_reversal`, `create`, and `retrieve` methods on resource `TaxTransaction`

## 10.2.0 - 2022-12-15
* [#1411](https://github.com/stripe/stripe-php/pull/1411) API Updates
  * Add support for new value `invoice_overpaid` on enum `CustomerBalanceTransaction.type`
* [#1407](https://github.com/stripe/stripe-php/pull/1407) API Updates

## 10.2.0-beta.1 - 2022-12-08
* [#1408](https://github.com/stripe/stripe-php/pull/1408) API Updates for beta branch
  * Updated stable APIs to the latest version
* [#1406](https://github.com/stripe/stripe-php/pull/1406) API Updates for beta branch
  * Updated stable APIs to the latest version
* [#1398](https://github.com/stripe/stripe-php/pull/1398) API Updates for beta branch
  * Updated stable APIs to the latest version

## 10.1.0 - 2022-12-06
* [#1405](https://github.com/stripe/stripe-php/pull/1405) API Updates
  * Add support for `flow` on `BillingPortal.Session`
* [#1404](https://github.com/stripe/stripe-php/pull/1404) API Updates
  * Remove support for resources `Order` and `Sku`
  * Remove support for `all`, `cancel`, `create`, `list_line_items`, `reopen`, `retrieve`, `submit`, and `update` methods on resource `Order`
  * Remove support for `all`, `create`, `delete`, `retrieve`, and `update` methods on resource `Sku`
  * Add support for `custom_text` on `Checkout.Session` and `PaymentLink`
  * Add support for `invoice_creation` and `invoice` on `Checkout.Session`
  * Remove support for `product` on `LineItem`
  * Add support for `latest_charge` on `PaymentIntent`
  * Remove support for `charges` on `PaymentIntent`

## 10.0.0 - 2022-11-16
* [#1392](https://github.com/stripe/stripe-php/pull/1392) Next major release changes

Breaking changes that arose during code generation of the library that we postponed for the next major version. For changes to the Stripe products, read more at https://docs.stripe.com/changelog/2022-11-15.

"⚠️" symbol highlights breaking changes.

## 9.9.0 - 2022-11-08
* [#1394](https://github.com/stripe/stripe-php/pull/1394) API Updates
  * Add support for new values `eg_tin`, `ph_tin`, and `tr_tin` on enum `TaxId.type`
* [#1389](https://github.com/stripe/stripe-php/pull/1389) API Updates
  * Add support for `on_behalf_of` on `Subscription`
* [#1379](https://github.com/stripe/stripe-php/pull/1379) Do not run Coveralls in PR-s

## 9.9.0-beta.2 - 2022-11-02
* [#1390](https://github.com/stripe/stripe-php/pull/1390) API Updates for beta branch
  * Updated beta APIs to the latest stable version

## 9.9.0-beta.1 - 2022-10-21
* [#1384](https://github.com/stripe/stripe-php/pull/1384) API Updates for beta branch
  * Updated stable APIs to the latest version
  * Add support for `network_data` on `Issuing.Transaction`
  * Add support for `paypal` on `Source`
  * Add support for new value `paypal` on enum `Source.type`

## 9.8.0 - 2022-10-20
* [#1383](https://github.com/stripe/stripe-php/pull/1383) API Updates
  * Add support for new values `jp_trn` and `ke_pin` on enum `TaxId.type`
* [#1293](https://github.com/stripe/stripe-php/pull/1293) Install deps in the install step of CI
* [#1291](https://github.com/stripe/stripe-php/pull/1291) Fix: Configure finder for `friendsofphp/php-cs-fixer`

## 9.7.0 - 2022-10-13
* [#1376](https://github.com/stripe/stripe-php/pull/1376) API Updates
  * Add support for `network_data` on `Issuing.Authorization`
* [#1374](https://github.com/stripe/stripe-php/pull/1374) Add request_log_url on ErrorObject
* [#1370](https://github.com/stripe/stripe-php/pull/1370) API Updates
  * Add support for `created` on `Checkout.Session`

## 9.7.0-beta.2 - 2022-10-07
* [#1373](https://github.com/stripe/stripe-php/pull/1373) API Updates for beta branch
  * Updated stable APIs to the latest version

## 9.7.0-beta.1 - 2022-09-26
* [#1368](https://github.com/stripe/stripe-php/pull/1368) API Updates for beta branch
  * Updated stable APIs to the latest version
  * Add `FinancingOffer`, `FinancingSummary` and `FinancingTransaction` resources.

## 9.6.0 - 2022-09-15
* [#1365](https://github.com/stripe/stripe-php/pull/1365) API Updates
  * Add support for `from_invoice` and `latest_revision` on `Invoice`
  * Add support for new value `pix` on enum `PaymentLink.payment_method_types[]`
  * Add support for `pix` on `PaymentMethod`
  * Add support for new value `pix` on enum `PaymentMethod.type`
  * Add support for `created` on `Treasury.CreditReversal` and `Treasury.DebitReversal`

## 9.5.0 - 2022-09-06
* [#1364](https://github.com/stripe/stripe-php/pull/1364) API Updates
  * Add support for new value `terminal_reader_splashscreen` on enum `File.purpose`
* [#1363](https://github.com/stripe/stripe-php/pull/1363) chore: Update PHP tests to handle search methods.

## 9.4.0 - 2022-08-26
* [#1362](https://github.com/stripe/stripe-php/pull/1362) API Updates
  * Add support for `login_page` on `BillingPortal.Configuration`
* [#1360](https://github.com/stripe/stripe-php/pull/1360) Add test coverage using Coveralls
* [#1361](https://github.com/stripe/stripe-php/pull/1361) fix: Fix type hints for error objects.
  * Update `Invoice.last_finalization_error`, `PaymentIntent.last_payment_error`, `SetupAttempt.setup_error` and `SetupIntent.setup_error` type to be `StripeObject`.
    * Addresses https://github.com/stripe/stripe-php/issues/1353. The library today does not actually return a `ErrorObject` for these fields, so the type annotation was incorrect.
* [#1356](https://github.com/stripe/stripe-php/pull/1356) Add beta readme.md section

## 9.4.0-beta.1 - 2022-08-26
* [#1358](https://github.com/stripe/stripe-php/pull/1358) API Updates for beta branch
  * Updated stable APIs to the latest version
  * Add support for the beta [Gift Card API](https://stripe.com/docs/gift-cards).

## 9.3.0 - 2022-08-23
* [#1355](https://github.com/stripe/stripe-php/pull/1355) API Updates
  * Change type of `Treasury.OutboundTransfer.destination_payment_method` from `string` to `string | null`
  * Change the return type of `CustomerService.fundCashBalance` test helper from `CustomerBalanceTransaction` to `CustomerCashBalanceTransaction`.
    * This would generally be considered a breaking change, but we've worked with all existing users to migrate and are comfortable releasing this as a minor as it is solely a test helper method. This was essentially broken prior to this change.

## 9.3.0-beta.1 - 2022-08-23
* [#1354](https://github.com/stripe/stripe-php/pull/1354) API Updates for beta branch
  - Updated stable APIs to the latest version
  - `Stripe-Version` beta headers are not pinned by-default and need to be manually specified, please refer to [beta SDKs README section](https://github.com/stripe/stripe-php/blob/master/README.md#beta-sdks)

## 9.2.0 - 2022-08-19
* [#1352](https://github.com/stripe/stripe-php/pull/1352) API Updates
  * Add support for new resource `CustomerCashBalanceTransaction`
  * Add support for `currency` on `PaymentLink`
  * Add constant for `customer_cash_balance_transaction.created` webhook event.
* [#1351](https://github.com/stripe/stripe-php/pull/1351) Add a support section to the readme
* [#1304](https://github.com/stripe/stripe-php/pull/1304) Allow passing PSR-3 loggers to setLogger as they are compatible

## 9.2.0-beta.1 - 2022-08-11
* [#1349](https://github.com/stripe/stripe-php/pull/1349) API Updates for beta branch
  - Updated stable APIs to the latest version
  - Add `refundPayment` method to Terminal resource

## 9.1.0 - 2022-08-11
* [#1348](https://github.com/stripe/stripe-php/pull/1348) API Updates
  * Add support for `payment_method_collection` on `Checkout.Session` and `PaymentLink`

* [#1346](https://github.com/stripe/stripe-php/pull/1346) API Updates
  * Add support for `expires_at` on `Apps.Secret`

## 9.1.0-beta.1 - 2022-08-03
* [#1345](https://github.com/stripe/stripe-php/pull/1345) API Updates for beta branch
  - Updated stable APIs to the latest version
  - Added the `Order` resource support

## 9.0.0 - 2022-08-02

Breaking changes that arose during code generation of the library that we postponed for the next major version. For changes to the SDK, read more detailed description at https://github.com/stripe/stripe-php/wiki/Migration-guide-for-v9. For changes to the Stripe products, read more at https://docs.stripe.com/changelog/2022-08-01.

"⚠️" symbol highlights breaking changes.

* [#1344](https://github.com/stripe/stripe-php/pull/1344) API Updates
* [#1337](https://github.com/stripe/stripe-php/pull/1337) API Updates
* [#1273](https://github.com/stripe/stripe-php/pull/1273) Add some PHPDoc return types and fixes
* [#1341](https://github.com/stripe/stripe-php/pull/1341) Next major release changes

## 8.12.0 - 2022-07-25
* [#1332](https://github.com/stripe/stripe-php/pull/1332) API Updates
  * Add support for `default_currency` and `invoice_credit_balance` on `Customer`

## 8.12.0-beta.1 - 2022-07-22
* [#1331](https://github.com/stripe/stripe-php/pull/1331) API Updates for beta branch
  - Updated stable APIs to the latest version
* [#1328](https://github.com/stripe/stripe-php/pull/1328) API Updates for beta branch
  - Updated stable APIs to the latest version
  - Add `QuotePhase` resource
* [#1325](https://github.com/stripe/stripe-php/pull/1325) API Updates for beta branch
  - Updated stable APIs to the latest version
  - Add `QuotePhaseConfiguration` service.
  - Add `Price.migrate_to` property
  - Add `SubscriptionSchedule.amend` method.
  - Add `Discount.subscription_item` property.
  - Add `Quote.subscription_data.billing_behavior`, `billing_cycle_anchor`, `end_behavior`, `from_schedule`, `from_subscription`, `prebilling`, `proration_behavior` properties.
  - Add `phases` parameter to `Quote.create`
  - Add `Subscription.discounts`, `prebilling` properties.
* [#1320](https://github.com/stripe/stripe-php/pull/1320) API Updates for beta branch
  - Include `server_side_confirmation_beta=v1` beta
  - Add `secretKeyConfirmation` to `PaymentIntent`
* [#1317](https://github.com/stripe/stripe-php/pull/1317) API Updates for beta branch
  - Updated stable APIs to the latest version

## 8.11.0 - 2022-07-18
* [#1324](https://github.com/stripe/stripe-php/pull/1324) API Updates
  * Add support for new value `blik` on enum `PaymentLink.payment_method_types[]`
  * Add support for `blik` on `PaymentMethod`
  * Add support for new value `blik` on enum `PaymentMethod.type`
  * Add `Invoice.upcomingLines` method.
  * Add `SourceService.allSourceTransactions` method.
* [#1322](https://github.com/stripe/stripe-php/pull/1322) API Updates
  * Change type of `source_type` on `Transfer` from nullable string to string (comment-only change)

## 8.10.0 - 2022-07-07
* [#1319](https://github.com/stripe/stripe-php/pull/1319) API Updates
  * Add support for `currency_options` on `Coupon` and `Price`
  * Add support for `currency` on `Subscription`
* [#1318](https://github.com/stripe/stripe-php/pull/1318) API Updates
  * Add support for new values financial_connections.account.created, financial_connections.account.deactivated, financial_connections.account.disconnected, financial_connections.account.reactivated, and financial_connections.account.refreshed_balance on `Event`.

## 8.9.0 - 2022-06-29
* [#1316](https://github.com/stripe/stripe-php/pull/1316) API Updates
  * Add support for `deliver_card`, `fail_card`, `return_card`, and `ship_card` test helper methods on resource `Issuing.Card`
  * Add support for `subtotal_excluding_tax` on `CreditNote` and `Invoice`
  * Add support for `amount_excluding_tax` and `unit_amount_excluding_tax` on `CreditNoteLineItem` and `InvoiceLineItem`
  * Add support for `total_excluding_tax` on `Invoice`
  * Change type of `PaymentLink.payment_method_types[]` from `literal('card')` to `enum`
  * Add support for `promptpay` on `PaymentMethod`
  * Add support for new value `promptpay` on enum `PaymentMethod.type`
  * Add support for `hosted_regulatory_receipt_url` and `reversal_details` on `Treasury.ReceivedCredit` and `Treasury.ReceivedDebit`

## 8.8.0 - 2022-06-23
* [#1302](https://github.com/stripe/stripe-php/pull/1302) API Updates
  * Add support for `custom_unit_amount` on `Price`
* [#1301](https://github.com/stripe/stripe-php/pull/1301) API Updates

  Documentation updates.

## 8.7.0 - 2022-06-17
* [#1306](https://github.com/stripe/stripe-php/pull/1306) API Updates
  * Add support for `fund_cash_balance` test helper method on resource `Customer`
  * Add support for `total_excluding_tax` on `CreditNote`
  * Add support for `rendering_options` on `Invoice`
* [#1307](https://github.com/stripe/stripe-php/pull/1307) Support updating pre-release versions
* [#1305](https://github.com/stripe/stripe-php/pull/1305) Trigger workflows on beta branches
* [#1302](https://github.com/stripe/stripe-php/pull/1302) API Updates
  * Add support for `custom_unit_amount` on `Price`
* [#1301](https://github.com/stripe/stripe-php/pull/1301) API Updates

  Documentation updates.

## 8.6.0 - 2022-06-08
* [#1300](https://github.com/stripe/stripe-php/pull/1300) API Updates
  * Add support for `attach_to_self` and `flow_directions` on `SetupAttempt`

## 8.5.0 - 2022-06-01
* [#1298](https://github.com/stripe/stripe-php/pull/1298) API Updates
  * Add support for `radar_options` on `Charge` and `PaymentMethod`
  * Add support for new value `simulated_wisepos_e` on enum `Terminal.Reader.device_type`

## 8.4.0 - 2022-05-26
* [#1296](https://github.com/stripe/stripe-php/pull/1296) API Updates
  * Add support for `persons` method on resource `Account`
  * Add support for `balance_transactions` method on resource `Customer`
  * Add support for `id_number_secondary_provided` on `Person`
* [#1295](https://github.com/stripe/stripe-php/pull/1295) API Updates

## 8.3.0 - 2022-05-23
* [#1294](https://github.com/stripe/stripe-php/pull/1294) API Updates
  * Add support for new resource `Apps.Secret`
  * Add support for `affirm` and `link` on `PaymentMethod`
  * Add support for new values `affirm` and `link` on enum `PaymentMethod.type`
* [#1289](https://github.com/stripe/stripe-php/pull/1289) fix: Update RequestOptions#redactedApiKey to stop exploding null.

## 8.2.0 - 2022-05-19
* [#1286](https://github.com/stripe/stripe-php/pull/1286) API Updates
  * Add support for new resources `Treasury.CreditReversal`, `Treasury.DebitReversal`, `Treasury.FinancialAccountFeatures`, `Treasury.FinancialAccount`, `Treasury.FlowDetails`, `Treasury.InboundTransfer`, `Treasury.OutboundPayment`, `Treasury.OutboundTransfer`, `Treasury.ReceivedCredit`, `Treasury.ReceivedDebit`, `Treasury.TransactionEntry`, and `Treasury.Transaction`
  * Add support for `retrieve_payment_method` method on resource `Customer`
  * Add support for `all` and `list_owners` methods on resource `FinancialConnections.Account`
  * Add support for `treasury` on `Issuing.Authorization`, `Issuing.Dispute`, and `Issuing.Transaction`
  * Add support for `financial_account` on `Issuing.Card`
  * Add support for `client_secret` on `Order`
  * Add support for `attach_to_self` and `flow_directions` on `SetupIntent`

## 8.1.0 - 2022-05-11
* [#1284](https://github.com/stripe/stripe-php/pull/1284) API Updates
  * Add support for `consent_collection`, `customer_creation`, `payment_intent_data`, `shipping_options`, `submit_type`, and `tax_id_collection` on `PaymentLink`
  * Add support for `description` on `Subscription`

## 8.0.0 - 2022-05-09
* [#1283](https://github.com/stripe/stripe-php/pull/1283) Major version release of v8.0.0. The [migration guide](https://github.com/stripe/stripe-php/wiki/Migration-Guide-for-v8) contains more information.
  (⚠️ = breaking changes):
  * ⚠️ Replace the legacy `Order` API with the new `Order` API.
    * Resource modified: `Order`.
    * New methods: `cancel`, `list_line_items`, `reopen`, and `submit`
    * Removed methods: `pay` and `return_order`
    * Removed resources: `OrderItem` and `OrderReturn`
    * Removed references from other resources: `Charge.order`
  * ⚠️ Rename `\FinancialConnections\Account.refresh` method to `\FinancialConnections\Account.refresh_account`
  * Add support for `amount_discount`, `amount_tax`, and `product` on `LineItem`

## 7.128.0 - 2022-05-05
* [#1282](https://github.com/stripe/stripe-php/pull/1282) API Updates
  * Add support for `default_price` on `Product`
  * Add support for `instructions_email` on `Refund`

## 7.127.0 - 2022-05-05
* [#1281](https://github.com/stripe/stripe-php/pull/1281) API Updates
  * Add support for new resources `FinancialConnections.AccountOwner`, `FinancialConnections.AccountOwnership`, `FinancialConnections.Account`, and `FinancialConnections.Session`
* [#1278](https://github.com/stripe/stripe-php/pull/1278) Pin setup-php action version.
* [#1277](https://github.com/stripe/stripe-php/pull/1277) API Updates
  * Add support for `registered_address` on `Person`

## 7.126.0 - 2022-05-03
* [#1276](https://github.com/stripe/stripe-php/pull/1276) API Updates
  * Add support for new resource `CashBalance`
  * Change type of `BillingPortal.Configuration.application` from `$Application` to `deletable($Application)`
  * Add support for `cash_balance` on `Customer`
  * Add support for `application` on `Invoice`, `Quote`, `SubscriptionSchedule`, and `Subscription`
  * Add support for new value `eu_oss_vat` on enum `TaxId.type`
* [#1274](https://github.com/stripe/stripe-php/pull/1274) Fix PHPDoc on Discount for nullable properties
* [#1272](https://github.com/stripe/stripe-php/pull/1272) Allow users to pass a custom IPRESOLVE cURL option.

## 7.125.0 - 2022-04-21
* [#1270](https://github.com/stripe/stripe-php/pull/1270) API Updates
  * Add support for `expire` test helper method on resource `Refund`

## 7.124.0 - 2022-04-18
* [#1265](https://github.com/stripe/stripe-php/pull/1265) API Updates
  * Add support for new resources `FundingInstructions` and `Terminal.Configuration`
  * Add support for `create_funding_instructions` method on resource `Customer`
  * Add support for `amount_details` on `PaymentIntent`
  * Add support for `customer_balance` on `PaymentMethod`
  * Add support for new value `customer_balance` on enum `PaymentMethod.type`
  * Add support for `configuration_overrides` on `Terminal.Location`

## 7.123.0 - 2022-04-13
* [#1263](https://github.com/stripe/stripe-php/pull/1263) API Updates
  * Add support for `increment_authorization` method on resource `PaymentIntent`
* [#1262](https://github.com/stripe/stripe-php/pull/1262) Add support for updating the version of the repo
* [#1230](https://github.com/stripe/stripe-php/pull/1230) Add PHPDoc return types
* [#1242](https://github.com/stripe/stripe-php/pull/1242) Fix some PHPDoc in tests

## 7.122.0 - 2022-04-08
* [#1261](https://github.com/stripe/stripe-php/pull/1261) API Updates
  * Add support for `apply_customer_balance` method on resource `PaymentIntent`
* [#1259](https://github.com/stripe/stripe-php/pull/1259) API Updates

  * Add `payment_intent.partially_funded`, `terminal.reader.action_failed`, and `terminal.reader.action_succeeded` events.

## 7.121.0 - 2022-03-30
* [#1258](https://github.com/stripe/stripe-php/pull/1258) API Updates
  * Add support for `cancel_action`, `process_payment_intent`, `process_setup_intent`, and `set_reader_display` methods on resource `Terminal.Reader`
  * Add support for `action` on `Terminal.Reader`

## 7.120.0 - 2022-03-29
* [#1257](https://github.com/stripe/stripe-php/pull/1257) API Updates
  * Add support for Search API
    * Add support for `search` method on resources `Charge`, `Customer`, `Invoice`, `PaymentIntent`, `Price`, `Product`, and `Subscription`

## 7.119.0 - 2022-03-25
* [#1256](https://github.com/stripe/stripe-php/pull/1256) API Updates
  * Add support for PayNow and US Bank Accounts Debits payments
      * Add support for `paynow` and `us_bank_account` on `PaymentMethod`
      * Add support for new values `paynow` and `us_bank_account` on enum `PaymentMethod.type`
  * Add support for `failure_balance_transaction` on `Charge`

## 7.118.0 - 2022-03-23
* [#1255](https://github.com/stripe/stripe-php/pull/1255) API Updates
  * Add support for `cancel` method on resource `Refund`
  * Add support for new values `bg_uic`, `hu_tin`, and `si_tin` on enum `TaxId.type`
  * Add  `test_helpers.test_clock.advancing`, `test_helpers.test_clock.created`, `test_helpers.test_clock.deleted`, `test_helpers.test_clock.internal_failure`, and `test_helpers.test_clock.ready` events.

## 7.117.0 - 2022-03-18
* [#1254](https://github.com/stripe/stripe-php/pull/1254) API Updates
  * Add support for `status` on `Card`
* [#1251](https://github.com/stripe/stripe-php/pull/1251) Add support for SearchResult objects.
* [#1249](https://github.com/stripe/stripe-php/pull/1249) Add missing constant for payment_behavior

## 7.116.0 - 2022-03-02
* [#1248](https://github.com/stripe/stripe-php/pull/1248) API Updates
  * Add support for `proration_details` on `InvoiceLineItem`

## 7.115.0 - 2022-03-01
* [#1245](https://github.com/stripe/stripe-php/pull/1245) [#1247](https://github.com/stripe/stripe-php/pull/1247) API Updates
  * Add support for new resource `TestHelpers.TestClock`
  * Add support for `test_clock` on `Customer`, `Invoice`, `InvoiceItem`, `Quote`, `Subscription`, and `SubscriptionSchedule`
  * Add support for `next_action` on `Refund`
  * Add support for `konbini` on `PaymentMethod`
* [#1244](https://github.com/stripe/stripe-php/pull/1244) API Updates
  * Add support for new values `bbpos_wisepad3` and `stripe_m2` on enum `Terminal.Reader.device_type`

## 7.114.0 - 2022-02-15
* [#1243](https://github.com/stripe/stripe-php/pull/1243) Add test
* [#1240](https://github.com/stripe/stripe-php/pull/1240) API Updates
  * Add support for `verify_microdeposits` method on resources `PaymentIntent` and `SetupIntent`
* [#1241](https://github.com/stripe/stripe-php/pull/1241) Add generic parameter to \Stripe\Collection usages

## 7.113.0 - 2022-02-03
* [#1239](https://github.com/stripe/stripe-php/pull/1239) API Updates
  * Add `REASON_EXPIRED_UNCAPTURED_CHARGE` enum value on `Refund`.

## 7.112.0 - 2022-01-25
* [#1235](https://github.com/stripe/stripe-php/pull/1235) API Updates
  * Add support for `phone_number_collection` on `PaymentLink`
  * Add support for new value `is_vat` on enum `TaxId.type`

## 7.111.0 - 2022-01-20
* [#1233](https://github.com/stripe/stripe-php/pull/1233) API Updates
  * Add support for new resource `PaymentLink`
  * Add support for `payment_link` on `Checkout.Session`

## 7.110.0 - 2022-01-13
* [#1232](https://github.com/stripe/stripe-php/pull/1232) API Updates
  * Add support for `paid_out_of_band` on `Invoice`

## 7.109.0 - 2022-01-12
* [#1231](https://github.com/stripe/stripe-php/pull/1231) API Updates
  * Add support for `customer_creation` on `Checkout.Session`
* [#1227](https://github.com/stripe/stripe-php/pull/1227) Update docs URLs

## 7.108.0 - 2021-12-22
* [#1226](https://github.com/stripe/stripe-php/pull/1226) Upgrade php-cs-fixer to 3.4.0.
* [#1222](https://github.com/stripe/stripe-php/pull/1222) API Updates
  * Add support for `processing` on `PaymentIntent`
* [#1220](https://github.com/stripe/stripe-php/pull/1220) API Updates

## 7.107.0 - 2021-12-09
* [#1219](https://github.com/stripe/stripe-php/pull/1219) API Updates
  * Add support for `metadata` on `BillingPortal.Configuration`
  * Add support for `wallets` on `Issuing.Card`

## 7.106.0 - 2021-12-09
* [#1218](https://github.com/stripe/stripe-php/pull/1218) API Updates
  * Add support for new values `ge_vat` and `ua_vat` on enum `TaxId.type`
* [#1216](https://github.com/stripe/stripe-php/pull/1216) Fix namespaced classes in @return PHPDoc.
* [#1214](https://github.com/stripe/stripe-php/pull/1214) Announce PHP8 support in CHANGELOG.md

## 7.105.0 - 2021-12-06
* [#1213](https://github.com/stripe/stripe-php/pull/1213) PHP 8.1 missing ReturnTypeWillChange annotations.
* As of this version, PHP 8.1 is officially supported.

## 7.104.0 - 2021-12-01
* [#1211](https://github.com/stripe/stripe-php/pull/1211) PHPStan compatibility with PHP8.x
* [#1209](https://github.com/stripe/stripe-php/pull/1209) PHPUnit compatibility with PHP 8.x

## 7.103.0 - 2021-11-19
* [#1206](https://github.com/stripe/stripe-php/pull/1206) API Updates
  * Add support for new value `jct` on enum `TaxRate.tax_type`

## 7.102.0 - 2021-11-17
* [#1205](https://github.com/stripe/stripe-php/pull/1205) API Updates
  * Add support for `automatic_payment_methods` on `PaymentIntent`

## 7.101.0 - 2021-11-16
* [#1203](https://github.com/stripe/stripe-php/pull/1203) API Updates
  * Add support for new resource `ShippingRate`
  * Add support for `shipping_options` and `shipping_rate` on `Checkout.Session`
  * Add support for `expire` method on resource `Checkout.Session`
  * Add support for `status` on `Checkout.Session`

## 7.100.0 - 2021-10-11
* [#1190](https://github.com/stripe/stripe-php/pull/1190) API Updates
  * Add support for `klarna` on `PaymentMethod`.

## 7.99.0 - 2021-10-11
* [#1188](https://github.com/stripe/stripe-php/pull/1188) API Updates
  * Add support for `list_payment_methods` method on resource `Customer`

## 7.98.0 - 2021-10-07
* [#1187](https://github.com/stripe/stripe-php/pull/1187) API Updates
  * Add support for `phone_number_collection` on `Checkout.Session`
  * Add support for new value `customer_id` on enum `Radar.ValueList.item_type`
  * Add support for new value `bbpos_wisepos_e` on enum `Terminal.Reader.device_type`

## 7.97.0 - 2021-09-16
* [#1181](https://github.com/stripe/stripe-php/pull/1181) API Updates
  * Add support for `full_name_aliases` on `Person`

## 7.96.0 - 2021-09-15
* [#1178](https://github.com/stripe/stripe-php/pull/1178) API Updates
  * Add support for livemode on Reporting.ReportType
  * Add support for new value `rst` on enum `TaxRate.tax_type`

## 7.95.0 - 2021-09-01
* [#1177](https://github.com/stripe/stripe-php/pull/1177) API Updates
  * Add support for `future_requirements` on `Account`, `Capability`, and `Person`
  * Add support for `after_expiration`, `consent`, `consent_collection`, `expires_at`, and `recovered_from` on `Checkout.Session`

## 7.94.0 - 2021-08-19
* [#1173](https://github.com/stripe/stripe-php/pull/1173) API Updates
  * Add support for new value `fil` on enum `Checkout.Session.locale`
  * Add support for new value `au_arn` on enum `TaxId.type`

## 7.93.0 - 2021-08-11
* [#1172](https://github.com/stripe/stripe-php/pull/1172) API Updates
  * Add support for `locale` on `BillingPortal.Session`

* [#1171](https://github.com/stripe/stripe-php/pull/1171) Fix typo in docblock `CurlClient::executeStreamingRequestWithRetries`

## 7.92.0 - 2021-07-28
* [#1167](https://github.com/stripe/stripe-php/pull/1167) API Updates
  * Add support for `account_type` on `BankAccount`
  * Add support for new value `redacted` on enum `Review.closed_reason`

## 7.91.0 - 2021-07-22
* [#1164](https://github.com/stripe/stripe-php/pull/1164) API Updates
  * Add support for new values `hr`, `ko`, and `vi` on enum `Checkout.Session.locale`
  * Add support for `payment_settings` on `Subscription`

## 7.90.0 - 2021-07-20
* [#1163](https://github.com/stripe/stripe-php/pull/1163) API Updates
  * Add support for `wallet` on `Issuing.Transaction`
* [#1160](https://github.com/stripe/stripe-php/pull/1160) Remove unused API error types from docs.

## 7.89.0 - 2021-07-14
* [#1158](https://github.com/stripe/stripe-php/pull/1158) API Updates
  * Add support for `list_computed_upfront_line_items` method on resource `Quote`
* [#1157](https://github.com/stripe/stripe-php/pull/1157) Improve readme for old PHP versions

## 7.88.0 - 2021-07-09
* [#1152](https://github.com/stripe/stripe-php/pull/1152) API Updates
  * Add support for new resource `Quote`
  * Add support for `quote` on `Invoice`
  * Add support for new value `quote_accept` on enum `Invoice.billing_reason`
* [#1155](https://github.com/stripe/stripe-php/pull/1155) Add streaming methods to Service infra
  * Add support for `setStreamingHttpClient` and `streamingHttpClient` to `ApiRequestor`
  * Add support for `getStreamingClient` and `requestStream` to `AbstractService`
  * Add support for `requestStream` to `BaseStripeClient`
  * `\Stripe\RequestOptions::parse` now clones its input if it is already a `RequestOptions` object, to prevent accidental mutation.
* [#1151](https://github.com/stripe/stripe-php/pull/1151) Add `mode` constants into Checkout\Session

## 7.87.0 - 2021-06-30
* [#1149](https://github.com/stripe/stripe-php/pull/1149) API Updates
  * Add support for `wechat_pay` on `PaymentMethod`
* [#1143](https://github.com/stripe/stripe-php/pull/1143) Streaming requests
* [#1138](https://github.com/stripe/stripe-php/pull/1138) Deprecate travis

## 7.86.0 - 2021-06-25
* [#1145](https://github.com/stripe/stripe-php/pull/1145) API Updates
  * Add support for `boleto` on `PaymentMethod`.
  * Add support for `il_vat` as a member of the `TaxID.Type` enum.

## 7.85.0 - 2021-06-18
* [#1142](https://github.com/stripe/stripe-php/pull/1142) API Updates
  * Add support for new TaxId types: `ca_pst_mb`, `ca_pst_bc`, `ca_gst_hst`, and `ca_pst_sk`.

## 7.84.0 - 2021-06-16
* [#1141](https://github.com/stripe/stripe-php/pull/1141) Update PHPDocs
  * Add support for `url` on `Checkout\Session`

## 7.83.0 - 2021-06-07
* [#1140](https://github.com/stripe/stripe-php/pull/1140) API Updates
  * Added support for `tax_id_collection` on `Checkout\Session` and `Checkout\Session#create`
  * Update `Location` to be expandable on `Terminal\Reader`

## 7.82.0 - 2021-06-04
* [#1136](https://github.com/stripe/stripe-php/pull/1136) Update PHPDocs
  * Add support for `controller` on `Account`.

## 7.81.0 - 2021-06-04
* [#1135](https://github.com/stripe/stripe-php/pull/1135) API Updates
  * Add support for new resource `TaxCode`
  * Add support for `automatic_tax` `Invoice` and`Checkout.Session`.
  * Add support for `tax_behavior` on `Price`
  * Add support for `tax_code` on `Product`
  * Add support for `tax` on `Customer`
  * Add support for `tax_type` enum on `TaxRate`

## 7.80.0 - 2021-05-26
* [#1130](https://github.com/stripe/stripe-php/pull/1130) Update PHPDocs

## 7.79.0 - 2021-05-19
* [#1126](https://github.com/stripe/stripe-php/pull/1126) API Updates
  * Added support for new resource `Identity.VerificationReport`
  * Added support for new resource `Identity.VerificationSession`
  * `File#list.purpose` and `File.purpose` added new enum members: `identity_document_downloadable` and `selfie`.

## 7.78.0 - 2021-05-05
* [#1120](https://github.com/stripe/stripe-php/pull/1120) Update PHPDocs
  * Add support for `Radar.EarlyFraudWarning.payment_intent`

## 7.77.0 - 2021-04-12
* [#1110](https://github.com/stripe/stripe-php/pull/1110) Update PHPDocs
  * Add support for `acss_debit` on `PaymentMethod`
  * Add support for `payment_method_options` on `Checkout\Session`
* [#1107](https://github.com/stripe/stripe-php/pull/1107) Remove duplicate object phpdoc

## 7.76.0 - 2021-03-22
* [#1100](https://github.com/stripe/stripe-php/pull/1100) Update PHPDocs
  * Added support for `amount_shipping` on `Checkout.Session.total_details`
* [#1088](https://github.com/stripe/stripe-php/pull/1088) Make possibility to extend CurlClient

## 7.75.0 - 2021-02-22
* [#1094](https://github.com/stripe/stripe-php/pull/1094) Add support for Billing Portal Configuration API

## 7.74.0 - 2021-02-17
* [#1093](https://github.com/stripe/stripe-php/pull/1093) Update PHPDocs
  * Add support for on_behalf_of to Invoice

## 7.73.0 - 2021-02-16
* [#1091](https://github.com/stripe/stripe-php/pull/1091) Update PHPDocs
  * Add support for `afterpay_clearpay` on `PaymentMethod`.

## 7.72.0 - 2021-02-08
* [#1089](https://github.com/stripe/stripe-php/pull/1089) Update PHPDocs
  * Add support for `afterpay_clearpay_payments` on `Account.capabilities`
  * Add support for `payment_settings` on `Invoice`

## 7.71.0 - 2021-02-05
* [#1087](https://github.com/stripe/stripe-php/pull/1087) Update PHPDocs
* [#1086](https://github.com/stripe/stripe-php/pull/1086) Update CA cert bundle URL

## 7.70.0 - 2021-02-03
* [#1085](https://github.com/stripe/stripe-php/pull/1085) Update PHPDocs
  * Add support for `nationality` on `Person`
  * Add member `gb_vat` of `TaxID` enum

## 7.69.0 - 2021-01-21
* [#1079](https://github.com/stripe/stripe-php/pull/1079) Update PHPDocs

## 7.68.0 - 2021-01-14
* [#1063](https://github.com/stripe/stripe-php/pull/1063) Multiple API changes
* [#1061](https://github.com/stripe/stripe-php/pull/1061) Bump phpDocumentor to 3.0.0

## 7.67.0 - 2020-12-09
* [#1060](https://github.com/stripe/stripe-php/pull/1060) Improve PHPDocs for `Discount`
* [#1059](https://github.com/stripe/stripe-php/pull/1059) Upgrade PHPStan to 0.12.59
* [#1057](https://github.com/stripe/stripe-php/pull/1057) Bump PHP-CS-Fixer and update code

## 7.66.1 - 2020-12-01
* [#1054](https://github.com/stripe/stripe-php/pull/1054) Improve error message for invalid keys in StripeClient

## 7.66.0 - 2020-11-24
* [#1053](https://github.com/stripe/stripe-php/pull/1053) Update PHPDocs

## 7.65.0 - 2020-11-19
* [#1050](https://github.com/stripe/stripe-php/pull/1050) Added constants for `proration_behavior` on `Subscription`

## 7.64.0 - 2020-11-18
* [#1049](https://github.com/stripe/stripe-php/pull/1049) Update PHPDocs

## 7.63.0 - 2020-11-17
* [#1048](https://github.com/stripe/stripe-php/pull/1048) Update PHPDocs
* [#1046](https://github.com/stripe/stripe-php/pull/1046) Force IPv4 resolving

## 7.62.0 - 2020-11-09
* [#1041](https://github.com/stripe/stripe-php/pull/1041) Add missing constants on `Event`
* [#1038](https://github.com/stripe/stripe-php/pull/1038) Update PHPDocs

## 7.61.0 - 2020-10-20
* [#1030](https://github.com/stripe/stripe-php/pull/1030) Add support for `jp_rn` and `ru_kpp` as a `type` on `TaxId`

## 7.60.0 - 2020-10-15
* [#1027](https://github.com/stripe/stripe-php/pull/1027) Warn if opts are in params

## 7.58.0 - 2020-10-14
* [#1026](https://github.com/stripe/stripe-php/pull/1026) Add support for the Payout Reverse API

## 7.57.0 - 2020-09-29
* [#1020](https://github.com/stripe/stripe-php/pull/1020) Add support for the `SetupAttempt` resource and List API

## 7.56.0 - 2020-09-25
* [#1019](https://github.com/stripe/stripe-php/pull/1019) Update PHPDocs

## 7.55.0 - 2020-09-24
* [#1018](https://github.com/stripe/stripe-php/pull/1018) Multiple API changes
  * Updated PHPDocs
  * Added `TYPE_CONTRIBUTION` as a constant on `BalanceTransaction`

## 7.54.0 - 2020-09-23
* [#1017](https://github.com/stripe/stripe-php/pull/1017) Updated PHPDoc

## 7.53.1 - 2020-09-22
* [#1015](https://github.com/stripe/stripe-php/pull/1015) Bugfix: don't error on systems with php_uname in disablefunctions with whitespace

## 7.53.0 - 2020-09-21
* [#1016](https://github.com/stripe/stripe-php/pull/1016) Updated PHPDocs

## 7.52.0 - 2020-09-08
* [#1010](https://github.com/stripe/stripe-php/pull/1010) Update PHPDocs

## 7.51.0 - 2020-09-02
* [#1007](https://github.com/stripe/stripe-php/pull/1007) Multiple API changes
  * Add support for the Issuing Dispute Submit API
  * Add constants for `payment_status` on Checkout `Session`
* [#1003](https://github.com/stripe/stripe-php/pull/1003) Add trim to getSignatures to allow for leading whitespace.

## 7.50.0 - 2020-08-28
* [#1005](https://github.com/stripe/stripe-php/pull/1005) Updated PHPDocs

## 7.49.0 - 2020-08-19
* [#998](https://github.com/stripe/stripe-php/pull/998) PHPDocs updated

## 7.48.0 - 2020-08-17
* [#997](https://github.com/stripe/stripe-php/pull/997) PHPDocs updated
* [#996](https://github.com/stripe/stripe-php/pull/996) Fixing telemetry

## 7.47.0 - 2020-08-13
* [#994](https://github.com/stripe/stripe-php/pull/994) Nullable balance_transactions on issuing disputes
* [#991](https://github.com/stripe/stripe-php/pull/991) Fix invalid return types in OAuthService

## 7.46.1 - 2020-08-07
* [#990](https://github.com/stripe/stripe-php/pull/990) PHPdoc changes

## 7.46.0 - 2020-08-05
* [#989](https://github.com/stripe/stripe-php/pull/989) Add support for the `PromotionCode` resource and APIs

## 7.45.0 - 2020-07-28
* [#981](https://github.com/stripe/stripe-php/pull/981) PHPdoc updates

## 7.44.0 - 2020-07-20
* [#948](https://github.com/stripe/stripe-php/pull/948) Add `first()` and `last()` functions to `Collection`

## 7.43.0 - 2020-07-17
* [#975](https://github.com/stripe/stripe-php/pull/975) Add support for `political_exposure` on `Person`

## 7.42.0 - 2020-07-15
* [#974](https://github.com/stripe/stripe-php/pull/974) Add new constants for `purpose` on `File`

## 7.41.1 - 2020-07-15
* [#973](https://github.com/stripe/stripe-php/pull/973) Multiple PHPDoc fixes

## 7.41.0 - 2020-07-14
* [#971](https://github.com/stripe/stripe-php/pull/971) Adds enum values for `billing_address_collection` on Checkout `Session`

## 7.40.0 - 2020-07-06
* [#964](https://github.com/stripe/stripe-php/pull/964) Add OAuthService

## 7.39.0 - 2020-06-25
* [#960](https://github.com/stripe/stripe-php/pull/960) Add constants for `payment_behavior` on `Subscription`

## 7.38.0 - 2020-06-24
* [#959](https://github.com/stripe/stripe-php/pull/959) Add multiple constants missing for `Event`

## 7.37.2 - 2020-06-23
* [#957](https://github.com/stripe/stripe-php/pull/957) Updated PHPDocs

## 7.37.1 - 2020-06-11
* [#952](https://github.com/stripe/stripe-php/pull/952) Improve PHPDoc

## 7.37.0 - 2020-06-09
* [#950](https://github.com/stripe/stripe-php/pull/950) Add support for `id_npwp` and `my_frp` as `type` on `TaxId`

## 7.36.2 - 2020-06-03
* [#946](https://github.com/stripe/stripe-php/pull/946) Update PHPDoc

## 7.36.1 - 2020-05-28
* [#938](https://github.com/stripe/stripe-php/pull/938) Remove extra array_keys() call.
* [#942](https://github.com/stripe/stripe-php/pull/942) fix autopagination for service methods

## 7.36.0 - 2020-05-21
* [#937](https://github.com/stripe/stripe-php/pull/937) Add support for `ae_trn`, `cl_tin` and `sa_vat` as `type` on `TaxId`

## 7.35.0 - 2020-05-20
* [#936](https://github.com/stripe/stripe-php/pull/936) Add `anticipation_repayment` as a `type` on `BalanceTransaction`

## 7.34.0 - 2020-05-18
* [#934](https://github.com/stripe/stripe-php/pull/934) Add support for `issuing_dispute` as a `type` on `BalanceTransaction`

## 7.33.1 - 2020-05-15
* [#933](https://github.com/stripe/stripe-php/pull/933) Services bugfix: convert nested null params to empty strings

## 7.33.0 - 2020-05-14
* [#771](https://github.com/stripe/stripe-php/pull/771) Introduce client/services API. The [migration guide](https://github.com/stripe/stripe-php/wiki/Migration-to-StripeClient-and-services-in-7.33.0) contains before & after examples of the backwards-compatible changes.

## 7.32.1 - 2020-05-13
* [#932](https://github.com/stripe/stripe-php/pull/932) Fix multiple PHPDoc

## 7.32.0 - 2020-05-11
* [#931](https://github.com/stripe/stripe-php/pull/931) Add support for the `LineItem` resource and APIs

## 7.31.0 - 2020-05-01
* [#927](https://github.com/stripe/stripe-php/pull/927) Add support for new tax IDs

## 7.30.0 - 2020-04-29
* [#924](https://github.com/stripe/stripe-php/pull/924) Add support for the `Price` resource and APIs

## 7.29.0 - 2020-04-22
* [#920](https://github.com/stripe/stripe-php/pull/920) Add support for the `Session` resource and APIs on the `BillingPortal` namespace

## 7.28.1 - 2020-04-10
* [#915](https://github.com/stripe/stripe-php/pull/915) Improve PHPdocs for many classes

## 7.28.0 - 2020-04-03
* [#912](https://github.com/stripe/stripe-php/pull/912) Preserve backwards compatibility for typoed `TYPE_ADJUSTEMENT` enum.
* [#911](https://github.com/stripe/stripe-php/pull/911) Codegenerated PHPDoc for nested resources
* [#902](https://github.com/stripe/stripe-php/pull/902) Update docstrings for nested resources

## 7.27.3 - 2020-03-18
* [#899](https://github.com/stripe/stripe-php/pull/899) Convert keys to strings in `StripeObject::toArray()`

## 7.27.2 - 2020-03-13
* [#894](https://github.com/stripe/stripe-php/pull/894) Multiple PHPDocs changes

## 7.27.1 - 2020-03-03
* [#890](https://github.com/stripe/stripe-php/pull/890) Update PHPdoc

## 7.27.0 - 2020-02-28
* [#889](https://github.com/stripe/stripe-php/pull/889) Add new constants for `type` on `TaxId`

## 7.26.0 - 2020-02-26
* [#886](https://github.com/stripe/stripe-php/pull/886) Add support for listing Checkout `Session`
* [#883](https://github.com/stripe/stripe-php/pull/883) Add PHPDoc class descriptions

## 7.25.0 - 2020-02-14
* [#879](https://github.com/stripe/stripe-php/pull/879) Make `\Stripe\Collection` implement `\Countable`
* [#875](https://github.com/stripe/stripe-php/pull/875) Last set of PHP-CS-Fixer updates
* [#874](https://github.com/stripe/stripe-php/pull/874) Enable php_unit_internal_class rule
* [#873](https://github.com/stripe/stripe-php/pull/873) Add support for phpDocumentor in Makefile
* [#872](https://github.com/stripe/stripe-php/pull/872) Another batch of PHP-CS-Fixer rule updates
* [#871](https://github.com/stripe/stripe-php/pull/871) Fix a few PHPDoc comments
* [#870](https://github.com/stripe/stripe-php/pull/870) More PHP-CS-Fixer tweaks

## 7.24.0 - 2020-02-10
* [#862](https://github.com/stripe/stripe-php/pull/862) Better PHPDoc
* [#865](https://github.com/stripe/stripe-php/pull/865) Get closer to `@PhpCsFixer` standard ruleset

## 7.23.0 - 2020-02-05
* [#860](https://github.com/stripe/stripe-php/pull/860) Add PHPDoc types for expandable fields
* [#858](https://github.com/stripe/stripe-php/pull/858) Use `native_function_invocation` PHPStan rule
* [#857](https://github.com/stripe/stripe-php/pull/857) Update PHPDoc on nested resources
* [#855](https://github.com/stripe/stripe-php/pull/855) PHPDoc: `StripeObject` -> `ErrorObject` where appropriate
* [#837](https://github.com/stripe/stripe-php/pull/837) Autogen diff
* [#854](https://github.com/stripe/stripe-php/pull/854) Upgrade PHPStan and fix settings
* [#850](https://github.com/stripe/stripe-php/pull/850) Yet more PHPDoc updates

## 7.22.0 - 2020-01-31
* [#849](https://github.com/stripe/stripe-php/pull/849) Add new constants for `type` on `TaxId`
* [#843](https://github.com/stripe/stripe-php/pull/843) Even more PHPDoc fixes
* [#841](https://github.com/stripe/stripe-php/pull/841) More PHPDoc fixes

## 7.21.1 - 2020-01-29
* [#840](https://github.com/stripe/stripe-php/pull/840) Update phpdocs across multiple resources.

## 7.21.0 - 2020-01-28
* [#839](https://github.com/stripe/stripe-php/pull/839) Add support for `TYPE_ES_CIF` on `TaxId`

## 7.20.0 - 2020-01-23
* [#836](https://github.com/stripe/stripe-php/pull/836) Add new type values for `TaxId`

## 7.19.1 - 2020-01-14
* [#831](https://github.com/stripe/stripe-php/pull/831) Fix incorrect `UnexpectedValueException` instantiation

## 7.19.0 - 2020-01-14
* [#830](https://github.com/stripe/stripe-php/pull/830) Add support for `CreditNoteLineItem`

## 7.18.0 - 2020-01-13
* [#829](https://github.com/stripe/stripe-php/pull/829) Don't call php_uname function if disabled by php.ini

## 7.17.0 - 2020-01-08
* [#821](https://github.com/stripe/stripe-php/pull/821) Improve PHPDoc types for `ApiErrorException.get/setJsonBody()` methods

## 7.16.0 - 2020-01-06
* [#826](https://github.com/stripe/stripe-php/pull/826) Rename remaining `$options` to `$opts`
* [#825](https://github.com/stripe/stripe-php/pull/825) Update PHPDoc

## 7.15.0 - 2020-01-06
* [#824](https://github.com/stripe/stripe-php/pull/824) Add constant `TYPE_SG_UEN` to `TaxId`

## 7.14.2 - 2019-12-04
* [#816](https://github.com/stripe/stripe-php/pull/816) Disable autoloader when checking for `Throwable`

## 7.14.1 - 2019-11-26
* [#812](https://github.com/stripe/stripe-php/pull/812) Fix invalid PHPdoc on `Subscription`

## 7.14.0 - 2019-11-26
* [#811](https://github.com/stripe/stripe-php/pull/811) Add support for `CreditNote` preview.

## 7.13.0 - 2019-11-19
* [#808](https://github.com/stripe/stripe-php/pull/808) Add support for listing lines on an Invoice directly via `Invoice::allLines()`

## 7.12.0 - 2019-11-08

-   [#805](https://github.com/stripe/stripe-php/pull/805) Add Source::allSourceTransactions and SubscriptionItem::allUsageRecordSummaries
-   [#798](https://github.com/stripe/stripe-php/pull/798) The argument of `array_key_exists` cannot be `null`
-   [#803](https://github.com/stripe/stripe-php/pull/803) Removed unwanted got

## 7.11.0 - 2019-11-06

-   [#797](https://github.com/stripe/stripe-php/pull/797) Add support for reverse pagination

## 7.10.0 - 2019-11-05

-   [#795](https://github.com/stripe/stripe-php/pull/795) Add support for `Mandate`

## 7.9.0 - 2019-11-05

-   [#794](https://github.com/stripe/stripe-php/pull/794) Add PHPDoc to `ApiResponse`
-   [#792](https://github.com/stripe/stripe-php/pull/792) Use single quotes for `OBJECT_NAME` constants

## 7.8.0 - 2019-11-05

-   [#790](https://github.com/stripe/stripe-php/pull/790) Mark nullable fields in PHPDoc
-   [#788](https://github.com/stripe/stripe-php/pull/788) Early codegen fixes
-   [#787](https://github.com/stripe/stripe-php/pull/787) Use PHPStan in Travis CI

## 7.7.1 - 2019-10-25

-   [#781](https://github.com/stripe/stripe-php/pull/781) Fix telemetry header
-   [#780](https://github.com/stripe/stripe-php/pull/780) Contributor Convenant

## 7.7.0 - 2019-10-23

-   [#776](https://github.com/stripe/stripe-php/pull/776) Add `CAPABILITY_TRANSFERS` to `Account`
-   [#778](https://github.com/stripe/stripe-php/pull/778) Add support for `TYPE_MX_RFC` type on `TaxId`

## 7.6.0 - 2019-10-22

-   [#770](https://github.com/stripe/stripe-php/pull/770) Add missing constants for Customer's `TaxId`

## 7.5.0 - 2019-10-18

-   [#768](https://github.com/stripe/stripe-php/pull/768) Redact API key in `RequestOptions` debug info

## 7.4.0 - 2019-10-15

-   [#764](https://github.com/stripe/stripe-php/pull/764) Add support for HTTP request monitoring callback

## 7.3.1 - 2019-10-07

-   [#755](https://github.com/stripe/stripe-php/pull/755) Respect Stripe-Should-Retry and Retry-After headers

## 7.3.0 - 2019-10-02

-   [#752](https://github.com/stripe/stripe-php/pull/752) Add `payment_intent.canceled` and `setup_intent.canceled` events
-   [#749](https://github.com/stripe/stripe-php/pull/749) Call `toArray()` on objects only

## 7.2.2 - 2019-09-24

-   [#746](https://github.com/stripe/stripe-php/pull/746) Add missing decline codes

## 7.2.1 - 2019-09-23

-   [#744](https://github.com/stripe/stripe-php/pull/744) Added new PHPDoc

## 7.2.0 - 2019-09-17

-   [#738](https://github.com/stripe/stripe-php/pull/738) Added missing constants for `SetupIntent` events

## 7.1.1 - 2019-09-16

-   [#737](https://github.com/stripe/stripe-php/pull/737) Added new PHPDoc

## 7.1.0 - 2019-09-13

-   [#736](https://github.com/stripe/stripe-php/pull/736) Make `CaseInsensitiveArray` countable and traversable

## 7.0.2 - 2019-09-06

-   [#729](https://github.com/stripe/stripe-php/pull/729) Fix usage of `SignatureVerificationException` in PHPDoc blocks

## 7.0.1 - 2019-09-05

-   [#728](https://github.com/stripe/stripe-php/pull/728) Clean up Collection

## 7.0.0 - 2019-09-03

Major version release. The [migration guide](https://github.com/stripe/stripe-php/wiki/Migration-guide-for-v7) contains a detailed list of backwards-incompatible changes with upgrade instructions.

Pull requests included in this release (cf. [#552](https://github.com/stripe/stripe-php/pull/552)) (⚠️ = breaking changes):

-   ⚠️ Drop support for PHP 5.4 ([#551](https://github.com/stripe/stripe-php/pull/551))
-   ⚠️ Drop support for PHP 5.5 ([#554](https://github.com/stripe/stripe-php/pull/554))
-   Bump dependencies ([#553](https://github.com/stripe/stripe-php/pull/553))
-   Remove `CURLFile` check ([#555](https://github.com/stripe/stripe-php/pull/555))
-   Update constant definitions for PHP >= 5.6 ([#556](https://github.com/stripe/stripe-php/pull/556))
-   ⚠️ Remove `FileUpload` alias ([#557](https://github.com/stripe/stripe-php/pull/557))
-   Remove `curl_reset` check ([#570](https://github.com/stripe/stripe-php/pull/570))
-   Use `\Stripe\<class>::class` constant instead of strings ([#643](https://github.com/stripe/stripe-php/pull/643))
-   Use `array_column` to flatten params ([#686](https://github.com/stripe/stripe-php/pull/686))
-   ⚠️ Remove deprecated methods ([#692](https://github.com/stripe/stripe-php/pull/692))
-   ⚠️ Remove `IssuerFraudRecord` ([#696](https://github.com/stripe/stripe-php/pull/696))
-   Update constructors of Stripe exception classes ([#559](https://github.com/stripe/stripe-php/pull/559))
-   Fix remaining TODOs ([#700](https://github.com/stripe/stripe-php/pull/700))
-   Use yield for autopagination ([#703](https://github.com/stripe/stripe-php/pull/703))
-   ⚠️ Rename fake magic methods and rewrite array conversion ([#704](https://github.com/stripe/stripe-php/pull/704))
-   Add `ErrorObject` to Stripe exceptions ([#705](https://github.com/stripe/stripe-php/pull/705))
-   Start using PHP CS Fixer ([#706](https://github.com/stripe/stripe-php/pull/706))
-   Update error messages for nested resource operations ([#708](https://github.com/stripe/stripe-php/pull/708))
-   Upgrade retry logic ([#707](https://github.com/stripe/stripe-php/pull/707))
-   ⚠️ `Collection` improvements / fixes ([#715](https://github.com/stripe/stripe-php/pull/715))
-   ⚠️ Modernize exceptions ([#709](https://github.com/stripe/stripe-php/pull/709))
-   Add constants for error codes ([#716](https://github.com/stripe/stripe-php/pull/716))
-   Update certificate bundle ([#717](https://github.com/stripe/stripe-php/pull/717))
-   Retry requests on a 429 that's a lock timeout ([#718](https://github.com/stripe/stripe-php/pull/718))
-   Fix `toArray()` calls ([#719](https://github.com/stripe/stripe-php/pull/719))
-   Couple of fixes for PHP 7.4 ([#725](https://github.com/stripe/stripe-php/pull/725))

## 6.43.1 - 2019-08-29

-   [#722](https://github.com/stripe/stripe-php/pull/722) Make `LoggerInterface::error` compatible with its PSR-3 counterpart
-   [#714](https://github.com/stripe/stripe-php/pull/714) Add `pending_setup_intent` property in `Subscription`
-   [#713](https://github.com/stripe/stripe-php/pull/713) Add typehint to `ApiResponse`
-   [#712](https://github.com/stripe/stripe-php/pull/712) Fix comment
-   [#701](https://github.com/stripe/stripe-php/pull/701) Start testing PHP 7.3

## 6.43.0 - 2019-08-09

-   [#694](https://github.com/stripe/stripe-php/pull/694) Add `SubscriptionItem::createUsageRecord` method

## 6.42.0 - 2019-08-09

-   [#688](https://github.com/stripe/stripe-php/pull/688) Remove `SubscriptionScheduleRevision`
    -   Note that this is technically a breaking change, however we've chosen to release it as a minor version in light of the fact that this resource and its API methods were virtually unused.

## 6.41.0 - 2019-07-31

-   [#683](https://github.com/stripe/stripe-php/pull/683) Move the List Balance History API to `/v1/balance_transactions`

## 6.40.0 - 2019-06-27

-   [#675](https://github.com/stripe/stripe-php/pull/675) Add support for `SetupIntent` resource and APIs

## 6.39.2 - 2019-06-26

-   [#676](https://github.com/stripe/stripe-php/pull/676) Fix exception message in `CustomerBalanceTransaction::update()`

## 6.39.1 - 2019-06-25

-   [#674](https://github.com/stripe/stripe-php/pull/674) Add new constants for `collection_method` on `Invoice`

## 6.39.0 - 2019-06-24

-   [#673](https://github.com/stripe/stripe-php/pull/673) Enable request latency telemetry by default

## 6.38.0 - 2019-06-17

-   [#649](https://github.com/stripe/stripe-php/pull/649) Add support for `CustomerBalanceTransaction` resource and APIs

## 6.37.2 - 2019-06-17

-   [#671](https://github.com/stripe/stripe-php/pull/671) Add new PHPDoc
-   [#672](https://github.com/stripe/stripe-php/pull/672) Add constants for `submit_type` on Checkout `Session`

## 6.37.1 - 2019-06-14

-   [#670](https://github.com/stripe/stripe-php/pull/670) Add new PHPDoc

## 6.37.0 - 2019-05-23

-   [#663](https://github.com/stripe/stripe-php/pull/663) Add support for `radar.early_fraud_warning` resource

## 6.36.0 - 2019-05-22

-   [#661](https://github.com/stripe/stripe-php/pull/661) Add constants for new TaxId types
-   [#662](https://github.com/stripe/stripe-php/pull/662) Add constants for BalanceTransaction types

## 6.35.2 - 2019-05-20

-   [#655](https://github.com/stripe/stripe-php/pull/655) Add constants for payment intent statuses
-   [#659](https://github.com/stripe/stripe-php/pull/659) Fix PHPDoc for various nested Account actions
-   [#660](https://github.com/stripe/stripe-php/pull/660) Fix various PHPDoc

## 6.35.1 - 2019-05-20

-   [#658](https://github.com/stripe/stripe-php/pull/658) Use absolute value when checking timestamp tolerance

## 6.35.0 - 2019-05-14

-   [#651](https://github.com/stripe/stripe-php/pull/651) Add support for the Capability resource and APIs

## 6.34.6 - 2019-05-13

-   [#654](https://github.com/stripe/stripe-php/pull/654) Fix typo in definition of `Event::PAYMENT_METHOD_ATTACHED` constant

## 6.34.5 - 2019-05-06

-   [#647](https://github.com/stripe/stripe-php/pull/647) Set the return type to static for more operations

## 6.34.4 - 2019-05-06

-   [#650](https://github.com/stripe/stripe-php/pull/650) Add missing constants for Event types

## 6.34.3 - 2019-05-01

-   [#644](https://github.com/stripe/stripe-php/pull/644) Update return type to `static` to improve static analysis
-   [#645](https://github.com/stripe/stripe-php/pull/645) Fix constant for `payment_intent.payment_failed`

## 6.34.2 - 2019-04-26

-   [#642](https://github.com/stripe/stripe-php/pull/642) Fix an issue where existing idempotency keys would be overwritten when using automatic retries

## 6.34.1 - 2019-04-25

-   [#640](https://github.com/stripe/stripe-php/pull/640) Add missing phpdocs

## 6.34.0 - 2019-04-24

-   [#626](https://github.com/stripe/stripe-php/pull/626) Add support for the `TaxRate` resource and APIs
-   [#639](https://github.com/stripe/stripe-php/pull/639) Fix multiple phpdoc issues

## 6.33.0 - 2019-04-22

-   [#630](https://github.com/stripe/stripe-php/pull/630) Add support for the `TaxId` resource and APIs

## 6.32.1 - 2019-04-19

-   [#636](https://github.com/stripe/stripe-php/pull/636) Correct type of `$personId` in PHPDoc

## 6.32.0 - 2019-04-18

-   [#621](https://github.com/stripe/stripe-php/pull/621) Add support for `CreditNote`

## 6.31.5 - 2019-04-12

-   [#628](https://github.com/stripe/stripe-php/pull/628) Add constants for `person.*` event types
-   [#628](https://github.com/stripe/stripe-php/pull/628) Add missing constants for `Account` and `Person`

## 6.31.4 - 2019-04-05

-   [#624](https://github.com/stripe/stripe-php/pull/624) Fix encoding of nested parameters in multipart requests

## 6.31.3 - 2019-04-02

-   [#623](https://github.com/stripe/stripe-php/pull/623) Only use HTTP/2 with curl >= 7.60.0

## 6.31.2 - 2019-03-25

-   [#619](https://github.com/stripe/stripe-php/pull/619) Fix PHPDoc return types for list methods for nested resources

## 6.31.1 - 2019-03-22

-   [#612](https://github.com/stripe/stripe-php/pull/612) Add a lot of constants
-   [#614](https://github.com/stripe/stripe-php/pull/614) Add missing subscription status constants

## 6.31.0 - 2019-03-18

-   [#600](https://github.com/stripe/stripe-php/pull/600) Add support for the `PaymentMethod` resource and APIs
-   [#606](https://github.com/stripe/stripe-php/pull/606) Add support for retrieving a Checkout `Session`
-   [#611](https://github.com/stripe/stripe-php/pull/611) Add support for deleting a Terminal `Location` and `Reader`

## 6.30.5 - 2019-03-11

-   [#607](https://github.com/stripe/stripe-php/pull/607) Correctly handle case where a metadata key is called `metadata`

## 6.30.4 - 2019-02-27

-   [#602](https://github.com/stripe/stripe-php/pull/602) Add `subscription_schedule` to `Subscription` for PHPDoc.

## 6.30.3 - 2019-02-26

-   [#603](https://github.com/stripe/stripe-php/pull/603) Improve PHPDoc on the `Source` object to cover all types of Sources currently supported.

## 6.30.2 - 2019-02-25

-   [#601](https://github.com/stripe/stripe-php/pull/601) Fix PHPDoc across multiple resources and add support for new events.

## 6.30.1 - 2019-02-16

-   [#599](https://github.com/stripe/stripe-php/pull/599) Fix PHPDoc for `SubscriptionSchedule` and `SubscriptionScheduleRevision`

## 6.30.0 - 2019-02-12

-   [#590](https://github.com/stripe/stripe-php/pull/590) Add support for `SubscriptionSchedule` and `SubscriptionScheduleRevision`

## 6.29.3 - 2019-01-31

-   [#592](https://github.com/stripe/stripe-php/pull/592) Some more PHPDoc fixes

## 6.29.2 - 2019-01-31

-   [#591](https://github.com/stripe/stripe-php/pull/591) Fix PHPDoc for nested resources

## 6.29.1 - 2019-01-25

-   [#566](https://github.com/stripe/stripe-php/pull/566) Fix dangling message contents
-   [#586](https://github.com/stripe/stripe-php/pull/586) Don't overwrite `CURLOPT_HTTP_VERSION` option

## 6.29.0 - 2019-01-23

-   [#579](https://github.com/stripe/stripe-php/pull/579) Rename `CheckoutSession` to `Session` and move it under the `Checkout` namespace. This is a breaking change, but we've reached out to affected merchants and all new merchants would use the new approach.

## 6.28.1 - 2019-01-21

-   [#580](https://github.com/stripe/stripe-php/pull/580) Properly serialize `individual` on `Account` objects

## 6.28.0 - 2019-01-03

-   [#576](https://github.com/stripe/stripe-php/pull/576) Add support for iterating directly over `Collection` instances

## 6.27.0 - 2018-12-21

-   [#571](https://github.com/stripe/stripe-php/pull/571) Add support for the `CheckoutSession` resource

## 6.26.0 - 2018-12-11

-   [#568](https://github.com/stripe/stripe-php/pull/568) Enable persistent connections

## 6.25.0 - 2018-12-10

-   [#567](https://github.com/stripe/stripe-php/pull/567) Add support for account links

## 6.24.0 - 2018-11-28

-   [#562](https://github.com/stripe/stripe-php/pull/562) Add support for the Review resource
-   [#564](https://github.com/stripe/stripe-php/pull/564) Add event name constants for subscription schedule aborted/expiring

## 6.23.0 - 2018-11-27

-   [#542](https://github.com/stripe/stripe-php/pull/542) Add support for `ValueList` and `ValueListItem` for Radar

## 6.22.1 - 2018-11-20

-   [#561](https://github.com/stripe/stripe-php/pull/561) Add cast and some docs to telemetry introduced in 6.22.0/549

## 6.22.0 - 2018-11-15

-   [#549](https://github.com/stripe/stripe-php/pull/549) Add support for client telemetry

## 6.21.1 - 2018-11-12

-   [#548](https://github.com/stripe/stripe-php/pull/548) Don't mutate `Exception` class properties from `OAuthBase` error

## 6.21.0 - 2018-11-08

-   [#537](https://github.com/stripe/stripe-php/pull/537) Add new API endpoints for the `Invoice` resource.

## 6.20.1 - 2018-11-07

-   [#546](https://github.com/stripe/stripe-php/pull/546) Drop files from the Composer package that aren't needed in the release

## 6.20.0 - 2018-10-30

-   [#536](https://github.com/stripe/stripe-php/pull/536) Add support for the `Person` resource
-   [#541](https://github.com/stripe/stripe-php/pull/541) Add support for the `WebhookEndpoint` resource

## 6.19.5 - 2018-10-17

-   [#539](https://github.com/stripe/stripe-php/pull/539) Fix methods on `\Stripe\PaymentIntent` to properly pass arguments to the API.

## 6.19.4 - 2018-10-11

-   [#534](https://github.com/stripe/stripe-php/pull/534) Fix PSR-4 autoloading for `\Stripe\FileUpload` class alias

## 6.19.3 - 2018-10-09

-   [#530](https://github.com/stripe/stripe-php/pull/530) Add constants for `flow` (`FLOW_*`), `status` (`STATUS_*`) and `usage` (`USAGE_*`) on `\Stripe\Source`

## 6.19.2 - 2018-10-08

-   [#531](https://github.com/stripe/stripe-php/pull/531) Store HTTP response headers in case-insensitive array

## 6.19.1 - 2018-09-25

-   [#526](https://github.com/stripe/stripe-php/pull/526) Ignore null values in request parameters

## 6.19.0 - 2018-09-24

-   [#523](https://github.com/stripe/stripe-php/pull/523) Add support for Stripe Terminal

## 6.18.0 - 2018-09-24

-   [#520](https://github.com/stripe/stripe-php/pull/520) Rename `\Stripe\FileUpload` to `\Stripe\File`

## 6.17.2 - 2018-09-18

-   [#522](https://github.com/stripe/stripe-php/pull/522) Fix warning when adding a new additional owner to an existing array

## 6.17.1 - 2018-09-14

-   [#517](https://github.com/stripe/stripe-php/pull/517) Integer-index encode all sequential arrays

## 6.17.0 - 2018-09-05

-   [#514](https://github.com/stripe/stripe-php/pull/514) Add support for reporting resources

## 6.16.0 - 2018-08-23

-   [#509](https://github.com/stripe/stripe-php/pull/509) Add support for usage record summaries

## 6.15.0 - 2018-08-03

-   [#504](https://github.com/stripe/stripe-php/pull/504) Add cancel support for topups

## 6.14.0 - 2018-08-02

-   [#505](https://github.com/stripe/stripe-php/pull/505) Add support for file links

## 6.13.0 - 2018-07-31

-   [#502](https://github.com/stripe/stripe-php/pull/502) Add `isDeleted()` method to `\Stripe\StripeObject`

## 6.12.0 - 2018-07-28

-   [#501](https://github.com/stripe/stripe-php/pull/501) Add support for scheduled query runs (`\Stripe\Sigma\ScheduledQueryRun`) for Sigma

## 6.11.0 - 2018-07-26

-   [#500](https://github.com/stripe/stripe-php/pull/500) Add support for Stripe Issuing

## 6.10.4 - 2018-07-19

-   [#498](https://github.com/stripe/stripe-php/pull/498) Internal improvements to the `\Stripe\ApiResource.classUrl()` method

## 6.10.3 - 2018-07-16

-   [#497](https://github.com/stripe/stripe-php/pull/497) Use HTTP/2 only for HTTPS requests

## 6.10.2 - 2018-07-11

-   [#494](https://github.com/stripe/stripe-php/pull/494) Enable HTTP/2 support

## 6.10.1 - 2018-07-10

-   [#493](https://github.com/stripe/stripe-php/pull/493) Add PHPDoc for `auto_advance` on `\Stripe\Invoice`

## 6.10.0 - 2018-06-28

-   [#488](https://github.com/stripe/stripe-php/pull/488) Add support for `$appPartnerId` to `Stripe::setAppInfo()`

## 6.9.0 - 2018-06-28

-   [#487](https://github.com/stripe/stripe-php/pull/487) Add support for payment intents

## 6.8.2 - 2018-06-24

-   [#486](https://github.com/stripe/stripe-php/pull/486) Make `Account.deauthorize()` return the `StripeObject` from the API

## 6.8.1 - 2018-06-13

-   [#472](https://github.com/stripe/stripe-php/pull/472) Added phpDoc for `ApiRequestor` and others, especially regarding thrown errors

## 6.8.0 - 2018-06-13

-   [#481](https://github.com/stripe/stripe-php/pull/481) Add new `\Stripe\Discount` and `\Stripe\OrderItem` classes, add more PHPDoc describing object attributes

## 6.7.4 - 2018-05-29

-   [#480](https://github.com/stripe/stripe-php/pull/480) PHPDoc changes for API version 2018-05-21 and the addition of the new `CHARGE_EXPIRED` event type

## 6.7.3 - 2018-05-28

-   [#479](https://github.com/stripe/stripe-php/pull/479) Fix unnecessary traits on `\Stripe\InvoiceLineItem`

## 6.7.2 - 2018-05-28

-   [#471](https://github.com/stripe/stripe-php/pull/471) Add `OBJECT_NAME` constant to all API resource classes, add `\Stripe\InvoiceLineItem` class

## 6.7.1 - 2018-05-13

-   [#468](https://github.com/stripe/stripe-php/pull/468) Update fields in PHP docs for accuracy

## 6.7.0 - 2018-05-09

-   [#466](https://github.com/stripe/stripe-php/pull/466) Add support for issuer fraud records

## 6.6.0 - 2018-04-11

-   [#460](https://github.com/stripe/stripe-php/pull/460) Add support for flexible billing primitives

## 6.5.0 - 2018-04-05

-   [#461](https://github.com/stripe/stripe-php/pull/461) Don't zero keys on non-`metadata` subobjects

## 6.4.2 - 2018-03-17

-   [#458](https://github.com/stripe/stripe-php/pull/458) Add PHPDoc for `account` on `\Stripe\Event`

## 6.4.1 - 2018-03-02

-   [#455](https://github.com/stripe/stripe-php/pull/455) Fix namespaces in PHPDoc
-   [#456](https://github.com/stripe/stripe-php/pull/456) Fix namespaces for some exceptions

## 6.4.0 - 2018-02-28

-   [#453](https://github.com/stripe/stripe-php/pull/453) Add constants for `reason` (`REASON_*`) and `status` (`STATUS_*`) on `\Stripe\Dispute`

## 6.3.2 - 2018-02-27

-   [#452](https://github.com/stripe/stripe-php/pull/452) Add PHPDoc for `amount_paid` and `amount_remaining` on `\Stripe\Invoice`

## 6.3.1 - 2018-02-26

-   [#443](https://github.com/stripe/stripe-php/pull/443) Add event types as constants to `\Stripe\Event` class

## 6.3.0 - 2018-02-23

-   [#450](https://github.com/stripe/stripe-php/pull/450) Add support for `code` attribute on all Stripe exceptions

## 6.2.0 - 2018-02-21

-   [#440](https://github.com/stripe/stripe-php/pull/440) Add support for topups
-   [#442](https://github.com/stripe/stripe-php/pull/442) Fix PHPDoc for `\Stripe\Error\SignatureVerification`

## 6.1.0 - 2018-02-12

-   [#435](https://github.com/stripe/stripe-php/pull/435) Fix header persistence on `Collection` objects
-   [#436](https://github.com/stripe/stripe-php/pull/436) Introduce new `Idempotency` error class

## 6.0.0 - 2018-02-07

Major version release. List of backwards incompatible changes to watch out for:

-   The minimum PHP version is now 5.4.0. If you're using PHP 5.3 or older, consider upgrading to a more recent version.

*   `\Stripe\AttachedObject` no longer exists. Attributes that used to be instances of `\Stripe\AttachedObject` (such as `metadata`) are now instances of `\Stripe\StripeObject`.

-   Attributes that used to be PHP arrays (such as `legal_entity->additional_owners` on `\Stripe\Account` instances) are now instances of `\Stripe\StripeObject`, except when they are empty. `\Stripe\StripeObject` has array semantics so this should not be an issue unless you are actively checking types.

*   `\Stripe\Collection` now derives from `\Stripe\StripeObject` rather than from `\Stripe\ApiResource`.

Pull requests included in this release:

-   [#410](https://github.com/stripe/stripe-php/pull/410) Drop support for PHP 5.3
-   [#411](https://github.com/stripe/stripe-php/pull/411) Use traits for common API operations
-   [#414](https://github.com/stripe/stripe-php/pull/414) Use short array syntax
-   [#404](https://github.com/stripe/stripe-php/pull/404) Fix serialization logic
-   [#417](https://github.com/stripe/stripe-php/pull/417) Remove `ExternalAccount` class
-   [#418](https://github.com/stripe/stripe-php/pull/418) Increase test coverage
-   [#421](https://github.com/stripe/stripe-php/pull/421) Update CA bundle and add script for future updates
-   [#422](https://github.com/stripe/stripe-php/pull/422) Use vendored CA bundle for all requests
-   [#428](https://github.com/stripe/stripe-php/pull/428) Support for automatic request retries

## 5.9.2 - 2018-02-07

-   [#431](https://github.com/stripe/stripe-php/pull/431) Update PHPDoc @property tags for latest API version

## 5.9.1 - 2018-02-06

-   [#427](https://github.com/stripe/stripe-php/pull/427) Add and update PHPDoc @property tags on all API resources

## 5.9.0 - 2018-01-17

-   [#421](https://github.com/stripe/stripe-php/pull/421) Updated bundled CA certificates
-   [#423](https://github.com/stripe/stripe-php/pull/423) Escape unsanitized input in OAuth example

## 5.8.0 - 2017-12-20

-   [#403](https://github.com/stripe/stripe-php/pull/403) Add `__debugInfo()` magic method to `StripeObject`

## 5.7.0 - 2017-11-28

-   [#390](https://github.com/stripe/stripe-php/pull/390) Remove some unsupported API methods
-   [#391](https://github.com/stripe/stripe-php/pull/391) Alphabetize the list of API resources in `Util::convertToStripeObject()` and add missing resources
-   [#393](https://github.com/stripe/stripe-php/pull/393) Fix expiry date update for card sources

## 5.6.0 - 2017-10-31

-   [#386](https://github.com/stripe/stripe-php/pull/386) Support for exchange rates APIs

## 5.5.1 - 2017-10-30

-   [#387](https://github.com/stripe/stripe-php/pull/387) Allow `personal_address_kana` and `personal_address_kanji` to be updated on an account

## 5.5.0 - 2017-10-27

-   [#385](https://github.com/stripe/stripe-php/pull/385) Support for listing source transactions

## 5.4.0 - 2017-10-24

-   [#383](https://github.com/stripe/stripe-php/pull/383) Add static methods to manipulate resources from parent
    -   `Account` gains methods for external accounts and login links (e.g. `createExternalAccount`, `createLoginLink`)
    -   `ApplicationFee` gains methods for refunds
    -   `Customer` gains methods for sources
    -   `Transfer` gains methods for reversals

## 5.3.0 - 2017-10-11

-   [#378](https://github.com/stripe/stripe-php/pull/378) Rename source `delete` to `detach` (and deprecate the former)

## 5.2.3 - 2017-09-27

-   Add PHPDoc for `Card`

## 5.2.2 - 2017-09-20

-   Fix deserialization mapping of `FileUpload` objects

## 5.2.1 - 2017-09-14

-   Serialized `shipping` nested attribute

## 5.2.0 - 2017-08-29

-   Add support for `InvalidClient` OAuth error

## 5.1.3 - 2017-08-14

-   Allow `address_kana` and `address_kanji` to be updated for custom accounts

## 5.1.2 - 2017-08-01

-   Fix documented return type of `autoPagingIterator()` (was missing namespace)

## 5.1.1 - 2017-07-03

-   Fix order returns to use the right URL `/v1/order_returns`

## 5.1.0 - 2017-06-30

-   Add support for OAuth

## 5.0.0 - 2017-06-27

-   `pay` on invoice now takes params as well as opts

## 4.13.0 - 2017-06-19

-   Add support for ephemeral keys

## 4.12.0 - 2017-06-05

-   Clients can implement `getUserAgentInfo()` to add additional user agent information

## 4.11.0 - 2017-06-05

-   Implement `Countable` for `AttachedObject` (`metadata` and `additional_owners`)

## 4.10.0 - 2017-05-25

-   Add support for login links

## 4.9.1 - 2017-05-10

-   Fix docs to include arrays on `$id` parameter for retrieve methods

## 4.9.0 - 2017-04-28

-   Support for checking webhook signatures

## 4.8.1 - 2017-04-24

-   Allow nested field `payout_schedule` to be updated

## 4.8.0 - 2017-04-20

-   Add `\Stripe\Stripe::setLogger()` to support an external PSR-3 compatible logger

## 4.7.0 - 2017-04-10

-   Add support for payouts and recipient transfers

## 4.6.0 - 2017-04-06

-   Please see 4.7.0 instead (no-op release)

## 4.5.1 - 2017-03-22

-   Remove hard dependency on cURL

## 4.5.0 - 2017-03-20

-   Support for detaching sources from customers

## 4.4.2 - 2017-02-27

-   Correct handling of `owner` parameter when updating sources

## 4.4.1 - 2017-02-24

-   Correct the error check on a bad JSON decoding

## 4.4.0 - 2017-01-18

-   Add support for updating sources

## 4.3.0 - 2016-11-30

-   Add support for verifying sources

## 4.2.0 - 2016-11-21

-   Add retrieve method for 3-D Secure resources

## 4.1.1 - 2016-10-21

-   Add docblock with model properties for `Plan`

## 4.1.0 - 2016-10-18

-   Support for 403 status codes (permission denied)

## 4.0.1 - 2016-10-17

-   Fix transfer reversal materialization
-   Fixes for some property definitions in docblocks

## 4.0.0 - 2016-09-28

-   Support for subscription items
-   Drop attempt to force TLS 1.2: please note that this could be breaking if you're using old OS distributions or packages and upgraded recently (so please make sure to test your integration!)

## 3.23.0 - 2016-09-15

-   Add support for Apple Pay domains

## 3.22.0 - 2016-09-13

-   Add `Stripe::setAppInfo` to allow plugins to register user agent information

## 3.21.0 - 2016-08-25

-   Add `Source` model for generic payment sources

## 3.20.0 - 2016-08-08

-   Add `getDeclineCode` to card errors

## 3.19.0 - 2016-07-29

-   Opt requests directly into TLS 1.2 where OpenSSL >= 1.0.1 (see #277 for context)

## 3.18.0 - 2016-07-28

-   Add new `STATUS_` constants for subscriptions

## 3.17.1 - 2016-07-28

-   Fix auto-paging iterator so that it plays nicely with `iterator_to_array`

## 3.17.0 - 2016-07-14

-   Add field annotations to model classes for better editor hinting

## 3.16.0 - 2016-07-12

-   Add `ThreeDSecure` model for 3-D secure payments

## 3.15.0 - 2016-06-29

-   Add static `update` method to all resources that can be changed.

## 3.14.3 - 2016-06-20

-   Make sure that cURL never sends `Expects: 100-continue`, even on large request bodies

## 3.14.2 - 2016-06-03

-   Add `inventory` under `SKU` to list of keys that have nested data and can be updated

## 3.14.1 - 2016-05-27

-   Fix some inconsistencies in PHPDoc

## 3.14.0 - 2016-05-25

-   Add support for returning Relay orders

## 3.13.0 - 2016-05-04

-   Add `list`, `create`, `update`, `retrieve`, and `delete` methods to the Subscription class

## 3.12.1 - 2016-04-07

-   Additional check on value arrays for some extra safety

## 3.12.0 - 2016-03-31

-   Fix bug `refreshFrom` on `StripeObject` would not take an `$opts` array
-   Fix bug where `$opts` not passed to parent `save` method in `Account`
-   Fix bug where non-existent variable was referenced in `reverse` in `Transfer`
-   Update CA cert bundle for compatibility with OpenSSL versions below 1.0.1

## 3.11.0 - 2016-03-22

-   Allow `CurlClient` to be initialized with default `CURLOPT_*` options

## 3.10.1 - 2016-03-22

-   Fix bug where request params and options were ignored in `ApplicationFee`'s `refund.`

## 3.10.0 - 2016-03-15

-   Add `reject` on `Account` to support the new API feature

## 3.9.2 - 2016-03-04

-   Fix error when an object's metadata is set more than once

## 3.9.1 - 2016-02-24

-   Fix encoding behavior of nested arrays for requests (see #227)

## 3.9.0 - 2016-02-09

-   Add automatic pagination mechanism with `autoPagingIterator()`
-   Allow global account ID to be set with `Stripe::setAccountId()`

## 3.8.0 - 2016-02-08

-   Add `CountrySpec` model for looking up country payment information

## 3.7.1 - 2016-02-01

-   Update bundled CA certs

## 3.7.0 - 2016-01-27

-   Support deleting Relay products and SKUs

## 3.6.0 - 2016-01-05

-   Allow configuration of HTTP client timeouts

## 3.5.0 - 2015-12-01

-   Add a verification routine for external accounts

## 3.4.0 - 2015-09-14

-   Products, SKUs, and Orders -- https://stripe.com/relay

## 3.3.0 - 2015-09-11

-   Add support for 429 Rate Limit response

## 3.2.0 - 2015-08-17

-   Add refund listing and retrieval without an associated charge

## 3.1.0 - 2015-08-03

-   Add dispute listing and retrieval
-   Add support for manage account deletion

## 3.0.0 - 2015-07-28

-   Rename `\Stripe\Object` to `\Stripe\StripeObject` (PHP 7 compatibility)
-   Rename `getCode` and `getParam` in exceptions to `getStripeCode` and `getStripeParam`
-   Add support for calling `json_encode` on Stripe objects in PHP 5.4+
-   Start supporting/testing PHP 7

## 2.3.0 - 2015-07-06

-   Add request ID to all Stripe exceptions

## 2.2.0 - 2015-06-01

-   Add support for Alipay accounts as sources
-   Add support for bank accounts as sources (private beta)
-   Add support for bank accounts and cards as external_accounts on Account objects

## 2.1.4 - 2015-05-13

-   Fix CA certificate file path (thanks @lphilps & @matthewarkin)

## 2.1.3 - 2015-05-12

-   Fix to account updating to permit `tos_acceptance` and `personal_address` to be set properly
-   Fix to Transfer reversal creation (thanks @neatness!)
-   Network requests are now done through a swappable class for easier mocking

## 2.1.2 - 2015-04-10

-   Remove SSL cert revokation checking (all pre-Heartbleed certs have expired)
-   Bug fixes to account updating

## 2.1.1 - 2015-02-27

-   Support transfer reversals

## 2.1.0 - 2015-02-19

-   Support new API version (2015-02-18)
-   Added Bitcoin Receiever update and delete actions
-   Edited tests to prefer "source" over "card" as per new API version

## 2.0.1 - 2015-02-16

-   Fix to fetching endpoints that use a non-default baseUrl (`FileUpload`)

## 2.0.0 - 2015-02-14

-   Bumped minimum version to 5.3.3
-   Switched to Stripe namespace instead of Stripe\_ class name prefiexes (thanks @chadicus!)
-   Switched tests to PHPUnit (thanks @chadicus!)
-   Switched style guide to PSR2 (thanks @chadicus!)
-   Added \$opts hash to the end of most methods: this permits passing 'idempotency_key', 'stripe_account', or 'stripe_version'. The last 2 will persist across multiple object loads.
-   Added support for retrieving Account by ID

## 1.18.0 - 2015-01-21

-   Support making bitcoin charges through BitcoinReceiver source object

## 1.17.5 - 2014-12-23

-   Adding support for creating file uploads.

## 1.17.4 - 2014-12-15

-   Saving objects fetched with a custom key now works (thanks @JustinHook & @jpasilan)
-   Added methods for reporting charges as safe or fraudulent and for specifying the reason for refunds

## 1.17.3 - 2014-11-06

-   Better handling of HHVM support for SSL certificate blacklist checking.

## 1.17.2 - 2014-09-23

-   Coupons now are backed by a `Stripe_Coupon` instead of `Stripe_Object`, and support updating metadata
-   Running operations (`create`, `retrieve`, `all`) on upcoming invoice items now works

## 1.17.1 - 2014-07-31

-   Requests now send Content-Type header

## 1.17.0 - 2014-07-29

-   Application Fee refunds now a list instead of array
-   HHVM now works
-   Small bug fixes (thanks @bencromwell & @fastest963)
-   `__toString` now returns the name of the object in addition to its JSON representation

## 1.16.0 - 2014-06-17

-   Add metadata for refunds and disputes

## 1.15.0 - 2014-05-28

-   Support canceling transfers

## 1.14.1 - 2014-05-21

-   Support cards for recipients.

## 1.13.1 - 2014-05-15

-   Fix bug in account resource where `id` wasn't in the result

## 1.13.0 - 2014-04-10

-   Add support for certificate blacklisting
-   Update ca bundle
-   Drop support for HHVM (Temporarily)

## 1.12.0 - 2014-04-01

-   Add Stripe_RateLimitError for catching rate limit errors.
-   Update to Zend coding style (thanks, @jpiasetz)

## 1.11.0 - 2014-01-29

-   Add support for multiple subscriptions per customer

## 1.10.1 - 2013-12-02

-   Add new ApplicationFee

## 1.9.1 - 2013-11-08

-   Fix a bug where a null nestable object causes warnings to fire.

## 1.9.0 - 2013-10-16

-   Add support for metadata API.

## 1.8.4 - 2013-09-18

-   Add support for closing disputes.

## 1.8.3 - 2013-08-13

-   Add new Balance and BalanceTransaction

## 1.8.2 - 2013-08-12

-   Add support for unsetting attributes by updating to NULL. Setting properties to a blank string is now an error.

## 1.8.1 - 2013-07-12

-   Add support for multiple cards API (Stripe API version 2013-07-12: https://docs.stripe.com/changelog/2013-07-05)

## 1.8.0 - 2013-04-11

-   Allow Transfers to be creatable
-   Add new Recipient resource

## 1.7.15 - 2013-02-21

-   Add 'id' to the list of permanent object attributes

## 1.7.14 - 2013-02-20

-   Don't re-encode strings that are already encoded in UTF-8. If you were previously using plan or coupon objects with UTF-8 IDs, they may have been treated as ISO-8859-1 (Latin-1) and encoded to UTF-8 a 2nd time. You may now need to pass the IDs to utf8_encode before passing them to Stripe_Plan::retrieve or Stripe_Coupon::retrieve.
-   Ensure that all input is encoded in UTF-8 before submitting it to Stripe's servers. (github issue #27)

## 1.7.13 - 2013-02-01

-   Add support for passing options when retrieving Stripe objects e.g., Stripe_Charge::retrieve(array("id"=>"foo", "expand" => array("customer"))); Stripe_Charge::retrieve("foo") will continue to work

## 1.7.12 - 2013-01-15

-   Add support for setting a Stripe API version override

## 1.7.11 - 2012-12-30

-   Version bump to cleanup constants and such (fix issue #26)

## 1.7.10 - 2012-11-08

-   Add support for updating charge disputes.
-   Fix bug preventing retrieval of null attributes

## 1.7.9 - 2012-11-08

-   Fix usage under autoloaders such as the one generated by composer (fix issue #22)

## 1.7.8 - 2012-10-30

-   Add support for creating invoices.
-   Add support for new invoice lines return format
-   Add support for new list objects

## 1.7.7 - 2012-09-14

-   Get all of the various version numbers in the repo in sync (no other changes)

## 1.7.6 - 2012-08-31

-   Add update and pay methods to Invoice resource

## 1.7.5 - 2012-08-23

-   Change internal function names so that Stripe_SingletonApiRequest is E_STRICT-clean (github issue #16)

## 1.7.4 - 2012-08-21

-   Bugfix so that Stripe objects (e.g. Customer, Charge objects) used in API calls are transparently converted to their object IDs

## 1.7.3 - 2012-08-15

-   Add new Account resource

## 1.7.2 - 2012-06-26

-   Make clearer that you should be including lib/Stripe.php, not test/Stripe.php (github issue #14)

## 1.7.1 - 2012-05-24

-   Add missing argument to Stripe_InvalidRequestError constructor in Stripe_ApiResource::instanceUrl. Fixes a warning when Stripe_ApiResource::instanceUrl is called on a resource with no ID (fix issue #12)

## 1.7.0 - 2012-05-17

-   Support Composer and Packagist (github issue #9)
-   Add new deleteDiscount method to Stripe_Customer
-   Add new Transfer resource
-   Switch from using HTTP Basic auth to Bearer auth. (Note: Stripe will support Basic auth for the indefinite future, but recommends Bearer auth when possible going forward)
-   Numerous test suite improvements

