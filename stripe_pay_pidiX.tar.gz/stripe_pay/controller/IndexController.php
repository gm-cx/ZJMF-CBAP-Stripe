<?php
namespace gateway\stripe_pay\controller;

use think\facade\Db;

class IndexController
{
    /**
     * 异步回调地址：/gateway/stripe_pay/index/notifyHandle
     */
    public function notifyHandle()
    {
        $config = $this->getPluginConfig();

        require_once dirname(dirname(__FILE__)) . '/lib/init.php';
        $secretKey = $config['live_secret_key'] ?? '';
        \Stripe\Stripe::setApiKey($secretKey);

        $payload = @file_get_contents('php://input');
        $sigHeader = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';
        $endpointSecret = $config['webhook_secret'] ?? '';

        try {
            $event = \Stripe\Webhook::constructEvent($payload, $sigHeader, $endpointSecret);
        } catch (\Exception $e) {
            http_response_code(400);
            exit('Webhook Error: ' . $e->getMessage());
        }

        // 监听 checkout.session.completed 事件
        if ($event->type === 'checkout.session.completed') {
            $session = $event->data->object;
            
            // 从 metadata 或 client_reference_id 获取临时订单号
            $tmpOrderId = $session->metadata['tmp_order_id'] ?? $session->client_reference_id ?? '';
            
            if ($tmpOrderId) {
                // 获取 PaymentIntent 以取得精确的交易金额和时间
                $paymentIntent = null;
                if (!empty($session->payment_intent)) {
                    try {
                        $paymentIntent = \Stripe\PaymentIntent::retrieve($session->payment_intent);
                    } catch (\Exception $e) {
                        // 记录日志
                    }
                }
                
                $amount = $paymentIntent ? ($paymentIntent->amount / 100) : ($session->amount_total / 100);
                $transId = $session->payment_intent ?? $session->id;
                $paidTime = $paymentIntent ? date('Y-m-d H:i:s', $paymentIntent->created) : date('Y-m-d H:i:s');
                
                $param = [
                    'tmp_order_id' => $tmpOrderId,
                    'amount'       => $amount,
                    'trans_id'     => $transId,
                    'currency'     => strtoupper($session->currency ?? 'usd'),
                    'paid_time'    => $paidTime,
                    'gateway'      => 'StripePay',
                ];
                order_pay_handle($param);
            }
        }

        http_response_code(200);
        exit('OK');
    }

    /**
     * 同步返回地址：/gateway/stripe_pay/index/returnHandle
     */
    public function returnHandle()
    {
        $sessionId = $_GET['session_id'] ?? '';
        $canceled = isset($_GET['canceled']);
        
        if ($canceled) {
            echo '<h2>支付已取消</h2><p>您已取消支付，可返回订单页面重新尝试。</p>';
            return;
        }
        
        if ($sessionId) {
            // 可选：显示支付成功提示，或直接重定向到订单详情页
            echo '<h2>支付成功</h2><p>感谢您的支付！订单处理中，请稍后查看状态。</p>';
            // 也可重定向到魔方系统的订单完成页
            // header('Location: /order/complete'); exit;
        } else {
            echo '<h2>支付处理中</h2><p>请返回网站查看订单状态。</p>';
        }
    }

    private function getPluginConfig()
    {
        $dbConfig = Db::name('plugin')
            ->where('name', 'StripePay')
            ->value('config');
        $dbConfig = json_decode($dbConfig, true) ?: [];

        $defaultFile = dirname(dirname(__FILE__)) . '/config/config.php';
        $default = file_exists($defaultFile) ? require $defaultFile : [];

        return array_merge($default, $dbConfig);
    }
}